const jwt = require('jsonwebtoken');
const UserModel = require('../models/userModel');

// --- Konfigurasi JWT ---
const JWT_SECRET = process.env.JWT_SECRET || 'kunci-rahasia-yang-harus-sangat-aman-dan-diganti';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

/**
 * Middleware untuk memastikan user sudah login (UNTUK API).
 * Memverifikasi token dari cookie dan mengembalikan JSON.
 */
const requireAuth = async (req, res, next) => {
    try {
        const token = req.cookies.token;
        
        if (!token) {
            return res.status(401).json({ success: false, message: 'Token tidak ditemukan. Silakan login terlebih dahulu.' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await UserModel.getById(decoded.id_user);

        if (!user) {
            return res.status(401).json({ success: false, message: 'User tidak ditemukan atau telah dihapus.' });
        }
        
        delete user.password;
        req.user = user;
        req.token = token;
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ success: false, message: 'Sesi Anda telah berakhir. Silakan login kembali.' });
        }
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({ success: false, message: 'Token tidak valid.' });
        }
        res.status(500).json({ success: false, message: 'Gagal melakukan otentikasi.' });
    }
};

/**
 * Middleware yang tidak wajib login (UNTUK API).
 * Jika ada token di cookie, verifikasi. Jika tidak, tetap lanjutkan.
 */
const optionalAuth = async (req, res, next) => {
    try {
        const token = req.cookies.token;

        if (token) {
            const decoded = jwt.verify(token, JWT_SECRET);
            const user = await UserModel.getById(decoded.id_user);
            if (user) {
                delete user.password;
                req.user = user;
                req.token = token;
            }
        }
        next();
    } catch (error) {
        next();
    }
};

/**
 * Middleware untuk memeriksa apakah user memiliki peran yang diizinkan (UNTUK API).
 * Gunakan setelah requireAuth.
 */
const requireRole = (allowedRoles) => {
    return (req, res, next) => {
        if (!req.user || !req.user.nama_role) {
            return res.status(403).json({ success: false, message: 'Informasi peran tidak ditemukan.' });
        }

        const userRole = req.user.nama_role;
        const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];

        if (roles.includes(userRole)) {
            next();
        } else {
            res.status(403).json({ success: false, message: `Akses ditolak. Membutuhkan peran: ${roles.join(', ')}.` });
        }
    };
};


// =================================================================
// TAMBAHAN BARU: Middleware untuk Halaman (Views)
// Fungsi-fungsi di bawah ini melakukan redirect, bukan mengirim JSON.
// Ini adalah solusi untuk masalah ERR_TOO_MANY_REDIRECTS.
// =================================================================

/**
 * Middleware untuk melindungi HALAMAN (seperti dashboard).
 * Jika user BELUM login (token tidak valid), akan di-redirect ke /login.
 */
const requirePageView = (req, res, next) => {
    const token = req.cookies.token;

    if (!token) {
        // Jika tidak ada token sama sekali, langsung redirect ke login.
        return res.redirect('/login');
    }

    try {
        // Coba verifikasi token. Jika berhasil, user boleh lanjut.
        jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        // Jika token ada TAPI tidak valid (misal: kadaluwarsa),
        // hapus cookie yang salah dan redirect ke login.
        res.clearCookie('token');
        return res.redirect('/login');
    }
};

/**
 * Middleware untuk HALAMAN login & register.
 * Jika user SUDAH login (punya token valid), akan di-redirect ke dashboard.
 */
const redirectIfLoggedIn = (req, res, next) => {
    const token = req.cookies.token;

    if (token) {
        try {
            // Coba verifikasi token.
            jwt.verify(token, JWT_SECRET);
            // Jika token valid, artinya user sudah login. Langsung redirect ke dashboard.
            return res.redirect('/');
        } catch (error) {
            // Jika token ada TAPI tidak valid, biarkan saja.
            // Lanjutkan ke halaman login agar user bisa login ulang.
            next();
        }
    } else {
        // Jika tidak ada token, lanjutkan ke halaman login.
        next();
    }
};


module.exports = {
    // Middleware lama untuk API
    requireAuth,
    optionalAuth,
    requireRole,
    // Middleware baru untuk Halaman (Views)
    requirePageView,
    redirectIfLoggedIn
};