const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class ListBarangModel {

    /** Get all items from list_barang */
    static async getAll() {
        const sql = `
            SELECT 
                lb.*,
                b.min_qty
            FROM list_barang lb
            LEFT JOIN barang b ON lb.id_barang = b.id_barang
            ORDER BY lb.created_at DESC;
        `;
        return (await query(sql)).rows;
    }

    /** Get items by base code (e.g., NB157) */
    static async getByKode(kode_barang) {
        const sql = `
            SELECT * FROM list_barang 
            WHERE UPPER(base_code) = UPPER($1)
            ORDER BY serial_number ASC;
        `;
        return (await query(sql, [kode_barang])).rows;
    }

    /** Get items by asset state */
    static async getByAssetState(asset_state) {
        const sql = `
            SELECT * FROM list_barang 
            WHERE asset_state = $1
            ORDER BY created_at DESC;
        `;
        return (await query(sql, [asset_state])).rows;
    }

    /** Get items by status (New/Second) */
    static async getByStatus(status) {
        const sql = `
            SELECT * FROM list_barang 
            WHERE status = $1
            ORDER BY created_at DESC;
        `;
        return (await query(sql, [status])).rows;
    }

    /** Get next serial number for base code */
    static async getNextSerialNumber(base_code) {
        const sql = `SELECT get_next_serial_number($1) as next_serial;`;
        const result = await query(sql, [base_code]);
        return result.rows[0].next_serial;
    }

    /** Create multiple serial items (for Receiving) */
    static async createBulk(items) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');
            
            const results = [];
            
            for (const item of items) {
                const {
                    id_barang,
                    base_code,
                    serial_number,
                    kode_barang,
                    nama_barang,
                    jenis_barang,
                    spesifikasi,
                    asset_state,
                    status,
                    lokasi,
                    id_transaksi_masuk
                } = item;
                
                const sql = `
                    INSERT INTO list_barang (
                        id_list_barang, id_barang, base_code, serial_number, kode_barang,
                        nama_barang, jenis_barang, spesifikasi, asset_state, status,
                        lokasi, id_transaksi_masuk
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                    RETURNING *;
                `;
                
                const result = await client.query(sql, [
                    uuidv4(),
                    id_barang,
                    base_code,
                    serial_number,
                    kode_barang,
                    nama_barang,
                    jenis_barang,
                    spesifikasi,
                    asset_state || 'In Store',
                    status || 'New',
                    lokasi,
                    id_transaksi_masuk
                ]);
                
                results.push(result.rows[0]);
            }
            
            await client.query('COMMIT');
            return results;
            
        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[ListBarangModel] Create Bulk Error:', error);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Update item (for Assignment) */
    static async updateForAssignment(kode_barang, updateData) {
        const {
            asset_state,
            npk,
            nama_employee,
            lokasi,
            id_transaksi_keluar
        } = updateData;
        
        const sql = `
            UPDATE list_barang 
            SET 
                asset_state = $1,
                npk = $2,
                nama_employee = $3,
                lokasi = $4,
                id_transaksi_keluar = $5,
                updated_at = NOW()
            WHERE UPPER(kode_barang) = UPPER($6)
            RETURNING *;
        `;
        
        const result = await query(sql, [
            asset_state || 'In Use',
            npk,
            nama_employee,
            lokasi,
            id_transaksi_keluar,
            kode_barang
        ]);
        
        return result.rows[0];
    }

    /** Delete item (for Disposal) */
    static async delete(kode_barang) {
        const sql = `
            DELETE FROM list_barang 
            WHERE UPPER(kode_barang) = UPPER($1)
            RETURNING *;
        `;
        const result = await query(sql, [kode_barang]);
        return result.rows[0];
    }

    /** Check if item exists and available for assignment */
    static async isAvailableForAssignment(kode_barang) {
        const sql = `
            SELECT * FROM list_barang 
            WHERE UPPER(kode_barang) = UPPER($1)
            AND asset_state = 'In Store';
        `;
        const result = await query(sql, [kode_barang]);
        return result.rows[0];
    }

    /** Search items */
    static async search(keyword) {
        const sql = `
            SELECT * FROM list_barang 
            WHERE 
                kode_barang ILIKE $1 OR
                base_code ILIKE $1 OR
                nama_barang ILIKE $1 OR
                jenis_barang ILIKE $1 OR
                nama_employee ILIKE $1 OR
                lokasi ILIKE $1 OR
                npk ILIKE $1
            ORDER BY created_at DESC;
        `;
        const searchPattern = `%${keyword}%`;
        return (await query(sql, [searchPattern])).rows;
    }

    /** Get statistics by base code */
    static async getStatsByBaseCode(base_code) {
        const sql = `
            SELECT 
                base_code,
                COUNT(*) as total_items,
                COUNT(*) FILTER (WHERE asset_state = 'In Store') as in_store,
                COUNT(*) FILTER (WHERE asset_state = 'In Use') as in_use,
                COUNT(*) FILTER (WHERE asset_state = 'Disposal') as disposal,
                COUNT(*) FILTER (WHERE asset_state = 'Expired') as expired,
                COUNT(*) FILTER (WHERE status = 'New') as new_items,
                COUNT(*) FILTER (WHERE status = 'Second') as second_items
            FROM list_barang
            WHERE UPPER(base_code) = UPPER($1)
            GROUP BY base_code;
        `;
        const result = await query(sql, [base_code]);
        return result.rows[0];
    }

    /** Get all items grouped by base code */
    static async getAllGroupedByBase() {
        const sql = `
            SELECT 
                base_code,
                nama_barang,
                jenis_barang,
                COUNT(*) as total_serials,
                COUNT(*) FILTER (WHERE asset_state = 'In Store') as available,
                COUNT(*) FILTER (WHERE asset_state = 'In Use') as in_use,
                MAX(serial_number) as last_serial
            FROM list_barang
            GROUP BY base_code, nama_barang, jenis_barang
            ORDER BY base_code ASC;
        `;
        return (await query(sql)).rows;
    }

}

module.exports = ListBarangModel;