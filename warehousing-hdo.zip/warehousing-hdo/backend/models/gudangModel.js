const { query } = require('../config/db');

class GudangModel {
  // Get all warehouses with transaction statistics
  static async getAll() {
    const sql = `
      SELECT 
        g.id_gudang,
        g.nama_gudang,
        COUNT(t.kode_transaksi) as total_transactions,
        SUM(CASE WHEN t.status_barang = 'Masuk' THEN t.qty_stok ELSE 0 END) as total_masuk,
        SUM(CASE WHEN t.status_barang IN ('Assignment', 'Disposal') THEN t.qty_stok ELSE 0 END) as total_keluar,
        SUM(CASE WHEN t.status_barang = 'Masuk' THEN t.qty_stok ELSE 0 END) - 
        SUM(CASE WHEN t.status_barang IN ('Assignment', 'Disposal') THEN t.qty_stok ELSE 0 END) as current_stock
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang
      GROUP BY g.id_gudang, g.nama_gudang
      ORDER BY g.nama_gudang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all warehouses: ${error.message}`);
    }
  }

  // Get warehouse by ID
  static async getById(id) {
    const sql = `
      SELECT 
        g.*,
        COUNT(t.kode_transaksi) as total_transactions,
        SUM(CASE WHEN t.status_barang = 'Masuk' THEN t.qty_stok ELSE 0 END) as total_masuk,
        SUM(CASE WHEN t.status_barang IN ('Assignment', 'Disposal') THEN t.qty_stok ELSE 0 END) as total_keluar
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang
      WHERE g.id_gudang = $1
      GROUP BY g.id_gudang, g.nama_gudang
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse by ID: ${error.message}`);
    }
  }

  // Create new warehouse
  static async create(warehouseData) {
    const { nama_gudang } = warehouseData;

    const sql = `
      INSERT INTO gudang (nama_gudang)
      VALUES ($1)
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [nama_gudang]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating warehouse: ${error.message}`);
    }
  }

  // Update warehouse
  static async update(id, warehouseData) {
    const { nama_gudang } = warehouseData;

    const sql = `
      UPDATE gudang 
      SET nama_gudang = $2
      WHERE id_gudang = $1
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [id, nama_gudang]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating warehouse: ${error.message}`);
    }
  }

  // Delete warehouse
  static async delete(id) {
    // Check if warehouse has transactions
    const checkSql = 'SELECT COUNT(*) as count FROM transaksi WHERE id_gudang = $1';
    const checkResult = await query(checkSql, [id]);
    
    if (parseInt(checkResult.rows[0].count) > 0) {
      throw new Error('Cannot delete warehouse that has transactions');
    }

    const sql = 'DELETE FROM gudang WHERE id_gudang = $1 RETURNING *';
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting warehouse: ${error.message}`);
    }
  }

  // Get warehouse stock details (items in specific warehouse)
  static async getStockDetails(warehouseId) {
    const sql = `
      SELECT 
        b.id_barang,
        b.jenis_barang,
        b.nama_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE status_barang = 'Masuk' AND id_gudang = $1
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE status_barang IN ('Assignment', 'Disposal') AND id_gudang = $1
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE (COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) > 0
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [warehouseId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting warehouse stock details: ${error.message}`);
    }
  }

  // Get warehouse transaction history
  static async getTransactionHistory(warehouseId, limit = 50) {
    const sql = `
      SELECT 
        t.kode_transaksi,
        t.jenis_barang,
        t.nama_barang,
        t.npk,
        t.nama,
        t.status_barang,
        t.qty_stok,
        t.tanggal,
        t.keterangan
      FROM transaksi t
      WHERE t.id_gudang = $1
      ORDER BY t.tanggal DESC
      LIMIT $2
    `;
    
    try {
      const result = await query(sql, [warehouseId, limit]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting warehouse transaction history: ${error.message}`);
    }
  }

  // Search warehouses
  static async search(searchTerm) {
    const sql = `
      SELECT 
        g.id_gudang,
        g.nama_gudang,
        COUNT(t.kode_transaksi) as total_transactions
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang
      WHERE LOWER(g.nama_gudang) LIKE LOWER($1)
      GROUP BY g.id_gudang, g.nama_gudang
      ORDER BY g.nama_gudang
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching warehouses: ${error.message}`);
    }
  }

  // Get warehouse summary statistics
  static async getSummaryStats() {
    const sql = `
      SELECT 
        COUNT(DISTINCT g.id_gudang) as total_warehouses,
        COUNT(t.kode_transaksi) as total_transactions,
        SUM(CASE WHEN t.status_barang = 'Masuk' THEN t.qty_stok ELSE 0 END) as total_items_in,
        SUM(CASE WHEN t.status_barang IN ('Assignment', 'Disposal') THEN t.qty_stok ELSE 0 END) as total_items_out,
        SUM(CASE WHEN t.status_barang = 'Masuk' THEN t.qty_stok ELSE 0 END) - 
        SUM(CASE WHEN t.status_barang IN ('Assignment', 'Disposal') THEN t.qty_stok ELSE 0 END) as current_total_stock
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse summary statistics: ${error.message}`);
    }
  }

  // Get items available in specific warehouse (with stock > 0)
  static async getAvailableItems(warehouseId) {
    const sql = `
      SELECT 
        b.id_barang,
        b.jenis_barang,
        b.nama_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as available_stock
      FROM barang b
      INNER JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE status_barang = 'Masuk' AND id_gudang = $1
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE status_barang IN ('Assignment', 'Disposal') AND id_gudang = $1
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE (COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) > 0
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [warehouseId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting available items in warehouse: ${error.message}`);
    }
  }
}

module.exports = GudangModel;