const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class GudangModel {

    /** Menambahkan gudang baru ke database. */
    static async create(gudangData, createdBy = null) {
        const { kode_gudang, nama_gudang, lokasi, kapasitas } = gudangData;
        const sql = `
            INSERT INTO gudang (id_gudang, kode_gudang, nama_gudang, lokasi, kapasitas, created_by) 
            VALUES ($1, $2, $3, $4, $5, $6) 
            RETURNING *;
        `;
        try {
            const result = await query(sql, [
                uuidv4(), kode_gudang, nama_gudang, lokasi, kapasitas, createdBy
            ]);
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') throw new Error('Kode gudang sudah ada.');
            throw error;
        }
    }

    /** Mengambil semua gudang yang aktif. */
    static async getAll() {
        const sql = `SELECT * FROM gudang WHERE deleted_at IS NULL ORDER BY nama_gudang;`;
        return (await query(sql)).rows;
    }

    /** Menghitung jumlah gudang yang aktif. */
    static async countActive() {
        const sql = `SELECT COUNT(*) FROM gudang WHERE deleted_at IS NULL;`;
        const result = await query(sql);
        return parseInt(result.rows[0].count, 10);
    }

    /** Mengambil statistik umum untuk dashboard. */
    static async getStats() {
        const sql = `
            SELECT 
                COUNT(*) FILTER (WHERE deleted_at IS NULL) as total_active,
                COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) as total_deleted,
                COUNT(DISTINCT lokasi) FILTER (WHERE deleted_at IS NULL) as unique_locations
            FROM gudang;
        `;
        return (await query(sql)).rows[0];
    }

    /** [OPTIMASI] Mengambil statistik utilisasi untuk SEMUA gudang dalam satu query. */
    static async getUtilizationStats() {
        const sql = `
            SELECT
                g.id_gudang, g.nama_gudang, g.lokasi, g.kapasitas,
                COUNT(DISTINCT t.id_barang) AS unique_items,
                SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.qty_stok ELSE -t.qty_stok END) AS total_stock
            FROM gudang g
            LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang AND t.deleted_at IS NULL
            WHERE g.deleted_at IS NULL
            GROUP BY g.id_gudang, g.nama_gudang, g.lokasi, g.kapasitas
            ORDER BY g.nama_gudang;
        `;
        return (await query(sql)).rows;
    }

    /** [FIXED] Mengambil inventory saat ini dari semua transaksi */
    static async getCurrentInventory() {
        // PERHATIAN: Logika ini sekarang sudah dipindahkan ke Controller,
        // tapi kita perbaiki di sini untuk konsistensi.
        const sql = `
            SELECT 
                b.kode_barang,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi,
                COALESCE(t.status, 'New') as status,
                COALESCE(t.lokasi, 'Unknown') as lokasi,
                MAX(t.tanggal) as tanggal, -- ✅ DIUBAH
                SUM(CASE 
                    WHEN t.jenis_transaksi = 'Receiving' THEN t.qty_stok 
                    WHEN t.jenis_transaksi = 'Assignment' THEN -t.qty_stok 
                    WHEN t.jenis_transaksi = 'Disposal' THEN -t.qty_stok 
                    ELSE 0 
                END) as qty
            FROM transaksi t
            INNER JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.deleted_at IS NULL
            GROUP BY b.kode_barang, b.nama_barang, b.jenis_barang, b.spesifikasi, t.status, t.lokasi
            HAVING SUM(CASE 
                WHEN t.jenis_transaksi = 'Receiving' THEN t.qty_stok 
                WHEN t.jenis_transaksi = 'Assignment' THEN -t.qty_stok 
                WHEN t.jenis_transaksi = 'Disposal' THEN -t.qty_stok 
                ELSE 0 
            END) > 0
            ORDER BY MAX(t.tanggal) DESC; -- ✅ DIUBAH
        `;
        try {
            const result = await query(sql);
            return result.rows;
        } catch (error) {
            console.error('[GudangModel.getCurrentInventory] Error:', error);
            throw error;
        }
    }

    /** Mengambil gudang berdasarkan ID */
    static async getById(id) {
        const sql = `SELECT * FROM gudang WHERE id_gudang = $1 AND deleted_at IS NULL;`;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** Update gudang */
    static async update(id, gudangData, updatedBy = null) {
        const { kode_gudang, nama_gudang, lokasi, kapasitas } = gudangData;
        const sql = `
            UPDATE gudang 
            SET kode_gudang = $1, nama_gudang = $2, lokasi = $3, kapasitas = $4, 
                updated_by = $5, updated_at = NOW()
            WHERE id_gudang = $6 AND deleted_at IS NULL
            RETURNING *;
        `;
        const result = await query(sql, [kode_gudang, nama_gudang, lokasi, kapasitas, updatedBy, id]);
        
        if (result.rows.length === 0) {
            throw new Error('Warehouse not found');
        }
        
        return result.rows[0];
    }

    /** Soft delete gudang */
    static async softDelete(id, deletedBy = null) {
        const sql = `
            UPDATE gudang 
            SET deleted_at = NOW(), deleted_by = $1
            WHERE id_gudang = $2
            RETURNING *;
        `;
        const result = await query(sql, [deletedBy, id]);
        return result.rows[0];
    }

    /** Hard delete gudang (permanent) */
    static async delete(id) {
        const sql = `DELETE FROM gudang WHERE id_gudang = $1 RETURNING *;`;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** Restore soft deleted gudang */
    static async restore(id) {
        const sql = `
            UPDATE gudang 
            SET deleted_at = NULL, deleted_by = NULL
            WHERE id_gudang = $1
            RETURNING *;
        `;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** Search gudang */
    static async search(searchTerm) {
        const sql = `
            SELECT * FROM gudang 
            WHERE deleted_at IS NULL
            AND (
                kode_gudang ILIKE $1 OR 
                nama_gudang ILIKE $1 OR 
                lokasi ILIKE $1
            )
            ORDER BY nama_gudang;
        `;
        const result = await query(sql, [`%${searchTerm}%`]);
        return result.rows;
    }

    /** Get stock details for specific warehouse */
    static async getStockDetails(warehouseId) {
        const sql = `
            SELECT 
                b.kode_barang,
                b.nama_barang,
                b.jenis_barang,
                SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.qty_stok ELSE -t.qty_stok END) as current_stock
            FROM transaksi t
            INNER JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.id_gudang = $1 AND t.deleted_at IS NULL
            GROUP BY b.kode_barang, b.nama_barang, b.jenis_barang
            HAVING SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.qty_stok ELSE -t.qty_stok END) > 0;
        `;
        const result = await query(sql, [warehouseId]);
        return result.rows;
    }

    /** Get available items in warehouse */
    static async getAvailableItems(warehouseId) {
        const sql = `
            SELECT DISTINCT b.*
            FROM barang b
            INNER JOIN transaksi t ON b.id_barang = t.id_barang
            WHERE t.id_gudang = $1 AND t.deleted_at IS NULL
            ORDER BY b.nama_barang;
        `;
        const result = await query(sql, [warehouseId]);
        return result.rows;
    }

    /** Get transaction history for warehouse */
    static async getTransactionHistory(warehouseId, limit = 50) {
        const sql = `
            SELECT t.*, b.nama_barang, b.kode_barang
            FROM transaksi t
            INNER JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.id_gudang = $1 AND t.deleted_at IS NULL
            ORDER BY t.tanggal DESC -- ✅ DIUBAH
            LIMIT $2;
        `;
        const result = await query(sql, [warehouseId, limit]);
        return result.rows;
    }

    /** Get summary stats for dashboard */
    static async getSummaryStats() {
        const sql = `
            SELECT
                COUNT(DISTINCT id_gudang) as total_warehouses,
                COUNT(DISTINCT lokasi) as unique_locations,
                SUM(kapasitas) as total_capacity
            FROM gudang
            WHERE deleted_at IS NULL;
        `;
        const result = await query(sql);
        return result.rows[0];
    }
}

module.exports = GudangModel;