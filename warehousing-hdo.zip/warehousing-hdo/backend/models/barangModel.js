const { query, getClient } = require('../config/db');

class BarangModel {
  // Get all items with stock calculation from transactions
  static async getAllWithStock() {
    const sql = `
      SELECT 
        b.id_barang,
        b.jenis_barang,
        b.nama_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE status_barang = 'Masuk'
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE status_barang IN ('Assignment', 'Disposal')
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all items with stock: ${error.message}`);
    }
  }

  // Get item by ID
  static async getById(id) {
    const sql = `
      SELECT * FROM barang WHERE id_barang = $1
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting item by ID: ${error.message}`);
    }
  }

  // Create new item
  static async create(itemData) {
    const { jenis_barang, nama_barang, spesifikasi } = itemData;

    const sql = `
      INSERT INTO barang (jenis_barang, nama_barang, spesifikasi)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [jenis_barang, nama_barang, spesifikasi]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating item: ${error.message}`);
    }
  }

  // Update item
  static async update(id, itemData) {
    const { jenis_barang, nama_barang, spesifikasi } = itemData;

    const sql = `
      UPDATE barang 
      SET jenis_barang = $2, nama_barang = $3, spesifikasi = $4
      WHERE id_barang = $1
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [id, jenis_barang, nama_barang, spesifikasi]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating item: ${error.message}`);
    }
  }

  // Delete item
  static async delete(id) {
    const sql = 'DELETE FROM barang WHERE id_barang = $1 RETURNING *';
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting item: ${error.message}`);
    }
  }

  // Get current stock for specific item and warehouse
  static async getCurrentStock(itemId, warehouseId = null) {
    let sql = `
      SELECT 
        b.id_barang,
        b.jenis_barang,
        b.nama_barang,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE status_barang = 'Masuk' AND id_barang = $1
    `;
    
    let params = [itemId];
    
    if (warehouseId) {
      sql += ` AND id_gudang = $2`;
      params.push(warehouseId);
    }
    
    sql += `
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT 
          id_barang,
          SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE status_barang IN ('Assignment', 'Disposal') AND id_barang = $1
    `;
    
    if (warehouseId) {
      sql += ` AND id_gudang = $${params.length + 1}`;
      params.push(warehouseId);
    }
    
    sql += `
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.id_barang = $1
    `;
    
    try {
      const result = await query(sql, params);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting current stock: ${error.message}`);
    }
  }

  // Get low stock items (items with stock < 5)
  static async getLowStockItems(threshold = 5) {
    const sql = `
      SELECT 
        b.id_barang,
        b.jenis_barang,
        b.nama_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock,
        g.nama_gudang
      FROM barang b
      LEFT JOIN (
        SELECT 
          id_barang,
          id_gudang,
          SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE status_barang = 'Masuk'
        GROUP BY id_barang, id_gudang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT 
          id_barang,
          id_gudang,
          SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE status_barang IN ('Assignment', 'Disposal')
        GROUP BY id_barang, id_gudang
      ) stock_out ON b.id_barang = stock_out.id_barang AND stock_in.id_gudang = stock_out.id_gudang
      LEFT JOIN gudang g ON stock_in.id_gudang = g.id_gudang
      WHERE (COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) < $1
      AND (COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) >= 0
      ORDER BY current_stock ASC, b.nama_barang
    `;
    
    try {
      const result = await query(sql, [threshold]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting low stock items: ${error.message}`);
    }
  }

  // Search items
  static async search(searchTerm) {
    const sql = `
      SELECT 
        b.id_barang,
        b.jenis_barang,
        b.nama_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_masuk
        FROM transaksi WHERE status_barang = 'Masuk'
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_keluar
        FROM transaksi WHERE status_barang IN ('Assignment', 'Disposal')
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE 
        LOWER(b.nama_barang) LIKE LOWER($1) OR
        LOWER(b.jenis_barang) LIKE LOWER($1) OR
        LOWER(b.spesifikasi) LIKE LOWER($1)
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching items: ${error.message}`);
    }
  }

  // Get items by category (jenis_barang)
  static async getByCategory(jenisBarang) {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_masuk
        FROM transaksi WHERE status_barang = 'Masuk'
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_keluar
        FROM transaksi WHERE status_barang IN ('Assignment', 'Disposal')
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE LOWER(b.jenis_barang) = LOWER($1)
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [jenisBarang]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting items by category: ${error.message}`);
    }
  }

  // Get all categories
  static async getCategories() {
    const sql = `
      SELECT 
        jenis_barang,
        COUNT(*) as item_count,
        SUM(COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) as total_stock
      FROM barang b
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_masuk
        FROM transaksi WHERE status_barang = 'Masuk'
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_keluar
        FROM transaksi WHERE status_barang IN ('Assignment', 'Disposal')
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      GROUP BY jenis_barang
      ORDER BY jenis_barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting categories: ${error.message}`);
    }
  }
}

module.exports = BarangModel;