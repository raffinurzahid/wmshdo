const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class BarangModel {

    /** Membuat barang baru */
    static async create(itemData, createdBy = null) {
        const { 
            kode_barang, 
            nama_barang, 
            jenis_barang, 
            spesifikasi, 
            qty_stok, 
            min_qty
        } = itemData;

        // Validasi kode_barang maksimal 6 karakter
        if (!kode_barang || kode_barang.trim().length === 0) {
            throw new Error('Kode Barang tidak boleh kosong.');
        }
        if (kode_barang.length > 6) {
            throw new Error('Kode Barang maksimal 6 karakter.');
        }

        // Validasi required fields
        if (!nama_barang || nama_barang.trim().length === 0) {
            throw new Error('Nama Barang tidak boleh kosong.');
        }
        if (!jenis_barang || jenis_barang.trim().length === 0) {
            throw new Error('Jenis Barang tidak boleh kosong.');
        }

        // Validasi qty tidak negatif
        const qtyVal = parseInt(qty_stok) || 0;
        if (qtyVal < 0) {
            throw new Error('Qty Stok tidak boleh negatif.');
        }

        const minQtyVal = parseInt(min_qty) || 0;
        if (minQtyVal < 0) {
            throw new Error('Min Qty tidak boleh negatif.');
        }

        const sql = `
            INSERT INTO barang (
                id_barang, kode_barang, nama_barang, jenis_barang, 
                spesifikasi, qty_stok, min_qty, created_by
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
            RETURNING *;
        `;

        try {
            const result = await query(sql, [
                uuidv4(), 
                kode_barang.trim().toUpperCase(), 
                nama_barang.trim(), 
                jenis_barang.trim(), 
                (spesifikasi || '').trim(), 
                qtyVal, 
                minQtyVal, 
                createdBy
            ]);
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') {
                throw new Error('Kode Barang sudah terdaftar.');
            }
            throw error;
        }
    }

    /** Mengambil semua barang */
    static async getAll() {
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE deleted_at IS NULL 
            ORDER BY nama_barang ASC;
        `;
        return (await query(sql)).rows;
    }

    /** Mengambil barang berdasarkan ID */
    static async getById(id) {
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE id_barang = $1 AND deleted_at IS NULL;
        `;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** Mengambil barang berdasarkan kode_barang */
    static async getByKode(kode) {
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE UPPER(kode_barang) = UPPER($1) AND deleted_at IS NULL;
        `;
        const result = await query(sql, [kode]);
        return result.rows[0];
    }

    /** Update barang */
    static async update(id, itemData, updatedBy = null) {
        const { 
            kode_barang, 
            nama_barang, 
            jenis_barang, 
            spesifikasi, 
            qty_stok, 
            min_qty
        } = itemData;

        // Validasi kode_barang jika diubah
        if (kode_barang !== undefined && kode_barang !== null) {
            if (kode_barang.trim().length === 0) {
                throw new Error('Kode Barang tidak boleh kosong.');
            }
            if (kode_barang.length > 6) {
                throw new Error('Kode Barang maksimal 6 karakter.');
            }
        }

        // Validasi qty tidak negatif
        if (qty_stok !== undefined && qty_stok !== null) {
            const qtyVal = parseInt(qty_stok);
            if (qtyVal < 0) {
                throw new Error('Qty Stok tidak boleh negatif.');
            }
        }

        if (min_qty !== undefined && min_qty !== null) {
            const minQtyVal = parseInt(min_qty);
            if (minQtyVal < 0) {
                throw new Error('Min Qty tidak boleh negatif.');
            }
        }

        const sql = `
            UPDATE barang 
            SET 
                kode_barang = COALESCE($1, kode_barang),
                nama_barang = COALESCE($2, nama_barang),
                jenis_barang = COALESCE($3, jenis_barang),
                spesifikasi = COALESCE($4, spesifikasi),
                qty_stok = COALESCE($5, qty_stok),
                min_qty = COALESCE($6, min_qty),
                updated_at = NOW(),
                updated_by = $7
            WHERE id_barang = $8 AND deleted_at IS NULL
            RETURNING *;
        `;

        try {
            const result = await query(sql, [
                kode_barang ? kode_barang.trim().toUpperCase() : null,
                nama_barang ? nama_barang.trim() : null,
                jenis_barang ? jenis_barang.trim() : null,
                spesifikasi ? spesifikasi.trim() : null,
                qty_stok !== undefined && qty_stok !== null ? parseInt(qty_stok) : null,
                min_qty !== undefined && min_qty !== null ? parseInt(min_qty) : null,
                updatedBy,
                id
            ]);

            if (result.rows.length === 0) {
                throw new Error('Barang tidak ditemukan.');
            }

            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') {
                throw new Error('Kode Barang sudah terdaftar.');
            }
            throw error;
        }
    }

    /** Update stock barang (untuk transaksi) */
    static async updateStock(id, qtyChange) {
        const sql = `
            UPDATE barang 
            SET qty_stok = qty_stok + $1,
                updated_at = NOW()
            WHERE id_barang = $2 AND deleted_at IS NULL
            RETURNING *;
        `;

        const result = await query(sql, [qtyChange, id]);
        
        if (result.rows.length === 0) {
            throw new Error('Barang tidak ditemukan.');
        }

        return result.rows[0];
    }

    /** Soft delete barang */
    static async softDelete(id, deletedBy = null) {
        const sql = `
            UPDATE barang 
            SET deleted_at = NOW(), deleted_by = $1
            WHERE id_barang = $2 AND deleted_at IS NULL
            RETURNING *;
        `;

        const result = await query(sql, [deletedBy, id]);
        
        if (result.rows.length === 0) {
            throw new Error('Barang tidak ditemukan.');
        }

        return result.rows[0];
    }

    /** Search barang */
    static async search(keyword) {
        const sql = `
            SELECT 
                id_barang,
                kode_barang,
                nama_barang,
                jenis_barang,
                spesifikasi,
                qty_stok,
                min_qty
            FROM barang
            WHERE deleted_at IS NULL
                AND (
                    kode_barang ILIKE $1 OR
                    nama_barang ILIKE $1 OR
                    jenis_barang ILIKE $1 OR
                    spesifikasi ILIKE $1
                )
            ORDER BY nama_barang ASC;
        `;

        const searchPattern = `%${keyword}%`;
        return (await query(sql, [searchPattern])).rows;
    }

    /** Get low stock items */
    static async getLowStockItems(limit = null) {
        let sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang,
                qty_stok, 
                min_qty,
                (min_qty - qty_stok) as shortage
            FROM barang 
            WHERE deleted_at IS NULL 
                AND min_qty > 0 
                AND qty_stok < min_qty 
            ORDER BY (min_qty - qty_stok) DESC, nama_barang ASC
        `;
        
        const params = [];
        if (limit) {
            sql += ` LIMIT $1`;
            params.push(limit);
        }
        
        return (await query(sql, params)).rows;
    }

    /** Get all items with stock info */
    static async getAllWithStock() {
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok as current_stock, 
                min_qty
            FROM barang 
            WHERE deleted_at IS NULL 
            ORDER BY nama_barang ASC;
        `;
        return (await query(sql)).rows;
    }

    /** Get categories */
    static async getCategories() {
        const sql = `
            SELECT 
                jenis_barang,
                COUNT(*) as item_count,
                SUM(qty_stok) as total_stock
            FROM barang
            WHERE deleted_at IS NULL
            GROUP BY jenis_barang
            ORDER BY jenis_barang ASC;
        `;
        return (await query(sql)).rows;
    }

    /** Get stats */
    static async getStats() {
        const sql = `
            SELECT 
                COUNT(*) AS total_items,
                COUNT(DISTINCT jenis_barang) AS unique_categories,
                SUM(qty_stok) AS total_stock,
                COUNT(*) FILTER (WHERE qty_stok < min_qty AND min_qty > 0) AS low_stock_count
            FROM barang 
            WHERE deleted_at IS NULL;
        `;
        return (await query(sql)).rows[0];
    }

    // ========== ✅ NEW METHODS FOR BASE CODE LOGIC ========== //

    /** Get all items sorted by stock */
    static async getAllSorted(order = 'DESC') {
        const orderDirection = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE deleted_at IS NULL 
            ORDER BY qty_stok ${orderDirection}, nama_barang ASC;
        `;
        return (await query(sql)).rows;
    }

    /** Extract base code from full code */
    static getByKode(fullCode) {
        if (!fullCode || typeof fullCode !== 'string') return fullCode;
        return fullCode.split('-')[0].toUpperCase();
    }

    /** Check if base code exists */
    static async kodeExists(kode_barang) {
        const sql = `
            SELECT id_barang 
            FROM barang 
            WHERE UPPER(kode_barang) = UPPER($1) AND deleted_at IS NULL 
            LIMIT 1;
        `;
        const result = await query(sql, [kode_barang]);
        return result.rows.length > 0;
    }

    /** Get item by base code (case insensitive) */
    static async getByKode(kode_barang) {
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE UPPER(kode_barang) = UPPER($1) AND deleted_at IS NULL;
        `;
        const result = await query(sql, [kode_barang]);
        return result.rows[0];
    }
}

module.exports = BarangModel;