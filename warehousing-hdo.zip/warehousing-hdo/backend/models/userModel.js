const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs'); 
const RoleModel = require('./RoleModel');

class UserModel {

    /** Membuat user baru dengan password yang di-hash. */
    static async create(userData, createdBy = null) {
        let { username, password, email, id_role } = userData;
        
        if (!id_role) {
            const userRole = await RoleModel.getByName('user');
            if (!userRole) throw new Error("Peran default 'user' tidak ditemukan di database.");
            id_role = userRole.id_role;
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const sql = `
            INSERT INTO "user" (id_user, username, password, email, id_role, created_by)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id_user, username, email, id_role;
        `;
        try {
            const result = await query(sql, [
                uuidv4(), username, hashedPassword, email, id_role, createdBy
            ]);
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') throw new Error('Username atau email sudah terdaftar.');
            throw error;
        }
    }

    /** Mengambil semua user yang aktif (tidak di-soft delete). */
    static async getAll() {
        const sql = `
            SELECT u.id_user, u.username, u.email, r.nama_role
            FROM "user" u
            LEFT JOIN role r ON u.id_role = r.id_role
            WHERE u.deleted_at IS NULL
            ORDER BY u.username;
        `;
        return (await query(sql)).rows;
    }

    /** Mengambil satu user berdasarkan ID. */
    static async getById(id) {
        const sql = `
            SELECT u.id_user, u.username, u.password, u.email, r.nama_role
            FROM "user" u
            LEFT JOIN role r ON u.id_role = r.id_role
            WHERE u.id_user = $1 AND u.deleted_at IS NULL;
        `;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** Memperbarui data user. */
    static async update(id, userData, updatedBy = null) {
        const fields = { ...userData, updated_by: updatedBy };
        if (fields.password) {
            fields.password = await bcrypt.hash(fields.password, 10);
        }

        const updates = [];
        const values = [id];
        let paramIndex = 2;

        for (const [key, value] of Object.entries(fields)) {
            if (value !== undefined) {
                updates.push(`"${key}" = $${paramIndex++}`);
                values.push(value);
            }
        }

        if (updates.length === 0) throw new Error('Tidak ada data yang diupdate.');

        const sql = `
            UPDATE "user" SET ${updates.join(', ')}, updated_at = NOW()
            WHERE id_user = $1 AND deleted_at IS NULL
            RETURNING id_user, username, email, id_role;
        `;
        
        const result = await query(sql, values);
        if (result.rows.length === 0) throw new Error('User tidak ditemukan.');
        return result.rows[0];
    }

    /** Menghapus user secara sementara (soft delete). */
    static async softDelete(id, deletedBy = null) {
        const sql = `
            UPDATE "user" SET deleted_at = NOW(), deleted_by = $2
            WHERE id_user = $1 AND deleted_at IS NULL
            RETURNING id_user, username;
        `;
        const result = await query(sql, [id, deletedBy]);
        if (result.rows.length === 0) throw new Error('User tidak ditemukan atau sudah dihapus.');
        return result.rows[0];
    }
    
    /** Mengembalikan user yang sudah di-soft delete. */
    static async restore(id) {
        const sql = `
            UPDATE "user" SET deleted_at = NULL, deleted_by = NULL
            WHERE id_user = $1 AND deleted_at IS NOT NULL
            RETURNING id_user, username;
        `;
        const result = await query(sql, [id]);
        if (result.rows.length === 0) throw new Error('User tidak ditemukan atau tidak dalam kondisi terhapus.');
        return result.rows[0];
    }

    /** Menghitung jumlah user aktif, lebih efisien dari getAll().length. */
    static async countActive() {
        const sql = `SELECT COUNT(*) FROM "user" WHERE deleted_at IS NULL;`;
        const result = await query(sql);
        return parseInt(result.rows[0].count, 10);
    }

    /** Mengambil statistik umum (total aktif, total dihapus, dll) untuk dashboard. */
    static async getStats() {
        const sql = `
            SELECT 
                COUNT(*) FILTER (WHERE deleted_at IS NULL) AS total_active,
                COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) AS total_deleted,
                COUNT(DISTINCT id_role) FILTER (WHERE deleted_at IS NULL) AS unique_roles
            FROM "user";
        `;
        return (await query(sql)).rows[0];
    }

    /** Mengambil ringkasan aktivitas untuk N pengguna teratas. */
    static async getActivitySummary(limit = 10) {
        const sql = `
            SELECT 
                u.username,
                COUNT(t.id_transaksi) AS total_transactions,
                COUNT(*) FILTER (WHERE t.jenis_transaksi = 'Assignment') AS assignment_count,
                COUNT(*) FILTER (WHERE t.jenis_transaksi = 'Masuk') AS receiving_count
            FROM "user" u
            LEFT JOIN transaksi t ON u.id_user = t.created_by::uuid
            WHERE u.deleted_at IS NULL
            GROUP BY u.id_user, u.username
            HAVING COUNT(t.id_transaksi) > 0
            ORDER BY total_transactions DESC
            LIMIT $1;
        `;
        return (await query(sql, [limit])).rows;
    }
    
    /** Mengambil user berdasarkan username untuk proses login. */
    static async getByUsername(username) {
        const sql = `
            SELECT u.*, r.nama_role FROM "user" u
            LEFT JOIN role r ON u.id_role = r.id_role
            WHERE u.username = $1 AND u.deleted_at IS NULL;
        `;
        return (await query(sql, [username])).rows[0];
    }
    
    /** Memverifikasi kecocokan password. */
    static async verifyPassword(plainPassword, hashedPassword) {
        return await bcrypt.compare(plainPassword, hashedPassword);
    }
}

module.exports = UserModel;