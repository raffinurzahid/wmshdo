const { query } = require('../config/db');

class KaryawanModel {
  // Get all employees
  static async getAll() {
    const sql = `
      SELECT 
        id_karyawan,
        npk,
        nama
      FROM karyawan
      ORDER BY nama
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all employees: ${error.message}`);
    }
  }

  // Get employee by ID
  static async getById(id) {
    const sql = `
      SELECT * FROM karyawan WHERE id_karyawan = $1
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting employee by ID: ${error.message}`);
    }
  }

  // Get employee by NPK
  static async getByNpk(npk) {
    const sql = `
      SELECT * FROM karyawan WHERE npk = $1
    `;
    
    try {
      const result = await query(sql, [npk]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting employee by NPK: ${error.message}`);
    }
  }

  // Create new employee
  static async create(employeeData) {
    const { npk, nama } = employeeData;

    const sql = `
      INSERT INTO karyawan (npk, nama)
      VALUES ($1, $2)
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [npk, nama]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating employee: ${error.message}`);
    }
  }

  // Update employee
  static async update(id, employeeData) {
    const { npk, nama } = employeeData;

    const sql = `
      UPDATE karyawan 
      SET npk = $2, nama = $3
      WHERE id_karyawan = $1
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [id, npk, nama]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating employee: ${error.message}`);
    }
  }

  // Delete employee
  static async delete(id) {
    const sql = 'DELETE FROM karyawan WHERE id_karyawan = $1 RETURNING *';
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting employee: ${error.message}`);
    }
  }

  // Search employees
  static async search(searchTerm) {
    const sql = `
      SELECT 
        id_karyawan, npk, nama
      FROM karyawan
      WHERE 
        LOWER(nama) LIKE LOWER($1) OR
        LOWER(npk) LIKE LOWER($1)
      ORDER BY nama
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching employees: ${error.message}`);
    }
  }

  // Get employee assignment history (from transactions)
  static async getAssignmentHistory(employeeId) {
    const sql = `
      SELECT 
        t.kode_transaksi,
        t.jenis_barang,
        t.nama_barang,
        t.status_barang,
        t.qty_stok,
        t.tanggal,
        g.nama_gudang,
        t.keterangan
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN karyawan k ON t.npk = k.npk
      WHERE k.id_karyawan = $1
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [employeeId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting employee assignment history: ${error.message}`);
    }
  }

  // Get current assignments for employee (status = Assignment)
  static async getCurrentAssignments(employeeId) {
    const sql = `
      SELECT 
        t.kode_transaksi,
        t.jenis_barang,
        t.nama_barang,
        t.qty_stok,
        t.tanggal,
        g.nama_gudang,
        t.keterangan
      FROM transaksi t
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      LEFT JOIN karyawan k ON t.npk = k.npk
      WHERE k.id_karyawan = $1 AND t.status_barang = 'Assignment'
      ORDER BY t.tanggal DESC
    `;
    
    try {
      const result = await query(sql, [employeeId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting current assignments: ${error.message}`);
    }
  }

  // Get employees with active assignments
  static async getWithActiveAssignments() {
    const sql = `
      SELECT 
        k.id_karyawan,
        k.npk,
        k.nama,
        COUNT(t.kode_transaksi) as total_assignments,
        STRING_AGG(DISTINCT t.nama_barang, ', ') as assigned_items
      FROM karyawan k
      JOIN transaksi t ON k.npk = t.npk
      WHERE t.status_barang = 'Assignment'
      GROUP BY k.id_karyawan, k.npk, k.nama
      ORDER BY k.nama
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting employees with active assignments: ${error.message}`);
    }
  }

  // Get employee statistics
  static async getEmployeeStats() {
    const sql = `
      SELECT 
        COUNT(*) as total_employees,
        COUNT(DISTINCT t.npk) as employees_with_assignments
      FROM karyawan k
      LEFT JOIN transaksi t ON k.npk = t.npk AND t.status_barang = 'Assignment'
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting employee statistics: ${error.message}`);
    }
  }
}

module.exports = KaryawanModel;