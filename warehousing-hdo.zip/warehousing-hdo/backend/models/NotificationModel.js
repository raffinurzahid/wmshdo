const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class NotificationModel {

    /** Mengambil notifikasi untuk user tertentu, diurutkan dari yang terbaru. */
    static async getByUser(userId, limit = 50) {
        const sql = `
            SELECT * FROM notification
            WHERE id_user = $1 AND deleted_at IS NULL
            ORDER BY created_at DESC
            LIMIT $2;
        `;
        return (await query(sql, [userId, limit])).rows;
    }

    /** Membuat notifikasi baru di database. */
    static async create(notificationData) {
        const { id_user, title, message, type, icon, color, reference_id } = notificationData;
        const sql = `
            INSERT INTO notification (id_notification, id_user, title, message, type, icon, color, reference_id)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING *;
        `;
        const result = await query(sql, [
            uuidv4(), id_user, title, message, type, icon, color, reference_id
        ]);
        return result.rows[0];
    }

    /** Menandai satu notifikasi sebagai sudah dibaca. */
    static async markAsRead(notificationId, userId) {
        const sql = `
            UPDATE notification SET is_read = TRUE, updated_at = NOW()
            WHERE id_notification = $1 AND id_user = $2 AND deleted_at IS NULL
            RETURNING *;
        `;
        const result = await query(sql, [notificationId, userId]);
        return result.rows[0];
    }

    /** Menandai semua notifikasi milik user sebagai sudah dibaca. */
    static async markAllAsRead(userId) {
        const sql = `
            UPDATE notification SET is_read = TRUE, updated_at = NOW()
            WHERE id_user = $1 AND is_read = FALSE AND deleted_at IS NULL;
        `;
        const result = await query(sql, [userId]);
        return result.rowCount; // Mengembalikan jumlah notifikasi yang di-update
    }

    /** Menghitung notifikasi yang belum dibaca oleh user. */
    static async countUnread(userId) {
        const sql = `SELECT COUNT(*) FROM notification WHERE id_user = $1 AND is_read = FALSE AND deleted_at IS NULL;`;
        const result = await query(sql, [userId]);
        return parseInt(result.rows[0].count, 10);
    }
}

module.exports = NotificationModel;