const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class TransaksiModel {

    /** Generate next transaction code */
    static async generateNextCode(prefix) {
        const sql = `SELECT get_next_transaction_code($1) as next_code;`;
        const result = await query(sql, [prefix]);
        return result.rows[0].next_code;
    }

    /** Get all transactions */
    static async getAll() {
        const sql = `
            SELECT 
                t.*,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi
            FROM transaksi t
            LEFT JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.deleted_at IS NULL
            ORDER BY t.created_at DESC;
        `;
        return (await query(sql)).rows;
    }

    /** Get transaction by ID */
    static async getById(id) {
        const sql = `
            SELECT 
                t.*,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi
            FROM transaksi t
            LEFT JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.id_transaksi = $1 AND t.deleted_at IS NULL;
        `;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** Create transaction and update stock - WITH BASE CODE LOGIC */
    static async create(txData, createdBy = null) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');

            const { 
                kode_transaksi,
                jenis_transaksi, 
                id_barang,
                kode_barang, // Could be MTR60 or MTR60-14
                qty_stok = 1,
                status,
                asset_state,
                npk,
                nama_employee,
                lokasi,
                id_gudang,
                keterangan,
                tanggal,
                status_barang // ✅ TAMBAHAN: Status barang untuk Receiving (New/Second)
            } = txData;

            console.log('[Model] ============ CREATE TRANSACTION ============');
            console.log('[Model] Input kode_barang:', kode_barang);
            console.log('[Model] Jenis transaksi:', jenis_transaksi);
            console.log('[Model] Qty:', qty_stok);
            console.log('[Model] Status (asset_state):', status || asset_state);
            console.log('[Model] Status Barang (New/Second):', status_barang);

            if (!kode_transaksi || !jenis_transaksi || !kode_barang) {
                throw new Error('Missing required fields');
            }

            // ✅ EXTRACT BASE CODE (handle both formats)
            const baseCode = kode_barang.split('-')[0].toUpperCase();
            console.log('[Model] ✅ Base code extracted:', baseCode);

            // ✅ FIND BASE ITEM in Master Data
            const itemResult = await client.query(
                'SELECT * FROM barang WHERE UPPER(kode_barang) = $1 AND deleted_at IS NULL',
                [baseCode]
            );

            if (itemResult.rows.length === 0) {
                console.error('[Model] ❌ Base item NOT FOUND:', baseCode);
                throw new Error(`Base item "${baseCode}" not found in Master Data Barang. Please create it first.`);
            }

            const itemData = itemResult.rows[0];
            console.log('[Model] ✅ Base item found:', {
                id_barang: itemData.id_barang,
                kode_barang: itemData.kode_barang,
                nama_barang: itemData.nama_barang,
                current_stock: itemData.qty_stok
            });

            // ✅ VALIDATE STOCK for Assignment/Disposal
            if (jenis_transaksi === 'Assignment' || jenis_transaksi === 'Disposal') {
                if (itemData.qty_stok < qty_stok) {
                    throw new Error(`Insufficient stock for ${baseCode}. Current: ${itemData.qty_stok}, Requested: ${qty_stok}`);
                }
            }

            // ✅ DETERMINE FINAL STATUS for transaksi table
            let finalStatus = asset_state || status;
            if (!finalStatus) {
                if (jenis_transaksi === 'Receiving') finalStatus = 'In Store';
                else if (jenis_transaksi === 'Assignment') finalStatus = 'In Use';
                else if (jenis_transaksi === 'Disposal') finalStatus = asset_state || 'Disposal';
            }

            // ✅ INSERT TRANSACTION with FULL CODE
            const txSql = `
                INSERT INTO transaksi (
                    id_transaksi, kode_transaksi, jenis_transaksi, 
                    id_barang, kode_barang, nama_barang, jenis_barang, spesifikasi,
                    qty_stok, status, asset_state, npk, nama_employee, 
                    lokasi, id_gudang, keterangan, tanggal, created_by
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
                RETURNING *;
            `;

            const txResult = await client.query(txSql, [
                uuidv4(),
                kode_transaksi,
                jenis_transaksi,
                itemData.id_barang, // ✅ ID dari base item
                kode_barang.toUpperCase(), // ✅ FULL CODE (MTR60-14 or MTR60)
                itemData.nama_barang,
                itemData.jenis_barang,
                itemData.spesifikasi,
                qty_stok,
                finalStatus, // ✅ Status untuk transaksi (In Store, In Use, Disposal, Expired)
                finalStatus, // ✅ Asset state sama dengan status
                npk || null,
                nama_employee || null,
                lokasi,
                id_gudang,
                keterangan,
                tanggal || new Date(),
                createdBy
            ]);

            console.log('[Model] ✅ Transaction inserted:', txResult.rows[0].kode_transaksi);

            // ✅ UPDATE STOCK in BASE CODE
            const stockChange = jenis_transaksi === 'Receiving' ? qty_stok : -qty_stok;
            
            console.log('[Model] ✅ Updating stock for base code:', baseCode);
            console.log('[Model]    Stock change:', stockChange);
            
            await client.query(
                `UPDATE barang 
                 SET qty_stok = qty_stok + $1, updated_at = NOW()
                 WHERE id_barang = $2`,
                [stockChange, itemData.id_barang]
            );

            const updatedStock = await client.query(
                'SELECT qty_stok FROM barang WHERE id_barang = $1',
                [itemData.id_barang]
            );
            console.log('[Model] ✅ New stock for', baseCode, ':', updatedStock.rows[0].qty_stok);

            // ✅ Master Gudang Integration
            if (jenis_transaksi === 'Receiving') {
                console.log('[Model] ✅ Receiving: Inserting to master_gudang');
                
                // ✅ PENTING: Kolom "status" di tabel gudang = untuk "New" atau "Second"
                const gudangStatus = status_barang || 'New'; // ✅ Ambil dari status_barang (bukan asset_state!)
                
                console.log('[Model]    Gudang status (New/Second):', gudangStatus);
                
                await client.query(`
                    INSERT INTO gudang (
                        id_gudang, kode_barang, nama_barang, jenis_barang, 
                        spesifikasi, status, lokasi, tanggal
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                `, [
                    uuidv4(),
                    kode_barang.toUpperCase(),
                    itemData.nama_barang,
                    itemData.jenis_barang,
                    itemData.spesifikasi,
                    gudangStatus, // ✅ INI YANG BENAR: "New" atau "Second"
                    lokasi,
                    tanggal || new Date()
                ]);

                console.log('[Model] ✅ Item added to master_gudang with status:', gudangStatus);

            } else if (jenis_transaksi === 'Assignment') {
                console.log('[Model] ✅ Assignment: Stock reduced, NOT touching master_gudang');
                
            } else if (jenis_transaksi === 'Disposal') {
                console.log('[Model] ✅ Disposal: Deleting from master_gudang');
                
                await client.query(`
                    DELETE FROM gudang WHERE UPPER(kode_barang) = $1
                `, [kode_barang.toUpperCase()]);
                
                console.log('[Model] ✅ Item removed from master_gudang');
            }

            await client.query('COMMIT');
            console.log('[Model] ✅ Transaction committed successfully');
            console.log('[Model] ============================================');
            
            return txResult.rows[0];

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[TransaksiModel] ❌ Create error:', error.message);
            console.error('[TransaksiModel] Stack:', error.stack);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Update transaction - FIXED */
    static async update(id, txData, updatedBy = null) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');

            const { qty_stok, lokasi, npk, nama_employee, keterangan, asset_state, status, old_qty } = txData;

            const currentTx = await client.query(
                'SELECT * FROM transaksi WHERE id_transaksi = $1 AND deleted_at IS NULL',
                [id]
            );

            if (currentTx.rows.length === 0) {
                throw new Error('Transaction not found');
            }

            const tx = currentTx.rows[0];
            const oldQty = old_qty || tx.qty_stok;
            const newQty = qty_stok || tx.qty_stok;
            const qtyDiff = newQty - oldQty;

            console.log('[Model] Update - Old Qty:', oldQty, 'New Qty:', newQty, 'Diff:', qtyDiff);

            const updateSql = `
                UPDATE transaksi 
                SET 
                    qty_stok = COALESCE($1, qty_stok),
                    lokasi = COALESCE($2, lokasi),
                    npk = COALESCE($3, npk),
                    nama_employee = COALESCE($4, nama_employee),
                    keterangan = COALESCE($5, keterangan),
                    asset_state = COALESCE($6, asset_state),
                    status = COALESCE($6, status),
                    updated_at = NOW(),
                    updated_by = $7
                WHERE id_transaksi = $8 AND deleted_at IS NULL
                RETURNING *;
            `;

            const result = await client.query(updateSql, [
                newQty,
                lokasi,
                npk,
                nama_employee,
                keterangan,
                asset_state || status,
                updatedBy,
                id
            ]);

            if (qtyDiff !== 0) {
                const stockAdjust = tx.jenis_transaksi === 'Receiving' ? qtyDiff : -qtyDiff;
                
                console.log('[Model] Adjusting stock by:', stockAdjust);
                
                await client.query(
                    `UPDATE barang 
                     SET qty_stok = qty_stok + $1, updated_at = NOW()
                     WHERE id_barang = $2`,
                    [stockAdjust, tx.id_barang]
                );
            }

            // ✅ Update master_gudang HANYA untuk Receiving
            if (tx.jenis_transaksi === 'Receiving' && lokasi && lokasi !== tx.lokasi) {
                console.log('[Model] Updating master_gudang location (Receiving only)');
                await client.query(
                    `UPDATE gudang SET lokasi = $1, tanggal = NOW() WHERE kode_barang = $2`,
                    [lokasi, tx.kode_barang]
                );
            }

            await client.query('COMMIT');
            return result.rows[0];

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[TransaksiModel] Update error:', error);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Delete transaction - FIXED */
    static async delete(id) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');

            const txResult = await client.query(
                'SELECT * FROM transaksi WHERE id_transaksi = $1',
                [id]
            );

            if (txResult.rows.length === 0) {
                throw new Error('Transaction not found');
            }

            const tx = txResult.rows[0];
            console.log('[Model] Deleting transaction:', tx.kode_transaksi);

            const stockReverse = tx.jenis_transaksi === 'Receiving' ? -tx.qty_stok : tx.qty_stok;
            
            console.log('[Model] Reversing stock by:', stockReverse);
            
            await client.query(
                `UPDATE barang 
                 SET qty_stok = qty_stok + $1, updated_at = NOW()
                 WHERE id_barang = $2`,
                [stockReverse, tx.id_barang]
            );

            if (tx.jenis_transaksi === 'Receiving') {
                console.log('[Model] Removing from master_gudang');
                await client.query('DELETE FROM gudang WHERE kode_barang = $1', [tx.kode_barang]);
            } else if (tx.jenis_transaksi === 'Disposal') {
                console.log('[Model] Restoring to master_gudang');
                const itemResult = await client.query(
                    'SELECT * FROM barang WHERE id_barang = $1',
                    [tx.id_barang]
                );
                
                if (itemResult.rows.length > 0) {
                    const item = itemResult.rows[0];
                    await client.query(`
                        INSERT INTO gudang (
                            id_gudang, kode_barang, nama_barang, jenis_barang, 
                            spesifikasi, status, lokasi, tanggal
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                    `, [
                        uuidv4(),
                        tx.kode_barang,
                        item.nama_barang,
                        item.jenis_barang,
                        item.spesifikasi,
                        'Second', // ✅ Default status saat restore
                        'Warehouse IT',
                        new Date()
                    ]);
                }
            }

            const deleteSql = `DELETE FROM transaksi WHERE id_transaksi = $1 RETURNING *;`;
            const result = await client.query(deleteSql, [id]);

            await client.query('COMMIT');
            return result.rows[0];

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[TransaksiModel] Delete error:', error);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Search transactions */
    static async search(keyword) {
        const sql = `
            SELECT 
                t.*,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi
            FROM transaksi t
            LEFT JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.deleted_at IS NULL
                AND (
                    t.kode_transaksi ILIKE $1 OR
                    t.kode_barang ILIKE $1 OR
                    t.nama_barang ILIKE $1 OR
                    t.jenis_barang ILIKE $1 OR
                    t.nama_employee ILIKE $1 OR
                    t.lokasi ILIKE $1 OR
                    t.keterangan ILIKE $1
                )
            ORDER BY t.created_at DESC;
        `;

        const searchPattern = `%${keyword}%`;
        return (await query(sql, [searchPattern])).rows;
    }

    /** Get dashboard summary */
    static async getDashboardSummary() {
        const sql = `
            SELECT
                COUNT(*) AS total_transactions,
                COUNT(*) FILTER (WHERE jenis_transaksi = 'Receiving') AS total_receiving,
                COUNT(*) FILTER (WHERE jenis_transaksi = 'Assignment') AS total_assignment,
                COUNT(*) FILTER (WHERE jenis_transaksi = 'Disposal') AS total_disposal,
                SUM(qty_stok) FILTER (WHERE jenis_transaksi = 'Receiving') as total_items_in,
                SUM(qty_stok) FILTER (WHERE jenis_transaksi = 'Assignment') as total_items_assigned,
                SUM(qty_stok) FILTER (WHERE jenis_transaksi = 'Disposal') as total_items_disposed
            FROM transaksi
            WHERE deleted_at IS NULL 
                AND created_at > NOW() - INTERVAL '30 days';
        `;
        return (await query(sql)).rows[0];
    }

    /** Get recent activities */
    static async getRecentActivities(limit = 10) {
        const sql = `
            SELECT 
                t.kode_transaksi,
                t.jenis_transaksi, 
                t.created_at, 
                t.qty_stok,
                t.nama_barang,
                t.kode_barang,
                t.nama_employee
            FROM transaksi t
            WHERE t.deleted_at IS NULL
            ORDER BY t.created_at DESC
            LIMIT $1;
        `;
        return (await query(sql, [limit])).rows;
    }

    /** Get all items sorted by stock */
    static async getAllSorted(order = 'DESC') {
        const orderDirection = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE deleted_at IS NULL 
            ORDER BY qty_stok ${orderDirection}, nama_barang ASC;
        `;
        return (await query(sql)).rows;
    }

    /** Extract base code from full code */
    static getBaseCode(fullCode) {
        if (!fullCode || typeof fullCode !== 'string') return fullCode;
        return fullCode.split('-')[0]; // NB132-12 → NB132
    }

    /** Check if base code exists */
    static async baseCodeExists(baseCode) {
        const sql = `
            SELECT id_barang 
            FROM barang 
            WHERE kode_barang = $1 AND deleted_at IS NULL 
            LIMIT 1;
        `;
        const result = await query(sql, [baseCode]);
        return result.rows.length > 0;
    }

    /** Get item by base code */
    static async getByBaseCode(baseCode) {
        const sql = `
            SELECT 
                id_barang, 
                kode_barang, 
                nama_barang, 
                jenis_barang, 
                spesifikasi, 
                qty_stok, 
                min_qty
            FROM barang 
            WHERE kode_barang = $1 AND deleted_at IS NULL;
        `;
        const result = await query(sql, [baseCode]);
        return result.rows[0];
    }

}

module.exports = TransaksiModel;