const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const ListBarangModel = require('./listBarangModel');

class TransaksiModel {

    /** Generate next transaction code */
    static async generateNextCode(prefix) {
        const sql = `SELECT get_next_transaction_code($1) as next_code;`;
        const result = await query(sql, [prefix]);
        return result.rows[0].next_code;
    }

    /** Get all transactions */
    static async getAll() {
        const sql = `
            SELECT 
                t.*,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi
            FROM transaksi t
            LEFT JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.deleted_at IS NULL
            ORDER BY t.created_at DESC;
        `;
        return (await query(sql)).rows;
    }

    /** Get transaction by ID */
    static async getById(id) {
        const sql = `
            SELECT 
                t.*,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi
            FROM transaksi t
            LEFT JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.id_transaksi = $1 AND t.deleted_at IS NULL;
        `;
        const result = await query(sql, [id]);
        return result.rows[0];
    }

    /** ✅ CREATE TRANSACTION - WITH AUTO-GENERATE SERIAL NUMBERS */
    static async create(txData, createdBy = null) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');

            // gunakan let supaya bisa diubah nilainya (fix error Assignment to constant variable)
            let { 
                kode_transaksi,
                jenis_transaksi, 
                kode_barang, // Could be base code (NB157) OR full code (NB157-14)
                qty_stok = 1,
                status,
                asset_state,
                npk,
                nama_employee,
                lokasi,
                id_gudang,
                keterangan,
                tanggal,
                status_barang // New/Second for Receiving
            } = txData;

            console.log('[Model] ============ CREATE TRANSACTION ============');
            console.log('[Model] Jenis:', jenis_transaksi);
            console.log('[Model] Input kode_barang:', kode_barang);
            console.log('[Model] Qty:', qty_stok);

            if (!kode_transaksi || !jenis_transaksi || !kode_barang) {
                throw new Error('Missing required fields');
            }

            // ========================================
            // RECEIVING LOGIC
            // ========================================
            if (jenis_transaksi === 'Receiving') {
                // Extract base code (NB157 from NB157 or NB157-14)
                kode_barang = kode_barang.split('-')[0].toUpperCase();
                console.log('[Model] 📥 RECEIVING - Base code:', kode_barang);

                // Get base item from master data
                const itemResult = await client.query(
                    'SELECT * FROM barang WHERE UPPER(kode_barang) = $1 AND deleted_at IS NULL',
                    [kode_barang]
                );

                if (itemResult.rows.length === 0) {
                    throw new Error(`kode item "${kode_barang}" not found in Master Data. Please create it first.`);
                }

                const itemData = itemResult.rows[0];
                console.log('[Model] ✅ Base item found:', itemData.kode_barang);

                // Get next serial number
                const nextSerial = await ListBarangModel.getNextSerialNumber(kode_barang);
                console.log('[Model] 🔢 Next serial starts at:', nextSerial);

                // Generate serial numbers
                const serialsToCreate = [];
                for (let i = 0; i < qty_stok; i++) {
                    const serialNum = nextSerial + i;
                    const fullCode = `${kode_barang}-${serialNum}`;
                    
                    serialsToCreate.push({
                        id_barang: itemData.id_barang,
                        base_code: kode_barang,
                        serial_number: serialNum,
                        kode_barang: fullCode,
                        nama_barang: itemData.nama_barang,
                        jenis_barang: itemData.jenis_barang,
                        spesifikasi: itemData.spesifikasi,
                        asset_state: 'In Store',
                        status: status_barang || 'New',
                        lokasi: lokasi,
                        id_transaksi_masuk: null // Will be set after transaction insert
                    });
                }

                console.log('[Model] 📋 Generated serials:', serialsToCreate.map(s => s.kode_barang).join(', '));

                // Insert transaction
                const txSql = `
                    INSERT INTO transaksi (
                        id_transaksi, kode_transaksi, jenis_transaksi, 
                        id_barang, kode_barang, nama_barang, jenis_barang, spesifikasi,
                        qty_stok, status, asset_state, npk, nama_employee, 
                        lokasi, id_gudang, keterangan, tanggal, created_by
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
                    RETURNING *;
                `;

                const txResult = await client.query(txSql, [
                    uuidv4(),
                    kode_transaksi,
                    jenis_transaksi,
                    itemData.id_barang,
                    kode_barang, // Store base code in transaction
                    itemData.nama_barang,
                    itemData.jenis_barang,
                    itemData.spesifikasi,
                    qty_stok,
                    'In Store',
                    'In Store',
                    null,
                    null,
                    lokasi,
                    id_gudang,
                    keterangan,
                    tanggal || new Date(),
                    createdBy
                ]);

                const transactionId = txResult.rows[0].id_transaksi;

                // Update serials with transaction ID
                serialsToCreate.forEach(s => s.id_transaksi_masuk = transactionId);

                // Insert to list_barang
                await ListBarangModel.createBulk(serialsToCreate);
                console.log('[Model] ✅ Inserted', qty_stok, 'items to list_barang');

                // Update master barang stock
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok + $1, updated_at = NOW() WHERE id_barang = $2`,
                    [qty_stok, itemData.id_barang]
                );

                console.log('[Model] ✅ Updated master stock +', qty_stok);

                await client.query('COMMIT');
                console.log('[Model] ✅ RECEIVING completed successfully');
                return txResult.rows[0];
            }

            // ========================================
            // ASSIGNMENT LOGIC
            // ========================================
            if (jenis_transaksi === 'Assignment') {
                const fullCode = kode_barang.trim().toUpperCase();
                console.log('[Model] 👤 ASSIGNMENT - Full code:', fullCode);

                // Check if item exists and available
                const listItem = await ListBarangModel.isAvailableForAssignment(fullCode);
                
                if (!listItem) {
                    throw new Error(`Item "${fullCode}" not found or already assigned/disposed`);
                }

                console.log('[Model] ✅ Item available:', listItem.kode_barang);

                // Validate NPK (must be 5 digits)
                if (!npk || npk.length !== 5) {
                    throw new Error('NPK must be exactly 5 digits');
                }

                // Get base item info
                const baseItem = await client.query(
                    'SELECT * FROM barang WHERE id_barang = $1',
                    [listItem.id_barang]
                );

                if (baseItem.rows.length === 0) {
                    throw new Error('Base item not found');
                }

                const itemData = baseItem.rows[0];

                // Insert transaction
                const txSql = `
                    INSERT INTO transaksi (
                        id_transaksi, kode_transaksi, jenis_transaksi, 
                        id_barang, kode_barang, nama_barang, jenis_barang, spesifikasi,
                        qty_stok, status, asset_state, npk, nama_employee, 
                        lokasi, id_gudang, keterangan, tanggal, created_by
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
                    RETURNING *;
                `;

                const txResult = await client.query(txSql, [
                    uuidv4(),
                    kode_transaksi,
                    jenis_transaksi,
                    itemData.id_barang,
                    fullCode, // Full serial code
                    itemData.nama_barang,
                    itemData.jenis_barang,
                    itemData.spesifikasi,
                    1, // Always 1 for assignment
                    'In Use',
                    'In Use',
                    npk,
                    nama_employee,
                    lokasi,
                    id_gudang,
                    keterangan,
                    tanggal || new Date(),
                    createdBy
                ]);

                const transactionId = txResult.rows[0].id_transaksi;

                // Update list_barang
                await ListBarangModel.updateForAssignment(fullCode, {
                    asset_state: 'In Use',
                    npk: npk,
                    nama_employee: nama_employee,
                    lokasi: lokasi,
                    id_transaksi_keluar: transactionId
                });

                console.log('[Model] ✅ Updated list_barang status to In Use');

                // Update master barang stock
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok - 1, updated_at = NOW() WHERE id_barang = $1`,
                    [itemData.id_barang]
                );

                console.log('[Model] ✅ Updated master stock -1');

                await client.query('COMMIT');
                console.log('[Model] ✅ ASSIGNMENT completed successfully');
                return txResult.rows[0];
            }

            // ========================================
            // DISPOSAL LOGIC
            // ========================================
            if (jenis_transaksi === 'Disposal') {
                const fullCode = kode_barang.trim().toUpperCase();
                console.log('[Model] 🗑️ DISPOSAL - Full code:', fullCode);

                // Check if item exists
                const listItem = await ListBarangModel.getByKode(fullCode);
                
                if (!listItem) {
                    throw new Error(`Item "${fullCode}" not found in list barang`);
                }

                console.log('[Model] ✅ Item found:', listItem.kode_barang);

                // Get base item info
                const baseItem = await client.query(
                    'SELECT * FROM barang WHERE id_barang = $1',
                    [listItem.id_barang]
                );

                if (baseItem.rows.length === 0) {
                    throw new Error('Base item not found');
                }

                const itemData = baseItem.rows[0];

                // Determine disposal state
                const disposalState = asset_state || status || 'Disposal';

                // Insert transaction
                const txSql = `
                    INSERT INTO transaksi (
                        id_transaksi, kode_transaksi, jenis_transaksi, 
                        id_barang, kode_barang, nama_barang, jenis_barang, spesifikasi,
                        qty_stok, status, asset_state, npk, nama_employee, 
                        lokasi, id_gudang, keterangan, tanggal, created_by
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
                    RETURNING *;
                `;

                const txResult = await client.query(txSql, [
                    uuidv4(),
                    kode_transaksi,
                    jenis_transaksi,
                    itemData.id_barang,
                    fullCode, // Full serial code
                    itemData.nama_barang,
                    itemData.jenis_barang,
                    itemData.spesifikasi,
                    1, // Always 1 for disposal
                    disposalState,
                    disposalState,
                    null,
                    null,
                    'P2B',
                    id_gudang,
                    keterangan,
                    tanggal || new Date(),
                    createdBy
                ]);

                // Delete from list_barang
                await ListBarangModel.delete(fullCode);
                console.log('[Model] ✅ Deleted from list_barang');

                // Update master barang stock
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok - 1, updated_at = NOW() WHERE id_barang = $1`,
                    [itemData.id_barang]
                );

                console.log('[Model] ✅ Updated master stock -1');

                await client.query('COMMIT');
                console.log('[Model] ✅ DISPOSAL completed successfully');
                return txResult.rows[0];
            }

            throw new Error('Invalid transaction type');

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[TransaksiModel] ❌ Create error:', error.message);
            console.error('[TransaksiModel] Stack:', error.stack);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Update transaction */
    static async update(id, txData, updatedBy = null) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');

            const { qty_stok, lokasi, npk, nama_employee, keterangan, asset_state, status, old_qty } = txData;

            const currentTx = await client.query(
                'SELECT * FROM transaksi WHERE id_transaksi = $1 AND deleted_at IS NULL',
                [id]
            );

            if (currentTx.rows.length === 0) {
                throw new Error('Transaction not found');
            }

            const tx = currentTx.rows[0];
            const oldQty = old_qty || tx.qty_stok;
            const newQty = qty_stok || tx.qty_stok;
            const qtyDiff = newQty - oldQty;

            console.log('[Model] Update - Old Qty:', oldQty, 'New Qty:', newQty, 'Diff:', qtyDiff);

            const updateSql = `
                UPDATE transaksi 
                SET 
                    qty_stok = COALESCE($1, qty_stok),
                    lokasi = COALESCE($2, lokasi),
                    npk = COALESCE($3, npk),
                    nama_employee = COALESCE($4, nama_employee),
                    keterangan = COALESCE($5, keterangan),
                    asset_state = COALESCE($6, asset_state),
                    status = COALESCE($6, status),
                    updated_at = NOW(),
                    updated_by = $7
                WHERE id_transaksi = $8 AND deleted_at IS NULL
                RETURNING *;
            `;

            const result = await client.query(updateSql, [
                newQty,
                lokasi,
                npk,
                nama_employee,
                keterangan,
                asset_state || status,
                updatedBy,
                id
            ]);

            // Update stock if qty changed
            if (qtyDiff !== 0 && tx.jenis_transaksi === 'Receiving') {
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok + $1, updated_at = NOW() WHERE id_barang = $2`,
                    [qtyDiff, tx.id_barang]
                );
            }

            // Update list_barang for Assignment
            if (tx.jenis_transaksi === 'Assignment') {
                await client.query(
                    `UPDATE list_barang SET lokasi = $1, npk = $2, nama_employee = $3, updated_at = NOW() WHERE kode_barang = $4`,
                    [lokasi || tx.lokasi, npk || tx.npk, nama_employee || tx.nama_employee, tx.kode_barang]
                );
            }

            await client.query('COMMIT');
            return result.rows[0];

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[TransaksiModel] Update error:', error);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Delete transaction */
    static async delete(id) {
        const client = await getClient();
        
        try {
            await client.query('BEGIN');

            const txResult = await client.query(
                'SELECT * FROM transaksi WHERE id_transaksi = $1',
                [id]
            );

            if (txResult.rows.length === 0) {
                throw new Error('Transaction not found');
            }

            const tx = txResult.rows[0];
            console.log('[Model] Deleting transaction:', tx.kode_transaksi);

            // Reverse stock for Receiving
            if (tx.jenis_transaksi === 'Receiving') {
                // Delete all serials from list_barang
                await client.query(
                    'DELETE FROM list_barang WHERE id_transaksi_masuk = $1',
                    [id]
                );
                
                // Update master stock
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok - $1, updated_at = NOW() WHERE id_barang = $2`,
                    [tx.qty_stok, tx.id_barang]
                );
            }

            // Reverse Assignment
            if (tx.jenis_transaksi === 'Assignment') {
                // Restore item to In Store
                await client.query(
                    `UPDATE list_barang SET asset_state = 'In Store', npk = NULL, nama_employee = NULL, id_transaksi_keluar = NULL WHERE kode_barang = $1`,
                    [tx.kode_barang]
                );
                
                // Update master stock
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok + 1, updated_at = NOW() WHERE id_barang = $1`,
                    [tx.id_barang]
                );
            }

            // Reverse Disposal
            if (tx.jenis_transaksi === 'Disposal') {
                // Restore to list_barang
                const itemResult = await client.query(
                    'SELECT * FROM barang WHERE id_barang = $1',
                    [tx.id_barang]
                );
                
                if (itemResult.rows.length > 0) {
                    const item = itemResult.rows[0];
                    const [kode_barang, serialStr] = tx.kode_barang.split('-');
                    
                    await client.query(`
                        INSERT INTO list_barang (
                            id_list_barang, id_barang, base_code, serial_number, kode_barang,
                            nama_barang, jenis_barang, spesifikasi, asset_state, status, lokasi
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                    `, [
                        uuidv4(),
                        item.id_barang,
                        kode_barang,
                        parseInt(serialStr) || 0,
                        tx.kode_barang,
                        item.nama_barang,
                        item.jenis_barang,
                        item.spesifikasi,
                        'In Store',
                        'Second',
                        'Warehouse IT'
                    ]);
                }
                
                // Update master stock
                await client.query(
                    `UPDATE barang SET qty_stok = qty_stok + 1, updated_at = NOW() WHERE id_barang = $1`,
                    [tx.id_barang]
                );
            }

            // Delete transaction
            const deleteSql = `DELETE FROM transaksi WHERE id_transaksi = $1 RETURNING *;`;
            const result = await client.query(deleteSql, [id]);

            await client.query('COMMIT');
            return result.rows[0];

        } catch (error) {
            await client.query('ROLLBACK');
            console.error('[TransaksiModel] Delete error:', error);
            throw error;
        } finally {
            client.release();
        }
    }

    /** Search transactions */
    static async search(keyword) {
        const sql = `
            SELECT 
                t.*,
                b.nama_barang,
                b.jenis_barang,
                b.spesifikasi
            FROM transaksi t
            LEFT JOIN barang b ON t.id_barang = b.id_barang
            WHERE t.deleted_at IS NULL
                AND (
                    t.kode_transaksi ILIKE $1 OR
                    t.kode_barang ILIKE $1 OR
                    t.nama_barang ILIKE $1 OR
                    t.jenis_barang ILIKE $1 OR
                    t.nama_employee ILIKE $1 OR
                    t.lokasi ILIKE $1 OR
                    t.keterangan ILIKE $1
                )
            ORDER BY t.created_at DESC;
        `;

        const searchPattern = `%${keyword}%`;
        return (await query(sql, [searchPattern])).rows;
    }

    /** Get dashboard summary */
    static async getDashboardSummary() {
        const sql = `
            SELECT
                COUNT(*) AS total_transactions,
                COUNT(*) FILTER (WHERE jenis_transaksi = 'Receiving') AS total_receiving,
                COUNT(*) FILTER (WHERE jenis_transaksi = 'Assignment') AS total_assignment,
                COUNT(*) FILTER (WHERE jenis_transaksi = 'Disposal') AS total_disposal,
                SUM(qty_stok) FILTER (WHERE jenis_transaksi = 'Receiving') as total_items_in,
                SUM(qty_stok) FILTER (WHERE jenis_transaksi = 'Assignment') as total_items_assigned,
                SUM(qty_stok) FILTER (WHERE jenis_transaksi = 'Disposal') as total_items_disposed
            FROM transaksi
            WHERE deleted_at IS NULL 
                AND created_at > NOW() - INTERVAL '30 days';
        `;
        return (await query(sql)).rows[0];
    }

    /** Get recent activities */
    static async getRecentActivities(limit = 10) {
        const sql = `
            SELECT 
                t.kode_transaksi,
                t.jenis_transaksi, 
                t.created_at, 
                t.qty_stok,
                t.nama_barang,
                t.kode_barang,
                t.nama_employee
            FROM transaksi t
            WHERE t.deleted_at IS NULL
            ORDER BY t.created_at DESC
            LIMIT $1;
        `;
        return (await query(sql, [limit])).rows;
    }

}

module.exports = TransaksiModel;