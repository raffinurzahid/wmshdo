const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class RoleModel {

    /** Membuat peran baru. */
    static async create(roleData, createdBy) {
        const { nama_role, deskripsi } = roleData;
        const sql = `
            INSERT INTO role (id_role, nama_role, deskripsi, created_by)
            VALUES ($1, $2, $3, $4) RETURNING *;
        `;
        try {
            const result = await query(sql, [uuidv4(), nama_role, deskripsi, createdBy]);
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') throw new Error('Nama peran sudah ada.');
            throw error;
        }
    }

    /** Mengambil semua peran yang aktif. */
    static async getAll() {
        const sql = `SELECT * FROM role WHERE deleted_at IS NULL ORDER BY nama_role;`;
        return (await query(sql)).rows;
    }

    /** Mencari satu peran berdasarkan ID. */
    static async getById(id) {
        const sql = `SELECT * FROM role WHERE id_role = $1 AND deleted_at IS NULL;`;
        return (await query(sql, [id])).rows[0];
    }

    /** Memperbarui data peran. */
    static async update(id, roleData, updatedBy) {
        const { nama_role, deskripsi } = roleData;
        const sql = `
            UPDATE role SET nama_role = $1, deskripsi = $2, updated_at = NOW(), updated_by = $3
            WHERE id_role = $4 AND deleted_at IS NULL RETURNING *;
        `;
        try {
            const result = await query(sql, [nama_role, deskripsi, updatedBy, id]);
            if (result.rows.length === 0) throw new Error('Peran tidak ditemukan.');
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') throw new Error('Nama peran sudah ada.');
            throw error;
        }
    }

    /** Menghapus peran secara permanen (hard delete). */
    static async delete(id) {
        // Cek dulu apakah ada user yang masih menggunakan peran ini
        const checkUserSql = `SELECT COUNT(*) FROM "user" WHERE id_role = $1 AND deleted_at IS NULL;`;
        const userCheck = await query(checkUserSql, [id]);
        if (parseInt(userCheck.rows[0].count) > 0) {
            throw new Error(`Tidak bisa menghapus peran. Masih ada ${userCheck.rows[0].count} user aktif yang menggunakan peran ini.`);
        }
        
        const sql = `DELETE FROM role WHERE id_role = $1 RETURNING *;`;
        const result = await query(sql, [id]);
        if (result.rows.length === 0) throw new Error('Peran tidak ditemukan.');
        return result.rows[0];
    }
    
    /** Menghapus peran secara sementara (soft delete). */
    static async softDelete(id, deletedBy) {
        // Cek dulu apakah ada user yang masih menggunakan peran ini
        const checkUserSql = `SELECT COUNT(*) FROM "user" WHERE id_role = $1 AND deleted_at IS NULL;`;
        const userCheck = await query(checkUserSql, [id]);
        if (parseInt(userCheck.rows[0].count) > 0) {
            throw new Error(`Tidak bisa menghapus peran. Masih ada ${userCheck.rows[0].count} user aktif yang menggunakan peran ini.`);
        }

        const sql = `
            UPDATE role SET deleted_at = NOW(), deleted_by = $2
            WHERE id_role = $1 AND deleted_at IS NULL RETURNING *;
        `;
        const result = await query(sql, [id, deletedBy]);
        if (result.rows.length === 0) throw new Error('Peran tidak ditemukan.');
        return result.rows[0];
    }

    /** Mengembalikan peran yang sudah di-soft delete. */
    static async restore(id) {
        const sql = `UPDATE role SET deleted_at = NULL, deleted_by = NULL WHERE id_role = $1 RETURNING *;`;
        const result = await query(sql, [id]);
        if (result.rows.length === 0) throw new Error('Peran tidak ditemukan atau tidak dalam kondisi terhapus.');
        return result.rows[0];
    }
    
    /** Mengambil semua user yang memiliki peran tertentu. */
    static async getUsersByRole(roleId) {
        const sql = `
            SELECT id_user, username, email FROM "user" 
            WHERE id_role = $1 AND deleted_at IS NULL ORDER BY username;
        `;
        return (await query(sql, [roleId])).rows;
    }

    /** Mencari peran berdasarkan nama. */
    static async search(searchTerm) {
        const sql = `SELECT * FROM role WHERE nama_role ILIKE $1 AND deleted_at IS NULL ORDER BY nama_role;`;
        return (await query(sql, [`%${searchTerm}%`])).rows;
    }
    
    /** Mengambil statistik peran. */
    static async getStats() {
        const sql = `
            SELECT
                COUNT(*) AS total_roles,
                (SELECT COUNT(*) FROM "user" WHERE deleted_at IS NULL) as total_users
            FROM role WHERE deleted_at IS NULL;
        `;
        return (await query(sql)).rows[0];
    }
}

module.exports = RoleModel;