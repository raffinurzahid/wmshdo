const BarangModel = require('../models/barangModel');

const handleError = (res, error, context) => {
    console.error(`[Error ${context}]:`, error.message);
    
    if (error.message.includes('sudah terdaftar') || error.message.includes('sudah ada')) {
        return res.status(409).json({ success: false, message: error.message });
    }
    if (error.message.includes('tidak ditemukan')) {
        return res.status(404).json({ success: false, message: error.message });
    }
    if (error.message.includes('tidak boleh') || error.message.includes('maksimal')) {
        return res.status(400).json({ success: false, message: error.message });
    }
    res.status(500).json({ success: false, message: `Gagal ${context}`, error: error.message });
};

class BarangController {

    /** [GET] Mengambil semua data barang */
    static async getAllItems(req, res) {
        try {
            console.log('[GET] /api/master-barang - Fetch all items');
            const items = await BarangModel.getAll();
            res.status(200).json({ success: true, data: items });
        } catch (error) {
            handleError(res, error, 'mengambil semua barang');
        }
    }

    /** [GET] Mengambil satu barang berdasarkan ID */
    static async getItemById(req, res) {
        try {
            const { id } = req.params;
            console.log(`[GET] /api/master-barang/${id} - Fetch item by ID`);
            
            const item = await BarangModel.getById(id);
            if (!item) {
                return res.status(404).json({ success: false, message: 'Barang tidak ditemukan.' });
            }
            res.status(200).json({ success: true, data: item });
        } catch (error) {
            handleError(res, error, `mengambil barang dengan ID: ${req.params.id}`);
        }
    }

    /** [POST] Membuat barang baru (Admin only) */
    static async createItem(req, res) {
        try {
            console.log('[POST] /api/master-barang - Create new item');
            console.log('Body:', req.body);
            
            const createdBy = req.user?.id_user || null;
            const newItem = await BarangModel.create(req.body, createdBy);
            
            res.status(201).json({ 
                success: true, 
                message: 'Barang berhasil dibuat.', 
                data: newItem 
            });
        } catch (error) {
            handleError(res, error, 'membuat barang');
        }
    }

    /** [PUT] Memperbarui data barang (Admin only) */
    static async updateItem(req, res) {
        try {
            const { id } = req.params;
            console.log(`[PUT] /api/master-barang/${id} - Update item`);
            console.log('Body:', req.body);
            
            const updatedBy = req.user?.id_user || null;
            const updatedItem = await BarangModel.update(id, req.body, updatedBy);
            
            res.status(200).json({ 
                success: true, 
                message: 'Barang berhasil diperbarui.', 
                data: updatedItem 
            });
        } catch (error) {
            handleError(res, error, 'memperbarui barang');
        }
    }

    /** [DELETE] Menghapus barang (Admin only) */
    static async deleteItem(req, res) {
        try {
            const { id } = req.params;
            console.log(`[DELETE] /api/master-barang/${id} - Delete item`);
            
            const deletedBy = req.user?.id_user || null;
            const deletedItem = await BarangModel.softDelete(id, deletedBy);
            
            res.status(200).json({ 
                success: true, 
                message: 'Barang berhasil dihapus.', 
                data: deletedItem 
            });
        } catch (error) {
            handleError(res, error, 'menghapus barang');
        }
    }

    /** [GET] Mencari barang berdasarkan keyword */
    static async searchItems(req, res) {
        try {
            const { q } = req.query;
            console.log('[GET] /api/master-barang/search - Search items with query:', q);
            
            if (!q || q.trim().length === 0) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Query pencarian (q) tidak boleh kosong.' 
                });
            }
            
            const items = await BarangModel.search(q);
            res.status(200).json({ success: true, data: items });
        } catch (error) {
            handleError(res, error, 'mencari barang');
        }
    }

    /** [GET] Sort items by stock */
    static async sortByStock(req, res) {
        try {
            const { order = 'DESC' } = req.query;
            console.log(`[GET] /api/master-barang/sort-by-stock?order=${order}`);
            
            const items = await BarangModel.getAllSorted(order);
            res.status(200).json({ 
                success: true, 
                data: items,
                sorted: order.toUpperCase() === 'ASC' ? 'Lowest First' : 'Highest First'
            });
        } catch (error) {
            handleError(res, error, 'sorting barang by stock');
        }
    }

    /** [GET] Download CSV template */
    static async downloadTemplate(req, res) {
        try {
            console.log('[GET] /api/master-barang/download-template');
            
            // Template WITHOUT Qty Stok (auto 0 on create)
            const csvContent = 'Kode Barang,Nama Barang,Jenis Barang,Spesifikasi,Min Qty';
            
            res.setHeader('Content-Type', 'text/csv;charset=utf-8');
            res.setHeader('Content-Disposition', 'attachment; filename=master_barang_template.csv');
            res.status(200).send(csvContent);
        } catch (error) {
            handleError(res, error, 'download template');
        }
    }

    /** [GET] Check if base code exists */
    static async checkBaseCode(req, res) {
        try {
            const { baseCode } = req.params;
            const upperBaseCode = baseCode.toUpperCase();
            console.log(`[GET] /api/master-barang/check-base/${upperBaseCode}`);
        
            const exists = await BarangModel.baseCodeExists(upperBaseCode);
        
            if (exists) {
                const item = await BarangModel.getByBaseCode(upperBaseCode);
                res.status(200).json({ 
                    success: true, 
                    exists: true,
                    data: item
                });
            } else {
                res.status(404).json({ 
                    success: false, 
                    exists: false,
                    message: `Base code ${upperBaseCode} tidak ditemukan di Master Data.`
                });
            }
        } catch (error) {
            handleError(res, error, 'check base code');
        }
    }

}

module.exports = BarangController;