const { query } = require('../config/db');

class MasterGudangController {
    
    /**
     * [FIXED] Mengambil data inventaris langsung dari tabel 'gudang'.
     * Tabel ini sudah berisi data inventaris real-time sesuai logika di transaksiModel.js.
     */
    static async getInventory(req, res) {
        try {
            console.log('[MasterGudang] Fetching inventory from "gudang" table...');
            
            // ✅ QUERY YANG BENAR: Langsung ambil dari tabel 'gudang'
            const sql = `
                SELECT 
                    kode_barang,
                    nama_barang,
                    jenis_barang,
                    spesifikasi,
                    status,
                    lokasi,
                    tanggal
                FROM gudang 
                ORDER BY tanggal DESC;
            `;
            
            const result = await query(sql);
            
            console.log(`[MasterGudang] ✅ Success! Total items fetched: ${result.rows.length}`);
            
            res.json({
                success: true,
                data: result.rows 
            });
            
        } catch (error) {
            console.error('[MasterGudang] ❌ Get Inventory Error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch inventory',
                error: error.message
            });
        }
    }

    /**
     * [FIXED] Mengambil inventaris berdasarkan lokasi dari tabel 'gudang'.
     */
    static async getInventoryByLocation(req, res) {
        try {
            const { lokasi } = req.query;
            
            if (!lokasi) {
                return res.status(400).json({
                    success: false,
                    message: 'Location parameter is required'
                });
            }
            
            console.log(`[MasterGudang] Fetching inventory for location: ${lokasi}`);
            
            // ✅ QUERY YANG BENAR: Filter berdasarkan lokasi di tabel 'gudang'
            const sql = `
                SELECT 
                    kode_barang,
                    nama_barang,
                    jenis_barang,
                    spesifikasi,
                    status,
                    lokasi,
                    tanggal
                FROM gudang
                WHERE lokasi ILIKE $1
                ORDER BY tanggal DESC;
            `;
            
            const result = await query(sql, [`%${lokasi}%`]);
            
            res.json({
                success: true,
                data: result.rows
            });
            
        } catch (error) {
            console.error('[MasterGudang] Get By Location Error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch inventory by location',
                error: error.message
            });
        }
    }

    /**
     * [FIXED] Mencari inventaris di dalam tabel 'gudang'.
     */
    static async searchInventory(req, res) {
        try {
            const { q } = req.query;
            
            if (!q || q.length < 2) {
                // Untuk konsistensi, kita kirim array kosong saja jika query pendek
                return res.json({ success: true, data: [] });
            }

            console.log(`[MasterGudang] Searching for: ${q}`);

            // ✅ QUERY YANG BENAR: Mencari di berbagai kolom di tabel 'gudang'
            const sql = `
                SELECT 
                    kode_barang,
                    nama_barang,
                    jenis_barang,
                    spesifikasi,
                    status,
                    lokasi,
                    tanggal
                FROM gudang
                WHERE 
                    kode_barang ILIKE $1 OR
                    nama_barang ILIKE $1 OR
                    jenis_barang ILIKE $1 OR
                    lokasi ILIKE $1 OR
                    spesifikasi ILIKE $1
                ORDER BY tanggal DESC;
            `;
            
            const searchPattern = `%${q}%`;
            const result = await query(sql, [searchPattern]);
            
            res.json({
                success: true,
                data: result.rows
            });
            
        } catch (error) {
            console.error('[MasterGudang] Search Error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to search inventory',
                error: error.message
            });
        }
    }
}

module.exports = MasterGudangController;