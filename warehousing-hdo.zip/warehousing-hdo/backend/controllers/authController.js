const jwt = require('jsonwebtoken');
const UserModel = require('../models/userModel');

// --- Konfigurasi JWT ---
const JWT_SECRET = process.env.JWT_SECRET || 'kunci-rahasia-yang-harus-sangat-aman-dan-diganti';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

/** Controller untuk proses login. */
const login = async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username dan password wajib diisi.' });
        }

        const user = await UserModel.getByUsername(username);
        if (!user) {
            return res.status(401).json({ success: false, message: 'Username atau password salah.' });
        }

        const isPasswordValid = await UserModel.verifyPassword(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ success: false, message: 'Username atau password salah.' });
        }

        const tokenPayload = { 
            id_user: user.id_user,
            username: user.username,
            role: user.nama_role
        };

        const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
        
        delete user.password;

        // 🔥 SET COOKIE DENGAN TOKEN
        res.cookie('token', token, {
            httpOnly: true,        // Tidak bisa diakses JavaScript (keamanan XSS)
            secure: process.env.NODE_ENV === 'production',  // HTTPS only di production
            sameSite: 'lax',       // CSRF protection
            maxAge: 24 * 60 * 60 * 1000  // 24 jam dalam milidetik
        });

        res.json({
            success: true,
            message: 'Login berhasil',
            data: {
                user: user,
                token,
                expiresIn: JWT_EXPIRES_IN
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, message: 'Terjadi kesalahan saat proses login.' });
    }
};

/** Controller untuk proses logout. */
const logout = (req, res) => {
    // 🔥 HAPUS COOKIE TOKEN
    res.clearCookie('token', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax'
    });
    
    res.json({ 
        success: true, 
        message: 'Logout berhasil.' 
    });
};

/** 
 * ✅ FIXED: Controller untuk mendapatkan data user yang sedang login.
 * Menambahkan field 'role' untuk memastikan frontend selalu dapat data role.
 */
const getCurrentUser = (req, res) => {
    // ✅ Enrich response dengan field 'role' yang konsisten
    const userData = {
        ...req.user,
        role: req.user.nama_role || req.user.role || 'User' // Fallback ke 'User' jika tidak ada
    };
    
    res.json({ 
        success: true, 
        data: userData 
    });
};

/** Controller untuk mengubah password. */
const changePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword, confirmPassword } = req.body;
        const userId = req.user.id_user;

        if (!currentPassword || !newPassword || !confirmPassword) {
            return res.status(400).json({ success: false, message: 'Semua field wajib diisi.' });
        }
        if (newPassword !== confirmPassword) {
            return res.status(400).json({ success: false, message: 'Password baru dan konfirmasi tidak cocok.' });
        }
        if (newPassword.length < 6) {
            return res.status(400).json({ success: false, message: 'Password baru minimal 6 karakter.' });
        }

        const userWithPassword = await UserModel.getById(userId);

        const isPasswordValid = await UserModel.verifyPassword(currentPassword, userWithPassword.password);
        if (!isPasswordValid) {
            return res.status(401).json({ success: false, message: 'Password saat ini salah.' });
        }

        await UserModel.update(userId, { password: newPassword }, userId);

        res.json({ success: true, message: 'Password berhasil diubah.' });
    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({ success: false, message: 'Gagal mengubah password.' });
    }
};

/** Controller untuk memperbarui token. */
const refreshToken = async (req, res) => {
    try {
        const user = req.user;

        const tokenPayload = { 
            id_user: user.id_user,
            username: user.username,
            role: user.nama_role
        };

        const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

        // 🔥 UPDATE COOKIE DENGAN TOKEN BARU
        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'lax',
            maxAge: 24 * 60 * 60 * 1000
        });

        res.json({
            success: true,
            message: 'Token berhasil diperbarui',
            data: {
                token,
                expiresIn: JWT_EXPIRES_IN
            }
        });
    } catch (error) {
        console.error('Refresh token error:', error);
        res.status(500).json({ success: false, message: 'Gagal memperbarui token.' });
    }
};

module.exports = {
    login,
    logout,
    getCurrentUser,
    changePassword,   
    refreshToken
};