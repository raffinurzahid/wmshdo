const TransaksiModel = require('../models/transaksiModel');
const BarangModel = require('../models/barangModel');
const NotificationModel = require('../models/NotificationModel');
const { query } = require('../config/db');

class TransaksiController {
    
    /** Get item details for auto-fill form */
    static async getAvailableItemDetails(req, res) {
        try {
            // ✅ Support both baseCode and kode_barang query params
            const inputCode = req.query.baseCode || req.query.kode_barang;
        
            if (!inputCode) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Base code or Kode Barang is required' 
                });
            }

            // ✅ Extract base code (works for both MTR60 and MTR60-14)
            const codeToSearch = inputCode.trim().toUpperCase().split('-')[0];
            console.log('[Controller] Searching base code:', codeToSearch, 'from input:', inputCode);
            
            const item = await BarangModel.getByKode(codeToSearch);

            if (!item) {
                return res.status(404).json({ 
                    success: false, 
                    message: `Item "${codeToSearch}" not found in Master Data` 
                });
            }
        
            res.json({ 
                success: true, 
                data: {
                    id_barang: item.id_barang,
                    kode_barang: item.kode_barang,
                    nama_barang: item.nama_barang,
                    jenis_barang: item.jenis_barang,
                    spesifikasi: item.spesifikasi,
                    qty_available: item.qty_stok
                }
            });

        } catch (error) {
            console.error('[Controller] Get Item Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch item details',
                error: error.message 
            });
        }
    }

    /** Get all transactions */
    static async getAllTransactions(req, res) {
        try {
            const transactions = await TransaksiModel.getAll();
            res.json({ success: true, data: transactions });
        } catch (error) {
            console.error('[Controller] Get All Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch transactions',
                error: error.message 
            });
        }
    }
    
    /** Get transaction by ID */
    static async getTransactionById(req, res) {
        try {
            const transaction = await TransaksiModel.getById(req.params.id);
            
            if (!transaction) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Transaction not found' 
                });
            }
            
            res.json({ success: true, data: transaction });
        } catch (error) {
            console.error('[Controller] Get By ID Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch transaction',
                error: error.message 
            });
        }
    }

    /** Create transaction - WITH NOTIFICATION */
    static async createSingleTransaction(req, res) {
        try {
            const { 
                jenis_transaksi, 
                kode_barang, 
                qty_stok, 
                lokasi, 
                npk, 
                nama_employee, 
                keterangan,
                status,
                asset_state,
                status_barang
            } = req.body;
            
            console.log('[Controller] Create transaction request:', {
                jenis_transaksi,
                kode_barang,
                qty_stok,
                lokasi,
                status_barang
            });

            if (!jenis_transaksi || !kode_barang || !qty_stok || !lokasi) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Missing required fields: jenis_transaksi, kode_barang, qty_stok, lokasi' 
                });
            }

            const qty = parseInt(qty_stok);
            if (qty <= 0) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Quantity must be greater than 0' 
                });
            }

            const createdBy = req.user?.id_user || null;

            // ✅ Extract base code from input (MTR60-14 → MTR60)
            const baseCode = kode_barang.trim().toUpperCase().split('-')[0];
            console.log('[Controller] Searching base code:', baseCode, 'from input:', kode_barang);
            
            const item = await BarangModel.getByKode(baseCode);

            if (!item) {
                return res.status(404).json({
                    success: false,
                    message: `Base item "${baseCode}" not found in Master Data. Please create the item first.`
                });
            }

            console.log('[Controller] Found item:', item.kode_barang, 'Stock:', item.qty_stok);

            // ✅ Validate stock for Assignment/Disposal
            if (jenis_transaksi === 'Assignment' || jenis_transaksi === 'Disposal') {
                if (item.qty_stok < qty) {
                    return res.status(400).json({
                        success: false,
                        message: `Insufficient stock for ${baseCode}. Available: ${item.qty_stok}, Requested: ${qty}`
                    });
                }

                if (jenis_transaksi === 'Assignment' && (!npk || !nama_employee)) {
                    return res.status(400).json({
                        success: false,
                        message: 'NPK and Employee Name are required for Assignment'
                    });
                }
            }

            // Generate transaction code
            const prefix = jenis_transaksi === 'Receiving' ? 'RCV' : 
                          jenis_transaksi === 'Assignment' ? 'ASG' : 'DPS';
            
            const kode_transaksi = await TransaksiModel.generateNextCode(prefix);

            // Determine asset state
            let finalAssetState = asset_state || status;
            if (!finalAssetState) {
                if (jenis_transaksi === 'Receiving') finalAssetState = 'In Store';
                else if (jenis_transaksi === 'Assignment') finalAssetState = 'In Use';
                else if (jenis_transaksi === 'Disposal') finalAssetState = 'Disposal';
            }

            const txData = {
                kode_transaksi: kode_transaksi,
                jenis_transaksi: jenis_transaksi,
                id_barang: item.id_barang, // ✅ Use base item's ID
                kode_barang: kode_barang.trim().toUpperCase(), // ✅ Store full code (MTR60-14)
                base_code: baseCode, // ✅ Store base code separately
                qty_stok: qty,
                status: finalAssetState,
                asset_state: finalAssetState,
                npk: npk || null,
                nama_employee: nama_employee || null,
                lokasi: lokasi,
                id_gudang: item.id_gudang || null,
                keterangan: keterangan || `${jenis_transaksi} transaction`,
                tanggal: new Date(),
                status_barang: status_barang || null
            };

            const result = await TransaksiModel.create(txData, createdBy);

            console.log('[Controller] Transaction created successfully:', result.kode_transaksi);

            // ✅ CREATE NOTIFICATION
            if (createdBy) {
                await this.createTransactionNotification({
                    jenis_transaksi,
                    kode_transaksi,
                    kode_barang: kode_barang.trim().toUpperCase(),
                    nama_barang: item.nama_barang,
                    qty_stok: qty,
                    lokasi,
                    npk,
                    nama_employee,
                    keterangan,
                    created_by: createdBy,
                    id_transaksi: result.id_transaksi,
                    tanggal: new Date()
                });
            }

            res.status(201).json({
                success: true,
                message: `${jenis_transaksi} transaction created successfully`,
                data: result
            });
            
        } catch (error) {
            console.error('[Controller] Create Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message || 'Failed to create transaction'
            });
        }
    }

    /** Update transaction */
    static async updateTransaction(req, res) {
        try {
            const { qty_stok, lokasi, npk, nama_employee, keterangan, asset_state, status } = req.body;
            const updatedBy = req.user?.id_user || null;

            console.log('[Controller] Update transaction:', req.params.id);
            
            const oldTx = await TransaksiModel.getById(req.params.id);
            if (!oldTx) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Transaction not found' 
                });
            }

            const updateData = {
                qty_stok,
                lokasi,
                npk,
                nama_employee,
                keterangan,
                asset_state: asset_state || status,
                old_qty: oldTx.qty_stok
            };

            const result = await TransaksiModel.update(req.params.id, updateData, updatedBy);
            
            res.json({ 
                success: true, 
                message: 'Transaction updated successfully', 
                data: result 
            });
        } catch (error) {
            console.error('[Controller] Update Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Delete transaction */
    static async deleteTransaction(req, res) {
        try {
            console.log('[Controller] Delete transaction:', req.params.id);
            
            const result = await TransaksiModel.delete(req.params.id);
            
            res.json({ 
                success: true, 
                message: 'Transaction deleted successfully', 
                data: result 
            });
        } catch (error) {
            console.error('[Controller] Delete Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Search transactions */
    static async searchTransactions(req, res) {
        try {
            const { q } = req.query;
            
            if (!q || q.length < 2) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Search query must be at least 2 characters' 
                });
            }
            
            const results = await TransaksiModel.search(q);
            res.json({ success: true, data: results });
        } catch (error) {
            console.error('[Controller] Search Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get dashboard statistics */
    static async getDashboardStats(req, res) {
        try {
            const stats = await TransaksiModel.getDashboardSummary();
            res.json({ success: true, data: stats });
        } catch (error) {
            console.error('[Controller] Get Stats Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get recent activities */
    static async getRecentActivities(req, res) {
        try {
            const { limit = 20 } = req.query;
            const activities = await TransaksiModel.getRecentActivities(parseInt(limit));
            res.json({ success: true, data: activities });
        } catch (error) {
            console.error('[Controller] Get Recent Activities Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get last transaction code */
    static async getLastCode(req, res) {
        try {
            const { prefix } = req.query;
            
            if (!prefix || !['RCV', 'ASG', 'DPS'].includes(prefix)) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Valid prefix required (RCV, ASG, or DPS)' 
                });
            }
            
            const nextCode = await TransaksiModel.generateNextCode(prefix);
            res.json({ success: true, data: { next_code: nextCode } });
        } catch (error) {
            console.error('[Controller] Get Last Code Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Soft delete transaction */
    static async softDeleteTransaction(req, res) {
        try {
            console.log('[Controller] Soft delete transaction:', req.params.id);
            
            // Note: You'll need to implement this in TransaksiModel
            res.status(501).json({ 
                success: false, 
                message: 'Soft delete not implemented yet. Use hard delete instead.' 
            });
        } catch (error) {
            console.error('[Controller] Soft Delete Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Restore transaction */
    static async restoreTransaction(req, res) {
        try {
            console.log('[Controller] Restore transaction:', req.params.id);
            
            // Note: You'll need to implement this in TransaksiModel
            res.status(501).json({ 
                success: false, 
                message: 'Restore not implemented yet' 
            });
        } catch (error) {
            console.error('[Controller] Restore Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** ✅ NEW: Create Transaction Notification (Helper Method) */
    static async createTransactionNotification(txData) {
        try {
            const { 
                jenis_transaksi, 
                kode_transaksi,
                kode_barang,
                nama_barang, 
                qty_stok, 
                lokasi,
                npk,
                nama_employee, 
                keterangan,
                created_by, 
                id_transaksi,
                tanggal
            } = txData;

            const date = new Date(tanggal);
            const formattedDate = date.toLocaleString('id-ID', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            let title, message, icon, color;

            if (jenis_transaksi === 'Receiving') {
                title = '✅ Receiving Complete!';
                message = `${kode_barang} - ${nama_barang} (Qty: ${qty_stok})\n📍 ${lokasi} • 🕐 ${formattedDate}`;
                icon = 'fas fa-download';
                color = '#28a745';
            } else if (jenis_transaksi === 'Assignment') {
                title = '👤 Item Assigned!';
                message = `${kode_barang} - ${nama_barang} (Qty: ${qty_stok}) → ${nama_employee} (NPK: ${npk})\n📍 ${lokasi} • 🕐 ${formattedDate}`;
                icon = 'fas fa-user-plus';
                color = '#ffc107';
            } else if (jenis_transaksi === 'Disposal') {
                title = '🗑️ Item Disposed';
                const reason = keterangan ? `\nReason: ${keterangan}` : '';
                message = `${kode_barang} - ${nama_barang} (Qty: ${qty_stok})\n📍 ${lokasi} • 🕐 ${formattedDate}${reason}`;
                icon = 'fas fa-trash';
                color = '#dc3545';
            } else {
                return; // Unknown type
            }

            const notificationData = {
                id_user: created_by,
                title: title,
                message: message,
                type: 'transaction',
                icon: icon,
                color: color,
                reference_id: id_transaksi
            };
            
            await NotificationModel.create(notificationData);
            console.log(`[Controller] ✅ Notification created for ${jenis_transaksi} - ${kode_transaksi}`);
        } catch (error) {
            console.error('[Controller] Failed to create notification:', error.message);
            // Don't throw - graceful failure
        }
    }
}

module.exports = TransaksiController;