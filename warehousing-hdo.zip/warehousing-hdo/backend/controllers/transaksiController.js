const TransaksiModel = require('../models/transaksiModel');
const BarangModel = require('../models/barangModel');
const ListBarangModel = require('../models/listBarangModel');
const NotificationModel = require('../models/NotificationModel');

class TransaksiController {
    
    /** Get item details for auto-fill form */
    static async getAvailableItemDetails(req, res) {
        try {
            const inputCode = req.query.kode_barang || req.query.kode_barang;
        
            if (!inputCode) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Base code or Kode Barang is required' 
                });
            }

            // Extract base code (works for both MTR60 and MTR60-14)
            const codeToSearch = inputCode.trim().toUpperCase().split('-')[0];
            console.log('[Controller] Searching base code:', codeToSearch, 'from input:', inputCode);
            
            const item = await BarangModel.getByKode(codeToSearch);

            if (!item) {
                return res.status(404).json({ 
                    success: false, 
                    message: `Item "${codeToSearch}" not found in Master Data` 
                });
            }
        
            res.json({ 
                success: true, 
                data: {
                    id_barang: item.id_barang,
                    kode_barang: item.kode_barang,
                    nama_barang: item.nama_barang,
                    jenis_barang: item.jenis_barang,
                    spesifikasi: item.spesifikasi,
                    qty_available: item.qty_stok
                }
            });

        } catch (error) {
            console.error('[Controller] Get Item Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch item details',
                error: error.message 
            });
        }
    }

    /** Get all transactions */
    static async getAllTransactions(req, res) {
        try {
            const transactions = await TransaksiModel.getAll();
            res.json({ success: true, data: transactions });
        } catch (error) {
            console.error('[Controller] Get All Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch transactions',
                error: error.message 
            });
        }
    }
    
    /** Get transaction by ID */
    static async getTransactionById(req, res) {
        try {
            const transaction = await TransaksiModel.getById(req.params.id);
            
            if (!transaction) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Transaction not found' 
                });
            }
            
            res.json({ success: true, data: transaction });
        } catch (error) {
            console.error('[Controller] Get By ID Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch transaction',
                error: error.message 
            });
        }
    }

    /** ✅ CREATE TRANSACTION - WITH NPK AUTO-FORMAT & VALIDASI */
    static async createSingleTransaction(req, res) {
        try {
            let { 
                jenis_transaksi, 
                kode_barang, 
                qty_stok, 
                lokasi, 
                npk, 
                nama_employee, 
                keterangan,
                status,
                asset_state,
                status_barang
            } = req.body;
            
            console.log('[Controller] ============ CREATE REQUEST ============');
            console.log('[Controller] Type:', jenis_transaksi);
            console.log('[Controller] Input kode_barang:', kode_barang);
            console.log('[Controller] Qty:', qty_stok);
            console.log('[Controller] NPK (raw):', npk);

            // Basic validation
            if (!jenis_transaksi || !kode_barang || !lokasi) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Missing required fields: jenis_transaksi, kode_barang, lokasi' 
                });
            }

            // ========================================
            // RECEIVING VALIDATION
            // ========================================
            if (jenis_transaksi === 'Receiving') {
                if (!qty_stok || qty_stok <= 0) {
                    return res.status(400).json({ 
                        success: false, 
                        message: 'Quantity must be greater than 0 for Receiving' 
                    });
                }

                const qty = parseInt(qty_stok);
                kode_barang = kode_barang.trim().toUpperCase().split('-')[0];
                
                console.log('[Controller] 📥 RECEIVING - Base:', kode_barang, 'Qty:', qty);

                // Check if base code exists
                const item = await BarangModel.getByKode(kode_barang);
                if (!item) {
                    return res.status(404).json({
                        success: false,
                        message: `Base item "${kode_barang}" not found in Master Data. Please create the item first.`
                    });
                }

                // Generate transaction code
                const kode_transaksi = await TransaksiModel.generateNextCode('RCV');

                const txData = {
                    kode_transaksi: kode_transaksi,
                    jenis_transaksi: jenis_transaksi,
                    kode_barang: kode_barang, // Store base code
                    qty_stok: qty,
                    status: 'In Store',
                    asset_state: 'In Store',
                    npk: null,
                    nama_employee: null,
                    lokasi: lokasi,
                    id_gudang: item.id_gudang || null,
                    keterangan: keterangan || `Receiving ${qty} items`,
                    tanggal: new Date(),
                    status_barang: status_barang || 'New'
                };

                const createdBy = req.user?.id_user || null;
                const result = await TransaksiModel.create(txData, createdBy);

                console.log('[Controller] ✅ RECEIVING completed:', result.kode_transaksi);

                // Create notification
                if (createdBy) {
                    await this.createTransactionNotification({
                        jenis_transaksi,
                        kode_transaksi,
                        kode_barang: kode_barang,
                        nama_barang: item.nama_barang,
                        qty_stok: qty,
                        lokasi,
                        npk: null,
                        nama_employee: null,
                        keterangan,
                        created_by: createdBy,
                        id_transaksi: result.id_transaksi,
                        tanggal: new Date()
                    });
                }

                return res.status(201).json({
                    success: true,
                    message: `✅ Receiving completed! Generated ${qty} serial numbers`,
                    data: result
                });
            }

            // ========================================
            // ASSIGNMENT VALIDATION
            // ========================================
            if (jenis_transaksi === 'Assignment') {
                const fullCode = kode_barang.trim().toUpperCase();
                
                console.log('[Controller] 👤 ASSIGNMENT - Full code:', fullCode);

                // Validate full code format (must have serial number)
                if (!fullCode.includes('-')) {
                    return res.status(400).json({
                        success: false,
                        message: 'Please enter full serial code (e.g., NB157-14) for Assignment'
                    });
                }

                // ✅ NPK AUTO-FORMAT (pad to 5 digits)
                if (!npk) {
                    return res.status(400).json({
                        success: false,
                        message: 'NPK is required for Assignment'
                    });
                }

                // Remove spaces and validate numeric only
                const cleanNPK = npk.toString().trim().replace(/\s/g, '');
                
                if (!/^\d+$/.test(cleanNPK)) {
                    return res.status(400).json({
                        success: false,
                        message: 'NPK must contain numbers only'
                    });
                }

                if (cleanNPK.length > 5) {
                    return res.status(400).json({
                        success: false,
                        message: 'NPK cannot exceed 5 digits'
                    });
                }

                // ✅ AUTO-PAD NPK TO 5 DIGITS
                const formattedNPK = cleanNPK.padStart(5, '0');
                console.log('[Controller] 🔢 NPK formatted:', npk, '→', formattedNPK);

                // Validate nama_employee (no numbers)
                if (!nama_employee) {
                    return res.status(400).json({
                        success: false,
                        message: 'Employee name is required for Assignment'
                    });
                }

                if (/\d/.test(nama_employee)) {
                    return res.status(400).json({
                        success: false,
                        message: 'Employee name cannot contain numbers'
                    });
                }

                // ✅ CHECK IF ITEM ALREADY ASSIGNED (VALIDASI DUPLIKAT)
                const existingItem = await ListBarangModel.getByKode(fullCode);
                
                if (!existingItem) {
                    return res.status(404).json({
                        success: false,
                        message: `❌ Item "${fullCode}" not found in inventory. Please check the serial number.`
                    });
                }

                if (existingItem.asset_state !== 'In Store') {
                    return res.status(400).json({
                        success: false,
                        message: `❌ Item "${fullCode}" is already ${existingItem.asset_state}. Cannot assign again!`
                    });
                }

                console.log('[Controller] ✅ Item available for assignment');

                // Generate transaction code
                const kode_transaksi = await TransaksiModel.generateNextCode('ASG');

                const txData = {
                    kode_transaksi: kode_transaksi,
                    jenis_transaksi: jenis_transaksi,
                    kode_barang: fullCode, // Full serial code
                    qty_stok: 1, // Always 1 for assignment
                    status: 'In Use',
                    asset_state: 'In Use',
                    npk: formattedNPK, // ✅ Use formatted NPK
                    nama_employee: nama_employee.trim(),
                    lokasi: lokasi,
                    id_gudang: existingItem.id_gudang || null,
                    keterangan: keterangan || `Assigned to ${nama_employee}`,
                    tanggal: new Date()
                };

                const createdBy = req.user?.id_user || null;
                const result = await TransaksiModel.create(txData, createdBy);

                console.log('[Controller] ✅ ASSIGNMENT completed:', result.kode_transaksi);

                // Create notification
                if (createdBy) {
                    await this.createTransactionNotification({
                        jenis_transaksi,
                        kode_transaksi,
                        kode_barang: fullCode,
                        nama_barang: existingItem.nama_barang,
                        qty_stok: 1,
                        lokasi,
                        npk: formattedNPK,
                        nama_employee,
                        keterangan,
                        created_by: createdBy,
                        id_transaksi: result.id_transaksi,
                        tanggal: new Date()
                    });
                }

                return res.status(201).json({
                    success: true,
                    message: `✅ Item "${fullCode}" assigned to ${nama_employee} (NPK: ${formattedNPK})`,
                    data: result
                });
            }

            // ========================================
            // DISPOSAL VALIDATION
            // ========================================
            if (jenis_transaksi === 'Disposal') {
                const fullCode = kode_barang.trim().toUpperCase();
                
                console.log('[Controller] 🗑️ DISPOSAL - Full code:', fullCode);

                // Validate full code format
                if (!fullCode.includes('-')) {
                    return res.status(400).json({
                        success: false,
                        message: 'Please enter full serial code (e.g., NB157-14) for Disposal'
                    });
                }

                // Check if item exists
                const existingItem = await ListBarangModel.getByKode(fullCode);
                
                if (!existingItem) {
                    return res.status(404).json({
                        success: false,
                        message: `❌ Item "${fullCode}" not found in inventory`
                    });
                }

                console.log('[Controller] ✅ Item found for disposal');

                // Generate transaction code
                const kode_transaksi = await TransaksiModel.generateNextCode('DPS');

                const txData = {
                    kode_transaksi: kode_transaksi,
                    jenis_transaksi: jenis_transaksi,
                    kode_barang: fullCode,
                    qty_stok: 1,
                    status: asset_state || status || 'Disposal',
                    asset_state: asset_state || status || 'Disposal',
                    npk: null,
                    nama_employee: null,
                    lokasi: 'P2B',
                    id_gudang: existingItem.id_gudang || null,
                    keterangan: keterangan || 'Item disposed',
                    tanggal: new Date()
                };

                const createdBy = req.user?.id_user || null;
                const result = await TransaksiModel.create(txData, createdBy);

                console.log('[Controller] ✅ DISPOSAL completed:', result.kode_transaksi);

                // Create notification
                if (createdBy) {
                    await this.createTransactionNotification({
                        jenis_transaksi,
                        kode_transaksi,
                        kode_barang: fullCode,
                        nama_barang: existingItem.nama_barang,
                        qty_stok: 1,
                        lokasi: 'P2B',
                        npk: null,
                        nama_employee: null,
                        keterangan,
                        created_by: createdBy,
                        id_transaksi: result.id_transaksi,
                        tanggal: new Date()
                    });
                }

                return res.status(201).json({
                    success: true,
                    message: `✅ Item "${fullCode}" disposed successfully`,
                    data: result
                });
            }

            return res.status(400).json({
                success: false,
                message: 'Invalid transaction type. Must be: Receiving, Assignment, or Disposal'
            });
            
        } catch (error) {
            console.error('[Controller] ❌ Create Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message || 'Failed to create transaction'
            });
        }
    }

    /** Update transaction */
    static async updateTransaction(req, res) {
        try {
            let { qty_stok, lokasi, npk, nama_employee, keterangan, asset_state, status } = req.body;
            const updatedBy = req.user?.id_user || null;

            console.log('[Controller] Update transaction:', req.params.id);
            
            const oldTx = await TransaksiModel.getById(req.params.id);
            if (!oldTx) {
                return res.status(404).json({ 
                    success: false, 
                    message: 'Transaction not found' 
                });
            }

            // ✅ NPK AUTO-FORMAT if provided
            if (npk) {
                const cleanNPK = npk.toString().trim().replace(/\s/g, '');
                
                if (!/^\d+$/.test(cleanNPK)) {
                    return res.status(400).json({
                        success: false,
                        message: 'NPK must contain numbers only'
                    });
                }

                if (cleanNPK.length > 5) {
                    return res.status(400).json({
                        success: false,
                        message: 'NPK cannot exceed 5 digits'
                    });
                }

                npk = cleanNPK.padStart(5, '0');
                console.log('[Controller] NPK formatted for update:', npk);
            }

            const updateData = {
                qty_stok,
                lokasi,
                npk,
                nama_employee,
                keterangan,
                asset_state: asset_state || status,
                old_qty: oldTx.qty_stok
            };

            const result = await TransaksiModel.update(req.params.id, updateData, updatedBy);
            
            res.json({ 
                success: true, 
                message: 'Transaction updated successfully', 
                data: result 
            });
        } catch (error) {
            console.error('[Controller] Update Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Delete transaction */
    static async deleteTransaction(req, res) {
        try {
            console.log('[Controller] Delete transaction:', req.params.id);
            
            const result = await TransaksiModel.delete(req.params.id);
            
            res.json({ 
                success: true, 
                message: 'Transaction deleted successfully', 
                data: result 
            });
        } catch (error) {
            console.error('[Controller] Delete Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Search transactions */
    static async searchTransactions(req, res) {
        try {
            const { q } = req.query;
            
            if (!q || q.length < 2) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Search query must be at least 2 characters' 
                });
            }
            
            const results = await TransaksiModel.search(q);
            res.json({ success: true, data: results });
        } catch (error) {
            console.error('[Controller] Search Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get dashboard statistics */
    static async getDashboardStats(req, res) {
        try {
            const stats = await TransaksiModel.getDashboardSummary();
            res.json({ success: true, data: stats });
        } catch (error) {
            console.error('[Controller] Get Stats Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get recent activities */
    static async getRecentActivities(req, res) {
        try {
            const { limit = 20 } = req.query;
            const activities = await TransaksiModel.getRecentActivities(parseInt(limit));
            res.json({ success: true, data: activities });
        } catch (error) {
            console.error('[Controller] Get Recent Activities Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get last transaction code */
    static async getLastCode(req, res) {
        try {
            const { prefix } = req.query;
            
            if (!prefix || !['RCV', 'ASG', 'DPS'].includes(prefix)) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Valid prefix required (RCV, ASG, or DPS)' 
                });
            }
            
            const nextCode = await TransaksiModel.generateNextCode(prefix);
            res.json({ success: true, data: { next_code: nextCode } });
        } catch (error) {
            console.error('[Controller] Get Last Code Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Create Transaction Notification (Helper Method) */
    static async createTransactionNotification(txData) {
        try {
            const { 
                jenis_transaksi, 
                kode_transaksi,
                kode_barang,
                nama_barang, 
                qty_stok, 
                lokasi,
                npk,
                nama_employee, 
                keterangan,
                created_by, 
                id_transaksi,
                tanggal
            } = txData;

            const date = new Date(tanggal);
            const formattedDate = date.toLocaleString('id-ID', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            let title, message, icon, color;

            if (jenis_transaksi === 'Receiving') {
                title = '✅ Receiving Complete!';
                message = `${kode_barang} - ${nama_barang} (Qty: ${qty_stok})\n📍 ${lokasi} • 🕐 ${formattedDate}`;
                icon = 'fas fa-download';
                color = '#28a745';
            } else if (jenis_transaksi === 'Assignment') {
                title = '👤 Item Assigned!';
                message = `${kode_barang} - ${nama_barang} → ${nama_employee} (NPK: ${npk})\n📍 ${lokasi} • 🕐 ${formattedDate}`;
                icon = 'fas fa-user-plus';
                color = '#ffc107';
            } else if (jenis_transaksi === 'Disposal') {
                title = '🗑️ Item Disposed';
                const reason = keterangan ? `\nReason: ${keterangan}` : '';
                message = `${kode_barang} - ${nama_barang}\n📍 ${lokasi} • 🕐 ${formattedDate}${reason}`;
                icon = 'fas fa-trash';
                color = '#dc3545';
            } else {
                return;
            }

            const notificationData = {
                id_user: created_by,
                title: title,
                message: message,
                type: 'transaction',
                icon: icon,
                color: color,
                reference_id: id_transaksi
            };
            
            await NotificationModel.create(notificationData);
            console.log(`[Controller] ✅ Notification created for ${jenis_transaksi} - ${kode_transaksi}`);
        } catch (error) {
            console.error('[Controller] Failed to create notification:', error.message);
        }
    }
}

module.exports = TransaksiController;