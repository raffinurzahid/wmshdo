const RoleModel = require('../models/roleModel');

class RoleController {
  // Get all roles
  static async getAllRoles(req, res) {
    try {
      const roles = await RoleModel.getAll();

      res.json({
        success: true,
        data: roles
      });
    } catch (error) {
      console.error('Error getting roles:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch roles',
        error: error.message
      });
    }
  }

  // Get role by ID
  static async getRoleById(req, res) {
    try {
      const { id } = req.params;
      const role = await RoleModel.getById(id);

      if (!role) {
        return res.status(404).json({
          success: false,
          message: 'Role not found'
        });
      }

      res.json({
        success: true,
        data: role
      });
    } catch (error) {
      console.error('Error getting role:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch role',
        error: error.message
      });
    }
  }

  // Create new role
  static async createRole(req, res) {
    try {
      const { nama_role } = req.body;

      if (!nama_role || nama_role.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Role name is required'
        });
      }

      const createdBy = req.user?.username || 'system';
      const role = await RoleModel.create(req.body, createdBy);

      res.status(201).json({
        success: true,
        message: 'Role created successfully',
        data: role
      });
    } catch (error) {
      console.error('Error creating role:', error);

      if (error.message.includes('already exists')) {
        return res.status(409).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to create role',
        error: error.message
      });
    }
  }

  // Update role
  static async updateRole(req, res) {
    try {
      const { id } = req.params;
      const { nama_role } = req.body;

      if (!nama_role || nama_role.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Role name is required'
        });
      }

      const updatedBy = req.user?.username || null;
      const role = await RoleModel.update(id, req.body, updatedBy);

      res.json({
        success: true,
        message: 'Role updated successfully',
        data: role
      });
    } catch (error) {
      console.error('Error updating role:', error);

      if (error.message.includes('not found')) {
        return res.status(404).json({
          success: false,
          message: error.message
        });
      }

      if (error.message.includes('already exists')) {
        return res.status(409).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to update role',
        error: error.message
      });
    }
  }

  // Soft delete role
  static async softDeleteRole(req, res) {
    try {
      const { id } = req.params;
      const deletedBy = req.user?.username || null;

      const role = await RoleModel.softDelete(id, deletedBy);

      res.json({
        success: true,
        message: 'Role soft deleted successfully',
        data: role
      });
    } catch (error) {
      console.error('Error soft deleting role:', error);

      if (error.message.includes('assigned users')) {
        return res.status(400).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to soft delete role',
        error: error.message
      });
    }
  }

  // Hard delete role
  static async deleteRole(req, res) {
    try {
      const { id } = req.params;
      const role = await RoleModel.delete(id);

      res.json({
        success: true,
        message: 'Role permanently deleted',
        data: role
      });
    } catch (error) {
      console.error('Error deleting role:', error);

      if (error.message.includes('assigned users')) {
        return res.status(400).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to delete role',
        error: error.message
      });
    }
  }

  // Restore soft deleted role
  static async restoreRole(req, res) {
    try {
      const { id } = req.params;
      const role = await RoleModel.restore(id);

      res.json({
        success: true,
        message: 'Role restored successfully',
        data: role
      });
    } catch (error) {
      console.error('Error restoring role:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to restore role',
        error: error.message
      });
    }
  }

  // Get users by role
  static async getUsersByRole(req, res) {
    try {
      const { id } = req.params;
      const users = await RoleModel.getUsersByRole(id);

      res.json({
        success: true,
        data: users
      });
    } catch (error) {
      console.error('Error getting users by role:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch users by role',
        error: error.message
      });
    }
  }

  // Search roles
  static async searchRoles(req, res) {
    try {
      const { q } = req.query;

      if (!q || q.trim().length < 2) {
        return res.status(400).json({
          success: false,
          message: 'Search query must be at least 2 characters'
        });
      }

      const roles = await RoleModel.search(q.trim());

      res.json({
        success: true,
        data: roles
      });
    } catch (error) {
      console.error('Error searching roles:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to search roles',
        error: error.message
      });
    }
  }

  // Get role statistics
  static async getRoleStats(req, res) {
    try {
      const stats = await RoleModel.getStats();

      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error getting role stats:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch role statistics',
        error: error.message
      });
    }
  }
}

module.exports = RoleController;