const BarangModel = require('../models/barangModel');
const TransaksiModel = require('../models/transaksiModel');
const UserModel = require('../models/userModel');
const GudangModel = require('../models/gudangModel');

const handleError = (res, error, context) => {
    console.error(`Error in ${context}:`, error);
    res.status(500).json({
        success: false,
        message: `Gagal memuat ${context}`,
        error: error.message
    });
};

class DashboardController {
    
    static async getDashboardPage(req, res) {
        try {
            const [
                summaryStats,
                lowStockItems,
                recentActivities,
                totalUsers,
                totalWarehouses
            ] = await Promise.all([
                TransaksiModel.getDashboardSummary(),
                BarangModel.getLowStockItems(5),
                TransaksiModel.getRecentActivities(10),
                UserModel.countActive(),
                GudangModel.countActive()
            ]);

            const dashboardData = {
                totalTransactions: summaryStats.total_transactions || 0,
                totalItemsIn: summaryStats.total_masuk || 0,
                totalItemsOut: summaryStats.total_assignment || 0,
                totalItemsDisposed: summaryStats.total_disposal || 0,
                totalStockValue: summaryStats.total_stock || 0,
                totalUniqueItems: summaryStats.total_unique_items || 0,
                lowStockItems: lowStockItems || [],
                recentActivities: recentActivities || [],
                totalUsers: totalUsers || 0,
                totalWarehouses: totalWarehouses || 0,
            };
            
            res.render('pages/dashboard', {
                title: 'Dashboard - WMS Help Desk',
                currentPage: 'dashboard',
                ...dashboardData
            });

        } catch (error) {
            console.error('Error loading dashboard page:', error);
            res.status(500).render('pages/error', {
                title: 'Error',
                message: 'Gagal memuat halaman dashboard.',
                error: error.message
            });
        }
    }

    static async getSummaryStats(req, res) {
        try {
            const stats = await TransaksiModel.getDashboardSummary();
            res.json({ success: true, data: stats });
        } catch (error) {
            handleError(res, error, 'dashboard summary stats');
        }
    }

    static async getInventoryOverview(req, res) {
        try {
            const [items, lowStock, warehouses, categories] = await Promise.all([
                BarangModel.getAllWithStock(),
                BarangModel.getLowStockItems(),
                GudangModel.getAll(),
                BarangModel.getCategories()
            ]);
            const overview = {
                totalUniqueItems: items.length,
                totalStock: items.reduce((sum, item) => sum + parseInt(item.current_stock || 0), 0),
                lowStockCount: lowStock.length,
                activeWarehouses: warehouses.length,
                categories: categories
            };
            res.json({ success: true, data: overview });
        } catch (error) {
            handleError(res, error, 'inventory overview');
        }
    }

    static async getTransactionChartData(req, res) {
        try {
            const { period = '30' } = req.query;
            const chartData = await TransaksiModel.getTransactionChartData(parseInt(period));
            res.json({ success: true, data: chartData });
        } catch (error) {
            handleError(res, error, 'transaction chart data');
        }
    }

    static async getUserActivitySummary(req, res) {
        try {
            const activity = await UserModel.getActivitySummary(10);
            res.json({ success: true, data: activity });
        } catch (error) {
            handleError(res, error, 'user activity summary');
        }
    }

    static async getWarehouseUtilization(req, res) {
        try {
            const utilization = await GudangModel.getUtilizationStats();
            res.json({ success: true, data: utilization });
        } catch (error) {
            handleError(res, error, 'warehouse utilization');
        }
    }

    static async getRecentActivities(req, res) {
        try {
            const { limit = 20 } = req.query;
            const activities = await TransaksiModel.getRecentActivities(parseInt(limit));
            res.json({ success: true, data: activities });
        } catch (error) {
            handleError(res, error, 'recent activities');
        }
    }
    
    static async getCategoryStats(req, res) {
        try {
            const categories = await BarangModel.getCategories();
            res.json({ success: true, data: categories });
        } catch (error) {
            handleError(res, error, 'category stats');
        }
    }

    static async getStockAlerts(req, res) {
        try {
            const lowStockItems = await BarangModel.getLowStockItems();
            const alerts = lowStockItems.map(item => ({
                type: 'low_stock',
                severity: (item.qty_stok || 0) === 0 ? 'critical' : 'warning',
                title: 'Stok Hampir Habis',
                message: `Stok ${item.nama_barang} (${item.kode_barang}) tersisa ${item.qty_stok || 0}.`,
                itemId: item.id_barang,
                currentStock: item.qty_stok,
                minStock: item.min_stok
            }));
            res.json({ success: true, data: alerts });
        } catch (error) {
            handleError(res, error, 'stock alerts');
        }
    }

    static async getSystemStats(req, res) {
        try {
            const [userStats, itemStats, warehouseStats, transactionStats] = await Promise.all([
                UserModel.getStats(),
                BarangModel.getStats(),
                GudangModel.getStats(),
                TransaksiModel.getStats()
            ]);
            res.json({
                success: true,
                data: {
                    users: userStats,
                    items: itemStats,
                    warehouses: warehouseStats,
                    transactions: transactionStats
                }
            });
        } catch (error) {
            handleError(res, error, 'system stats');
        }
    }
}

module.exports = DashboardController;