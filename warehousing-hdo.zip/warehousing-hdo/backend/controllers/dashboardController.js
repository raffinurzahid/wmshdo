  const BarangModel = require('../models/barangModel');
  const TransaksiModel = require('../models/transaksiModel');
  const KaryawanModel = require('../models/karyawanModel');
  const GudangModel = require('../models/gudangModel');

  class DashboardController {
    // Get dashboard page
    static async getDashboardPage(req, res) {
      try {
        // Get dashboard statistics
        const [
          dashboardStats,
          lowStockItems,
          recentTransactions,
          warehouseStats,
          allItems,
          allEmployees,
          allWarehouses
        ] = await Promise.all([
          TransaksiModel.getDashboardStats(),
          BarangModel.getLowStockItems(),
          TransaksiModel.getRecentTransactions(10),
          GudangModel.getSummaryStats(),
          BarangModel.getAllWithStock(),
          KaryawanModel.getAll(),
          GudangModel.getAll()
        ]);

        // Calculate totals and statistics
        const totalBarang = allItems.length;
        const totalStok = allItems.reduce((sum, item) => sum + (item.current_stock || 0), 0);
        const totalSuppliers = 10; // Static value since we don't have supplier table

        // Get categories count
        const categories = await BarangModel.getCategories();
        const totalShelfs = categories.length;

        const dashboardData = {
          // Main statistics cards  
          totalShelfs: totalShelfs,
          totalMedicines: totalStok,
          totalStocksQuality: totalStok,
          totalSuppliers: totalSuppliers,
          numberOfPurchase: dashboardStats.total_masuk || 0,
          totalPurchaseAmount: 0, // We don't have price data in simplified schema
          numberOfSales: dashboardStats.total_assignment || 0,
          totalSalesAmount: 0, // We don't have price data in simplified schema
          
          // Additional data
          lowStockItems: lowStockItems || [],
          recentTransactions: recentTransactions || [],
          warehouseStats: warehouseStats || {},
          totalKaryawan: allEmployees.length,
          totalGudang: allWarehouses.length,
          lowStockCount: (lowStockItems || []).length,
          
          // Transaction statistics
          totalTransactions: dashboardStats.total_transactions || 0,
          totalDisposal: dashboardStats.total_disposal || 0
        };

        res.render('pages/dashboard', {
          title: 'Dashboard - WMS Help Desk',
          currentPage: 'dashboard',
          ...dashboardData
        });

      } catch (error) {
        console.error('Error loading dashboard:', error);
        res.status(500).render('pages/error', {
          title: 'Error',
          message: 'Gagal memuat dashboard',
          error: error.message
        });
      }
    }

    // API: Get dashboard statistics
    static async getDashboardStats(req, res) {
      try {
        const stats = await TransaksiModel.getDashboardStats();
        
        res.json({
          success: true,
          data: stats
        });
      } catch (error) {
        console.error('Error getting dashboard stats:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil statistik dashboard',
          error: error.message
        });
      }
    }

    // API: Get inventory overview
    static async getInventoryOverview(req, res) {
      try {
        const [items, lowStock, warehouses, categories] = await Promise.all([
          BarangModel.getAllWithStock(),
          BarangModel.getLowStockItems(),
          GudangModel.getAll(),
          BarangModel.getCategories()
        ]);

        const overview = {
          totalItems: items.length,
          totalStock: items.reduce((sum, item) => sum + (item.current_stock || 0), 0),
          lowStockCount: lowStock.length,
          activeWarehouses: warehouses.length,
          categories: categories,
          itemsByCategory: {},
          stockByWarehouse: {}
        };

        // Group items by category
        categories.forEach(category => {
          overview.itemsByCategory[category.jenis_barang] = {
            count: category.item_count,
            totalStock: category.total_stock || 0
          };
        });

        // Get stock by warehouse
        for (const warehouse of warehouses) {
          const stockDetails = await GudangModel.getStockDetails(warehouse.id_gudang);
          overview.stockByWarehouse[warehouse.nama_gudang] = {
            totalItems: stockDetails.length,
            totalStock: stockDetails.reduce((sum, stock) => sum + (stock.current_stock || 0), 0),
            lowStockItems: stockDetails.filter(stock => (stock.current_stock || 0) < 5).length
          };
        }

        res.json({
          success: true,
          data: overview
        });
      } catch (error) {
        console.error('Error getting inventory overview:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil overview inventory',
          error: error.message
        });
      }
    }

    // API: Get transaction summary with chart data
    static async getTransactionSummary(req, res) {
      try {
        const { period = '30' } = req.query; // days
        
        const sql = `
          SELECT 
            DATE(tanggal) as date,
            status_barang,
            COUNT(*) as count,
            SUM(qty_stok) as total_items
          FROM transaksi 
          WHERE tanggal >= CURRENT_DATE - INTERVAL '${parseInt(period)} days'
          GROUP BY DATE(tanggal), status_barang
          ORDER BY date DESC
        `;

        const { query } = require('../config/db');
        const result = await query(sql);

        // Process data for chart
        const processedData = {};
        result.rows.forEach(row => {
          const dateKey = row.date.toISOString().split('T')[0];
          if (!processedData[dateKey]) {
            processedData[dateKey] = {
              date: dateKey,
              Masuk: 0,
              Assignment: 0,
              Disposal: 0
            };
          }
          processedData[dateKey][row.status_barang] = parseInt(row.count);
        });

        const chartData = Object.values(processedData).sort((a, b) => new Date(a.date) - new Date(b.date));

        res.json({
          success: true,
          data: chartData
        });
      } catch (error) {
        console.error('Error getting transaction summary:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil ringkasan transaksi',
          error: error.message
        });
      }
    }

    // API: Get employee activity summary
    static async getEmployeeActivity(req, res) {
      try {
        const sql = `
          SELECT 
            k.npk,
            k.nama,
            COUNT(CASE WHEN t.status_barang = 'Assignment' THEN 1 END) as active_assignments,
            COUNT(CASE WHEN t.status_barang = 'Masuk' THEN 1 END) as receiving_transactions,
            COUNT(t.kode_transaksi) as total_transactions
          FROM karyawan k
          LEFT JOIN transaksi t ON k.npk = t.npk
          GROUP BY k.npk, k.nama
          HAVING COUNT(t.kode_transaksi) > 0
          ORDER BY active_assignments DESC, total_transactions DESC
          LIMIT 10
        `;

        const { query } = require('../config/db');
        const result = await query(sql);

        res.json({
          success: true,
          data: result.rows
        });
      } catch (error) {
        console.error('Error getting employee activity:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil aktivitas karyawan',
          error: error.message
        });
      }
    }

    // API: Get warehouse utilization
    static async getWarehouseUtilization(req, res) {
      try {
        const warehouses = await GudangModel.getAll();
        const utilization = [];

        for (const warehouse of warehouses) {
          const stockDetails = await GudangModel.getStockDetails(warehouse.id_gudang);
          
          utilization.push({
            id: warehouse.id_gudang,
            nama_gudang: warehouse.nama_gudang,
            total_items: stockDetails.length,
            current_stock: warehouse.current_stock || 0,
            total_transactions: warehouse.total_transactions || 0,
            low_stock_items: stockDetails.filter(item => (item.current_stock || 0) < 5).length
          });
        }

        res.json({
          success: true,
          data: utilization
        });
      } catch (error) {
        console.error('Error getting warehouse utilization:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil utilitas gudang',
          error: error.message
        });
      }
    }

    // API: Get recent activities
    static async getRecentActivities(req, res) {
      try {
        const { limit = 20 } = req.query;

        const sql = `
          SELECT 
            'transaction' as activity_type,
            t.kode_transaksi as reference,
            t.status_barang as action,
            t.tanggal as timestamp,
            t.nama as actor,
            CONCAT(t.status_barang, ' - ', t.nama_barang, ' (', t.qty_stok, ' qty)') as description
          FROM transaksi t
          ORDER BY t.tanggal DESC
          LIMIT $1
        `;

        const { query } = require('../config/db');
        const result = await query(sql, [parseInt(limit)]);

        res.json({
          success: true,
          data: result.rows
        });
      } catch (error) {
        console.error('Error getting recent activities:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil aktivitas terbaru',
          error: error.message
        });
      }
    }

    // API: Get category statistics
    static async getCategoryStats(req, res) {
      try {
        const categories = await BarangModel.getCategories();
        
        res.json({
          success: true,
          data: categories
        });
      } catch (error) {
        console.error('Error getting category stats:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil statistik kategori',
          error: error.message
        });
      }
    }

    // API: Get stock alerts
    static async getStockAlerts(req, res) {
      try {
        const lowStockItems = await BarangModel.getLowStockItems(5);
        
        const alerts = lowStockItems.map(item => ({
          type: 'low_stock',
          severity: item.current_stock === 0 ? 'critical' : 'warning',
          title: 'Low Stock Alert',
          message: `${item.nama_barang} stock is ${item.current_stock === 0 ? 'out of stock' : 'running low'}`,
          item_id: item.id_barang,
          current_stock: item.current_stock,
          warehouse: item.nama_gudang
        }));

        res.json({
          success: true,
          data: alerts
        });
      } catch (error) {
        console.error('Error getting stock alerts:', error);
        res.status(500).json({
          success: false,
          message: 'Gagal mengambil alert stok',
          error: error.message
        });
      }
    }
  }

  module.exports = DashboardController;