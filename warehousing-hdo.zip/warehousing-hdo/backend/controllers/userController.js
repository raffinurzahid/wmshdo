const UserModel = require('../models/userModel');

class UserController {
  // Get all users
  static async getAllUsers(req, res) {
    try {
      const users = await UserModel.getAll();
      
      res.json({
        success: true,
        data: users
      });
    } catch (error) {
      console.error('Error getting users:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch users',
        error: error.message
      });
    }
  }

  // Get user by ID
  static async getUserById(req, res) {
    try {
      const { id } = req.params;
      const user = await UserModel.getById(id);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }

      delete user.password;
      
      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      console.error('Error getting user:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch user',
        error: error.message
      });
    }
  }

  // Create new user
  static async createUser(req, res) {
    try {
      const { username, password, email, id_role } = req.body;

      if (!username || !password || !email || !id_role) {
        return res.status(400).json({
          success: false,
          message: 'Username, password, email, and role are required'
        });
      }

      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Password must be at least 6 characters'
        });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid email format'
        });
      }

      const createdBy = req.user?.username || 'system';
      const user = await UserModel.create(req.body, createdBy);

      delete user.password;

      res.status(201).json({
        success: true,
        message: 'User created successfully',
        data: user
      });
    } catch (error) {
      console.error('Error creating user:', error);
      
      if (error.message.includes('already exists')) {
        return res.status(409).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to create user',
        error: error.message
      });
    }
  }

  // Update user
  static async updateUser(req, res) {
    try {
      const { id } = req.params;
      const { username, email, id_role, password } = req.body;

      if (password && password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Password must be at least 6 characters'
        });
      }

      if (email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          return res.status(400).json({
            success: false,
            message: 'Invalid email format'
          });
        }
      }

      const updateData = {};
      if (username !== undefined) updateData.username = username;
      if (email !== undefined) updateData.email = email;
      if (id_role !== undefined) updateData.id_role = id_role;
      if (password !== undefined) updateData.password = password;

      const updatedBy = req.user?.username || null;
      const user = await UserModel.update(id, updateData, updatedBy);

      delete user.password;

      res.json({
        success: true,
        message: 'User updated successfully',
        data: user
      });
    } catch (error) {
      console.error('Error updating user:', error);
      
      if (error.message.includes('not found')) {
        return res.status(404).json({
          success: false,
          message: error.message
        });
      }

      if (error.message.includes('already exists')) {
        return res.status(409).json({
          success: false,
          message: error.message
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to update user',
        error: error.message
      });
    }
  }

  // Soft delete user
  static async softDeleteUser(req, res) {
    try {
      const { id } = req.params;

      if (req.user?.id_user === id) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete your own account'
        });
      }

      const deletedBy = req.user?.username || null;
      const user = await UserModel.softDelete(id, deletedBy);

      res.json({
        success: true,
        message: 'User soft deleted successfully',
        data: user
      });
    } catch (error) {
      console.error('Error soft deleting user:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to soft delete user',
        error: error.message
      });
    }
  }

  // Hard delete user
  static async deleteUser(req, res) {
    try {
      const { id } = req.params;

      if (req.user?.id_user === id) {
        return res.status(400).json({
          success: false,
          message: 'Cannot delete your own account'
        });
      }

      const user = await UserModel.delete(id);

      res.json({
        success: true,
        message: 'User permanently deleted',
        data: user
      });
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to delete user',
        error: error.message
      });
    }
  }

  // Restore soft deleted user
  static async restoreUser(req, res) {
    try {
      const { id } = req.params;
      const user = await UserModel.restore(id);

      res.json({
        success: true,
        message: 'User restored successfully',
        data: user
      });
    } catch (error) {
      console.error('Error restoring user:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to restore user',
        error: error.message
      });
    }
  }

  // Search users
  static async searchUsers(req, res) {
    try {
      const { q } = req.query;

      if (!q || q.trim().length < 2) {
        return res.status(400).json({
          success: false,
          message: 'Search query must be at least 2 characters'
        });
      }

      const users = await UserModel.search(q.trim());

      res.json({
        success: true,
        data: users
      });
    } catch (error) {
      console.error('Error searching users:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to search users',
        error: error.message
      });
    }
  }

  // Get users by role
  static async getUsersByRole(req, res) {
    try {
      const { roleId } = req.params;
      const users = await UserModel.getByRole(roleId);

      res.json({
        success: true,
        data: users
      });
    } catch (error) {
      console.error('Error getting users by role:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch users by role',
        error: error.message
      });
    }
  }

  // Get user statistics
  static async getUserStats(req, res) {
    try {
      const stats = await UserModel.getStats();

      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error getting user stats:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch user statistics',
        error: error.message
      });
    }
  }
}

module.exports = UserController;