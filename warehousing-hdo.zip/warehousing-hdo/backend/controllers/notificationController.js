const NotificationModel = require('../models/NotificationModel');

class NotificationController {

    /** [API] Mengambil semua notifikasi milik user yang sedang login */
    static async getAll(req, res) {
        try {
            const userId = req.user?.id_user;
            
            if (!userId) {
                return res.json({ success: true, data: [] });
            }

            const notifications = await NotificationModel.getByUser(userId);
            res.json({ success: true, data: notifications || [] });
        } catch (error) {
            console.error('Error fetching notifications:', error.message);
            // Return empty array instead of error (graceful fallback)
            res.json({ success: true, data: [] });
        }
    }

    /** [API] Menghitung notifikasi yang belum dibaca */
    static async getUnreadCount(req, res) {
        try {
            const userId = req.user?.id_user;
            
            if (!userId) {
                return res.json({ success: true, data: { count: 0 } });
            }

            const count = await NotificationModel.countUnread(userId);
            res.json({ success: true, data: { count: count || 0 } });
        } catch (error) {
            console.error('Error fetching unread count:', error.message);
            res.json({ success: true, data: { count: 0 } });
        }
    }

    /** [API] Menandai satu notifikasi sebagai sudah dibaca */
    static async markRead(req, res) {
        try {
            const { id } = req.params;
            const userId = req.user?.id_user;

            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }

            const notification = await NotificationModel.markAsRead(id, userId);
            
            res.json({ 
                success: true, 
                message: 'Notifikasi ditandai sudah dibaca.',
                data: notification || {}
            });
        } catch (error) {
            console.error('Error marking notification as read:', error.message);
            res.json({ success: true, message: 'Notifikasi sudah dibaca' });
        }
    }

    /** [API] Menandai semua notifikasi sebagai sudah dibaca */
    static async markAllRead(req, res) {
        try {
            const userId = req.user?.id_user;

            if (!userId) {
                return res.status(401).json({ success: false, message: 'Unauthorized' });
            }

            const updatedCount = await NotificationModel.markAllAsRead(userId);
            res.json({ 
                success: true, 
                message: `${updatedCount || 0} notifikasi ditandai sudah dibaca.` 
            });
        } catch (error) {
            console.error('Error marking all notifications as read:', error.message);
            res.json({ success: true, message: 'Semua notifikasi ditandai sudah dibaca' });
        }
    }
}

/**
 * [HELPER] Fungsi untuk membuat notifikasi terkait transaksi secara otomatis.
 * Fungsi ini akan dipanggil dari file lain (contoh: TransaksiModel).
 */
const createTransactionNotification = async (transactionData) => {
    try {
        const { jenis_transaksi, nama_barang, qty_stok, nama_employee, created_by, id_transaksi } = transactionData;
        
        const configs = {
            'Receiving': { 
                title: "Barang Masuk", 
                icon: "fas fa-download", 
                color: "#28a745", 
                message: `${qty_stok} unit ${nama_barang} telah diterima.` 
            },
            'Assignment': { 
                title: "Barang Ditugaskan", 
                icon: "fas fa-user-plus", 
                color: "#ffc107", 
                message: `${nama_barang} telah ditugaskan ke ${nama_employee || 'karyawan'}.` 
            },
            'Disposal': { 
                title: "Barang Dibuang", 
                icon: "fas fa-trash", 
                color: "#dc3545", 
                message: `${nama_barang} telah ditandai untuk dibuang.` 
            }
        };

        const config = configs[jenis_transaksi];
        if (!config) {
            console.log(`No config for transaction type: ${jenis_transaksi}`);
            return;
        }

        const notificationData = {
            id_user: created_by,
            title: config.title,
            message: config.message,
            type: 'transaction',
            icon: config.icon,
            color: config.color,
            reference_id: id_transaksi
        };
        
        await NotificationModel.create(notificationData);
        console.log(`Notifikasi transaksi '${jenis_transaksi}' berhasil dibuat`);
    } catch (error) {
        console.error('Gagal membuat notifikasi transaksi:', error.message);
        // Don't throw - graceful failure
    }
};

module.exports = { NotificationController, createTransactionNotification };