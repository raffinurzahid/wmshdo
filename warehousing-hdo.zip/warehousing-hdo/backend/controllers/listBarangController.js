const ListBarangModel = require('../models/listBarangModel');

class ListBarangController {

    /** Get all items */
    static async getAllItems(req, res) {
        try {
            console.log('[ListBarang Controller] Fetching all items...');
            const items = await ListBarangModel.getAll();
            
            console.log('[ListBarang Controller] Success! Total:', items.length);
            res.json({ 
                success: true, 
                data: items 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Get All Error:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Failed to fetch list barang',
                error: error.message 
            });
        }
    }

    /** Get items by status (New/Second) */
    static async getItemsByStatus(req, res) {
        try {
            const { status } = req.params;
            
            if (!['New', 'Second'].includes(status)) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Invalid status. Must be "New" or "Second"' 
                });
            }
            
            const items = await ListBarangModel.getByStatus(status);
            res.json({ 
                success: true, 
                data: items 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Get By Status Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get items by asset state */
    static async getItemsByAssetState(req, res) {
        try {
            const { state } = req.params;
            
            const validStates = ['In Store', 'In Use', 'Disposal', 'Expired'];
            if (!validStates.includes(state)) {
                return res.status(400).json({ 
                    success: false, 
                    message: `Invalid asset state. Must be one of: ${validStates.join(', ')}` 
                });
            }
            
            const items = await ListBarangModel.getByAssetState(state);
            res.json({ 
                success: true, 
                data: items 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Get By Asset State Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Search items */
    static async searchItems(req, res) {
        try {
            const { q } = req.query;
            
            if (!q || q.trim().length < 2) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Search query must be at least 2 characters' 
                });
            }
            
            const items = await ListBarangModel.search(q.trim());
            res.json({ 
                success: true, 
                data: items 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Search Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get item by kode barang */
    static async getItemByKode(req, res) {
        try {
            const { kode } = req.params;
            
            const item = await ListBarangModel.getByKode(kode);
            
            if (!item) {
                return res.status(404).json({ 
                    success: false, 
                    message: `Item "${kode}" not found` 
                });
            }
            
            res.json({ 
                success: true, 
                data: item 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Get By Kode Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get statistics by base code */
    static async getStatsByBase(req, res) {
        try {
            const { kode_barang } = req.params;
            
            const stats = await ListBarangModel.getStatsByKode(kode_barang);

            
            if (!stats) {
                return res.status(404).json({ 
                    success: false, 
                    message: `No items found for base code "${kode_barang}"` 
                });
            }
            
            res.json({ 
                success: true, 
                data: stats 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Get Stats Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

    /** Get all items grouped by base code */
    static async getGroupedByBase(req, res) {
        try {
            const grouped = await ListBarangModel.getAllGroupedByBase();
            res.json({ 
                success: true, 
                data: grouped 
            });
        } catch (error) {
            console.error('[ListBarang Controller] Get Grouped Error:', error);
            res.status(500).json({ 
                success: false, 
                message: error.message 
            });
        }
    }

}

module.exports = ListBarangController;