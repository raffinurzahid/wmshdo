const { query } = require('../config/db');

class ListBarangController {
    /**
     * [GET] Ambil semua data barang dari tabel transaksi
     * (Digunakan untuk menampilkan daftar seluruh barang hasil transaksi)
     */
    static async getAllItems(req, res) {
        try {
            console.log('📦 [ListBarang] Fetching all items from transaksi...');

            const sql = `
                SELECT 
                    t.id_transaksi,
                    t.kode_transaksi,
                    t.jenis_transaksi,
                    t.kode_barang,
                    t.nama_barang,
                    t.jenis_barang,
                    t.spesifikasi,
                    t.qty_stok,
                    t.status AS asset_state,
                    t.asset_state AS status_barang,
                    t.npk,
                    t.nama_employee,
                    t.lokasi,
                    t.tanggal,
                    t.created_at,
                    t.keterangan
                FROM transaksi t
                WHERE t.deleted_at IS NULL
                ORDER BY t.created_at DESC;
            `;

            const result = await query(sql);

            console.log(`✅ [ListBarang] Total items fetched: ${result.rows.length}`);

            res.json({
                success: true,
                message: 'List barang berhasil diambil.',
                total: result.rows.length,
                data: result.rows
            });

        } catch (error) {
            console.error('[ListBarang] ❌ Get All Error:', error);
            res.status(500).json({
                success: false,
                message: 'Gagal mengambil data list barang.',
                error: error.message
            });
        }
    }

    /**
     * [GET] Ambil data barang berdasarkan jenis transaksi
     * (Receiving / Assignment / Disposal)
     */
    static async getItemsByType(req, res) {
        try {
            const { type } = req.params;

            console.log(`[ListBarang] Fetching items by transaction type: ${type}`);

            if (!type) {
                return res.status(400).json({
                    success: false,
                    message: 'Parameter "type" wajib diisi (Receiving, Assignment, Disposal).'
                });
            }

            const sql = `
                SELECT 
                    t.id_transaksi,
                    t.kode_transaksi,
                    t.jenis_transaksi,
                    t.kode_barang,
                    t.nama_barang,
                    t.jenis_barang,
                    t.spesifikasi,
                    t.qty_stok,
                    t.status AS asset_state,
                    t.npk,
                    t.nama_employee,
                    t.lokasi,
                    t.tanggal,
                    t.created_at,
                    t.keterangan
                FROM transaksi t
                WHERE t.deleted_at IS NULL
                    AND t.jenis_transaksi ILIKE $1
                ORDER BY t.created_at DESC;
            `;

            const result = await query(sql, [type]);

            res.json({
                success: true,
                message: `List barang berdasarkan jenis transaksi: ${type}`,
                total: result.rows.length,
                data: result.rows
            });

        } catch (error) {
            console.error('[ListBarang] ❌ Get By Type Error:', error);
            res.status(500).json({
                success: false,
                message: 'Gagal mengambil data berdasarkan jenis transaksi.',
                error: error.message
            });
        }
    }

    /**
     * [GET] Ambil data berdasarkan status asset (In Store, In Use, Disposal, Expired)
     */
    static async getItemsByAssetState(req, res) {
        try {
            const { state } = req.params;

            console.log(`[ListBarang] Fetching items by asset state: ${state}`);

            if (!state) {
                return res.status(400).json({
                    success: false,
                    message: 'Parameter "state" wajib diisi (contoh: In Store, In Use, Disposal).'
                });
            }

            const sql = `
                SELECT 
                    t.id_transaksi,
                    t.kode_transaksi,
                    t.jenis_transaksi,
                    t.kode_barang,
                    t.nama_barang,
                    t.jenis_barang,
                    t.spesifikasi,
                    t.qty_stok,
                    t.status AS asset_state,
                    t.npk,
                    t.nama_employee,
                    t.lokasi,
                    t.tanggal,
                    t.created_at,
                    t.keterangan
                FROM transaksi t
                WHERE t.deleted_at IS NULL
                    AND t.status ILIKE $1
                ORDER BY t.created_at DESC;
            `;

            const result = await query(sql, [state]);

            res.json({
                success: true,
                message: `List barang berdasarkan status: ${state}`,
                total: result.rows.length,
                data: result.rows
            });

        } catch (error) {
            console.error('[ListBarang] ❌ Get By Asset State Error:', error);
            res.status(500).json({
                success: false,
                message: 'Gagal mengambil data berdasarkan status asset.',
                error: error.message
            });
        }
    }

    /**
     * [GET] Pencarian barang berdasarkan keyword
     */
    static async searchItems(req, res) {
        try {
            const { q } = req.query;

            if (!q || q.trim().length < 2) {
                return res.status(400).json({
                    success: false,
                    message: 'Minimal 2 karakter untuk pencarian.'
                });
            }

            console.log(`[ListBarang] Searching items with keyword: "${q}"`);

            const sql = `
                SELECT 
                    t.id_transaksi,
                    t.kode_transaksi,
                    t.jenis_transaksi,
                    t.kode_barang,
                    t.nama_barang,
                    t.jenis_barang,
                    t.spesifikasi,
                    t.qty_stok,
                    t.status AS asset_state,
                    t.npk,
                    t.nama_employee,
                    t.lokasi,
                    t.tanggal,
                    t.created_at,
                    t.keterangan
                FROM transaksi t
                WHERE t.deleted_at IS NULL
                  AND (
                      t.kode_barang ILIKE $1 OR
                      t.nama_barang ILIKE $1 OR
                      t.jenis_barang ILIKE $1 OR
                      t.nama_employee ILIKE $1 OR
                      t.lokasi ILIKE $1 OR
                      t.keterangan ILIKE $1
                  )
                ORDER BY t.created_at DESC;
            `;

            const searchPattern = `%${q}%`;
            const result = await query(sql, [searchPattern]);

            res.json({
                success: true,
                message: `Pencarian untuk "${q}" berhasil.`,
                total: result.rows.length,
                data: result.rows
            });

        } catch (error) {
            console.error('[ListBarang] ❌ Search Error:', error);
            res.status(500).json({
                success: false,
                message: 'Gagal melakukan pencarian list barang.',
                error: error.message
            });
        }
    }

    /**
     * [GET] Statistik barang (total transaksi per jenis dan status)
     */
    static async getStatistics(req, res) {
        try {
            console.log('[ListBarang] Fetching statistics...');

            const sql = `
                SELECT
                    COUNT(*) AS total_items,
                    COUNT(*) FILTER (WHERE jenis_transaksi = 'Receiving') AS total_receiving,
                    COUNT(*) FILTER (WHERE jenis_transaksi = 'Assignment') AS total_assignment,
                    COUNT(*) FILTER (WHERE jenis_transaksi = 'Disposal') AS total_disposal,
                    COUNT(*) FILTER (WHERE status = 'In Store') AS total_in_store,
                    COUNT(*) FILTER (WHERE status = 'In Use') AS total_in_use,
                    COUNT(*) FILTER (WHERE status = 'Disposal') AS total_disposed,
                    COUNT(*) FILTER (WHERE status = 'Expired') AS total_expired,
                    SUM(qty_stok) AS total_quantity
                FROM transaksi
                WHERE deleted_at IS NULL;
            `;

            const result = await query(sql);

            res.json({
                success: true,
                message: 'Statistik list barang berhasil diambil.',
                data: result.rows[0]
            });

        } catch (error) {
            console.error('[ListBarang] ❌ Get Statistics Error:', error);
            res.status(500).json({
                success: false,
                message: 'Gagal mengambil statistik list barang.',
                error: error.message
            });
        }
    }
}

module.exports = ListBarangController;