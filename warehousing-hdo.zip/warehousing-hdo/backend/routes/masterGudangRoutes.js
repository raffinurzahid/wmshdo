const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

// GET warehouse summary
router.get('/summary', async (req, res) => {
  try {
    const sql = `
      SELECT 
        g.nama_gudang,
        COUNT(DISTINCT b.id_barang) as total_items,
        COUNT(DISTINCT b.id_barang) FILTER (
          WHERE (
            COALESCE((SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = b.id_barang AND id_gudang = g.id_gudang AND status_barang = 'Masuk'), 0) -
            COALESCE((SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = b.id_barang AND id_gudang = g.id_gudang AND status_barang IN ('Assignment', 'Disposal')), 0)
          ) < 5 AND (
            COALESCE((SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = b.id_barang AND id_gudang = g.id_gudang AND status_barang = 'Masuk'), 0) -
            COALESCE((SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = b.id_barang AND id_gudang = g.id_gudang AND status_barang IN ('Assignment', 'Disposal')), 0)
          ) > 0
        ) as low_stock_items
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      GROUP BY g.nama_gudang
    `;
    
    const result = await query(sql);
    
    const warehouses = {};
    let totalItems = 0;
    let totalLowStock = 0;
    
    result.rows.forEach(row => {
      const total = parseInt(row.total_items) || 0;
      const lowStock = parseInt(row.low_stock_items) || 0;
      
      warehouses[row.nama_gudang] = {
        total: total,
        lowStock: lowStock
      };
      
      totalItems += total;
      totalLowStock += lowStock;
    });
    
    res.json({
      success: true,
      warehouses: warehouses,
      overall: {
        total: totalItems,
        lowStock: totalLowStock
      }
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch warehouse summary' });
  }
});

// GET warehouse inventory (keep for compatibility)
router.get('/', async (req, res) => {
  const { warehouse } = req.query;
  
  if (!warehouse) {
    return res.status(400).json({ success: false, message: 'Warehouse parameter required' });
  }

  try {
    const sql = `
      SELECT 
        b.id_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        COALESCE(
          (SELECT SUM(qty_stok) FROM transaksi 
           WHERE id_barang = b.id_barang 
           AND status_barang = 'Masuk' 
           AND id_gudang = (SELECT id_gudang FROM gudang WHERE nama_gudang = $1)),
          0
        ) - COALESCE(
          (SELECT SUM(qty_stok) FROM transaksi 
           WHERE id_barang = b.id_barang 
           AND status_barang IN ('Assignment', 'Disposal') 
           AND id_gudang = (SELECT id_gudang FROM gudang WHERE nama_gudang = $1)),
          0
        ) as qty_stok
      FROM barang b
      WHERE EXISTS (
        SELECT 1 FROM transaksi t
        WHERE t.id_barang = b.id_barang
        AND t.id_gudang = (SELECT id_gudang FROM gudang WHERE nama_gudang = $1)
      )
      ORDER BY b.nama_barang
    `;
    
    const result = await query(sql, [warehouse]);
    res.json({ success: true, items: result.rows });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch warehouse items' });
  }
});

module.exports = router;