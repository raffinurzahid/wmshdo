const express = require('express');
const router = express.Router();
const masterGudangController = require('../controllers/masterGudangController');
const { optionalAuth } = require('../middleware/authMiddleware');

console.log('✅ masterGudangRoutes.js loaded');

// Get all inventory
router.get('/inventory', optionalAuth, (req, res, next) => {
    console.log('🔍 GET /api/master-gudang/inventory');
    masterGudangController.getInventory(req, res, next);
});

// Get inventory by location
router.get('/inventory/location', optionalAuth, (req, res, next) => {
    console.log('🔍 GET /api/master-gudang/inventory/location');
    masterGudangController.getInventoryByLocation(req, res, next);
});

// Search inventory
router.get('/inventory/search', optionalAuth, (req, res, next) => {
    console.log('🔍 GET /api/master-gudang/inventory/search');
    masterGudangController.searchInventory(req, res, next);
});

console.log('✅ masterGudangRoutes registered successfully');

module.exports = router;