const express = require('express');
const router = express.Router();

// 🔥 IMPORT CONTROLLER (login, logout, dll)
const { 
  login, 
  logout, 
  getCurrentUser, 
  changePassword, 
  refreshToken
} = require('../controllers/authController'); 

// 🔥 IMPORT MIDDLEWARE (requireAuth DAN MIDDLEWARE BARU UNTUK HALAMAN)
const { requireAuth, redirectIfLoggedIn } = require('../middleware/authMiddleware');

// GET /login -> Menampilkan halaman form login
// DITAMBAHKAN MIDDLEWARE 'redirectIfLoggedIn' untuk mencegah user yang sudah login mengakses halaman ini lagi.
router.get('/login', redirectIfLoggedIn, (req, res) => {
    res.render('pages/login', {
        title: 'Login - WMS Help Desk',
        currentPage: 'login'
    });
});

// POST /api/auth/login -> Memproses data login dari form
router.post('/api/auth/login', login);

// POST /api/auth/logout -> Logout (menghapus token cookie)
router.post('/api/auth/logout', logout);

// GET /api/auth/me -> Mendapatkan info user yang sedang login
router.get('/api/auth/me', requireAuth, getCurrentUser);

// POST /api/auth/change-password -> Mengubah password user yang sedang login
router.post('/api/auth/change-password', requireAuth, changePassword);

// POST /api/auth/refresh-token -> Memperbarui token JWT
router.post('/api/auth/refresh-token', requireAuth, refreshToken);

module.exports = router;