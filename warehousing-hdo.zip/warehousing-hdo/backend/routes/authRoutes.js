const express = require('express');
const router = express.Router();
const { login, logout, getCurrentUser } = require('../middleware/authMiddleware');

// Login Admin
router.post('/login', login);

// Logout
router.post('/logout', logout);

// Get Current User Info
router.get('/me', getCurrentUser);

module.exports = router;
