const express = require('express');
const router = express.Router();

const { NotificationController } = require('../controllers/notificationController');
const { requireAuth } = require('../middleware/authMiddleware');

// Semua rute di bawah ini memerlukan user untuk login
router.use(requireAuth);

// GET /api/notifications -> Mengambil semua notifikasi
router.get('/', NotificationController.getAll);

// GET /api/notifications/unread-count -> Menghitung notifikasi belum dibaca
router.get('/unread-count', NotificationController.getUnreadCount);

// PUT /api/notifications/read-all -> Menandai semua sebagai sudah dibaca
router.put('/read-all', NotificationController.markAllRead);


// PUT /api/notifications/:id/read -> Menandai satu notifikasi sebagai sudah dibaca
router.put('/:id/read', NotificationController.markRead);

module.exports = router;