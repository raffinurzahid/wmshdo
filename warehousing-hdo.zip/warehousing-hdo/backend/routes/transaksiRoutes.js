const express = require('express');
const router = express.Router();
const { query } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

let createTransactionNotification = null;

const setNotificationCreator = (notificationCreator) => {
  createTransactionNotification = notificationCreator;
};

// Helper: Generate transaction ID
async function generateTransactionId(type) {
  try {
    const prefixMap = { RCV: 'RCV', ASS: 'ASG', DISP: 'DPS' };
    const prefix = prefixMap[type] || 'TXN';
    
    const statusMap = { RCV: 'Masuk', ASS: 'Assignment', DISP: 'Disposal' };
    const statusFilter = statusMap[type];
    
    let countQuery = 'SELECT COUNT(*) as count FROM transaksi';
    let queryParams = [];
    
    if (statusFilter) {
      countQuery += ' WHERE status_barang = $1';
      queryParams.push(statusFilter);
    }
    
    const result = await query(countQuery, queryParams);
    const count = parseInt(result.rows[0].count) + 1;
    
    return `${prefix}${count.toString().padStart(5, '0')}`;
  } catch (error) {
    console.error('Error generating ID:', error);
    return `${type}${Date.now()}`;
  }
}

// Helper: Get gudang ID from name
async function getGudangId(locationName) {
  try {
    const result = await query('SELECT id_gudang FROM gudang WHERE nama_gudang = $1', [locationName]);
    if (result.rows.length > 0) {
      return result.rows[0].id_gudang;
    }
    throw new Error(`Gudang tidak ditemukan: ${locationName}`);
  } catch (error) {
    console.error('Error getting gudang ID:', error);
    throw error;
  }
}

// GET all transactions
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 100, type, status, date } = req.query;
    
    let queryStr = `
      SELECT t.*, g.nama_gudang 
      FROM transaksi t 
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang 
      WHERE 1=1
    `;
    const queryParams = [];
    let paramCount = 0;

    if (type) {
      paramCount++;
      const statusMap = { RCV: 'Masuk', ASS: 'Assignment', DISP: 'Disposal' };
      queryStr += ` AND t.status_barang = $${paramCount}`;
      queryParams.push(statusMap[type]);
    }

    if (status) {
      paramCount++;
      const statusMap = { 'In Store': 'Masuk', 'In Use': 'Assignment', 'Disposal': 'Disposal', 'Expired': 'Disposal' };
      queryStr += ` AND t.status_barang = $${paramCount}`;
      queryParams.push(statusMap[status]);
    }

    if (date) {
      paramCount++;
      queryStr += ` AND DATE(t.tanggal) = $${paramCount}`;
      queryParams.push(date);
    }

    queryStr += ' ORDER BY t.tanggal DESC';

    const result = await query(queryStr, queryParams);
    
    const transformedData = result.rows.map(row => ({
      id: row.id_transaksi || row.kode_transaksi,
      transaction_id: row.kode_transaksi,
      type: row.status_barang === 'Masuk' ? 'RCV' : row.status_barang === 'Assignment' ? 'ASS' : 'DISP',
      id_barang: row.id_barang,
      nama_barang: row.nama_barang,
      spesifikasi: row.jenis_barang,
      quantity: row.qty_stok,
      status: row.status_barang === 'Masuk' ? 'In Store' : row.status_barang === 'Assignment' ? 'In Use' : 'Disposal',
      nama: row.nama,
      npk: row.npk,
      location: row.nama_gudang || 'Unknown',
      keterangan: row.keterangan,
      datetime: row.tanggal
    }));

    res.json({ success: true, data: transformedData, total: result.rowCount });
  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// GET item by ID for auto-fill (check if not already used)
router.get('/items/:id_barang', async (req, res) => {
  const { id_barang } = req.params;
  
  try {
    console.log('Fetching item for auto-fill:', id_barang);
    
    // Check if item already used (Assignment or Disposal)
    const checkExitQuery = `
      SELECT COUNT(*) as exit_count 
      FROM transaksi 
      WHERE id_barang = $1 
        AND status_barang IN ('Assignment', 'Disposal')
    `;
    
    const exitCheck = await query(checkExitQuery, [id_barang]);
    
    if (parseInt(exitCheck.rows[0].exit_count) > 0) {
      return res.status(404).json({
        success: false,
        message: 'ID Barang sudah keluar (Assignment/Disposal). Item tidak dapat digunakan lagi.'
      });
    }
    
    // Get item data from last Receiving transaction
    const result = await query(
      `SELECT DISTINCT ON (id_barang) 
        id_barang, 
        nama_barang, 
        jenis_barang as spesifikasi
      FROM transaksi 
      WHERE id_barang = $1 
        AND status_barang = 'Masuk'
      ORDER BY id_barang, tanggal DESC
      LIMIT 1`,
      [id_barang]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'ID Barang tidak ditemukan dalam sistem.'
      });
    }

    const item = result.rows[0];
    
    res.json({
      success: true,
      data: {
        id_barang: item.id_barang,
        nama_barang: item.nama_barang,
        spesifikasi: item.spesifikasi || ''
      }
    });

  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({
      success: false,
      message: 'Terjadi kesalahan saat mengambil data barang',
      error: err.message
    });
  }
});

// GET transaction by ID
router.get('/transactions/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const result = await query(
      `SELECT t.*, g.nama_gudang 
       FROM transaksi t 
       LEFT JOIN gudang g ON t.id_gudang = g.id_gudang 
       WHERE t.id_transaksi = $1`,
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan' });
    }

    const row = result.rows[0];
    const transformedData = {
      id: row.id_transaksi || row.kode_transaksi,
      transaction_id: row.kode_transaksi,
      type: row.status_barang === 'Masuk' ? 'RCV' : row.status_barang === 'Assignment' ? 'ASS' : 'DISP',
      id_barang: row.id_barang,
      nama_barang: row.nama_barang,
      spesifikasi: row.jenis_barang,
      quantity: row.qty_stok,
      status: row.status_barang === 'Masuk' ? 'In Store' : row.status_barang === 'Assignment' ? 'In Use' : 'Disposal',
      nama: row.nama,
      npk: row.npk,
      location: row.nama_gudang || 'Unknown',
      keterangan: row.keterangan,
      datetime: row.tanggal
    };

    res.json({ success: true, data: transformedData });
  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST create transaction (supports batch for RCV)
router.post('/', async (req, res) => {
  try {
    console.log('Request body:', req.body);

    // Check if batch (for RCV)
    if (req.body.transactions && Array.isArray(req.body.transactions)) {
      const results = [];
      
      for (const txData of req.body.transactions) {
        const transactionId = uuidv4();
        const transactionCode = await generateTransactionId(txData.type);
        const finalGudangId = await getGudangId(txData.location);
        
        let timestampValue;
        if (txData.datetime) {
          const date = new Date(txData.datetime);
          timestampValue = date.toISOString().slice(0, 19).replace('T', ' ');
        } else {
          const now = new Date();
          timestampValue = now.toISOString().slice(0, 19).replace('T', ' ');
        }

        const insertQuery = `
          INSERT INTO transaksi 
            (id_transaksi, kode_transaksi, id_barang, nama_barang, npk, nama, status_barang, qty_stok, tanggal, id_gudang, jenis_barang, keterangan) 
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) 
          RETURNING *
        `;

        const queryParams = [
          transactionId,
          transactionCode,
          txData.id_barang,
          txData.nama_barang,
          txData.npk || null,
          txData.nama || null,
          txData.status_barang || 'Masuk',
          parseInt(txData.qty_stok),
          timestampValue,
          finalGudangId,
          txData.jenis_barang || 'General',
          txData.keterangan || ''
        ];

        const result = await query(insertQuery, queryParams);
        results.push(result.rows[0]);
      }

      if (createTransactionNotification) {
        createTransactionNotification({ type: 'RCV', quantity: results.length }, 'RCV');
      }

      return res.status(201).json({ 
        success: true, 
        message: `${results.length} transactions created successfully`, 
        data: results 
      });
    }

    // Single transaction
    const { type, id_barang, nama_barang, jenis_barang, qty_stok, status_barang, nama, npk, location, keterangan, datetime } = req.body;

    if (!type || !id_barang || !nama_barang || !qty_stok || !location) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: type, id_barang, nama_barang, qty_stok, location'
      });
    }

    // Check if item already used (for ASS/DISP)
    if (type === 'ASS' || type === 'DISP') {
      const checkQuery = `
        SELECT COUNT(*) as exit_count 
        FROM transaksi 
        WHERE id_barang = $1 
          AND status_barang IN ('Assignment', 'Disposal')
      `;
      
      const checkResult = await query(checkQuery, [id_barang]);
      
      if (parseInt(checkResult.rows[0].exit_count) > 0) {
        return res.status(400).json({
          success: false,
          message: 'ID Barang sudah pernah keluar. Tidak dapat digunakan lagi.'
        });
      }
    }

    const transactionId = uuidv4();
    const transactionCode = await generateTransactionId(type);
    
    const statusMap = { RCV: 'Masuk', ASS: 'Assignment', DISP: 'Disposal' };
    const finalStatus = statusMap[type] || status_barang || 'Masuk';
    const finalGudangId = await getGudangId(location);

    if (type === 'ASS' && (!nama || !npk)) {
      return res.status(400).json({
        success: false,
        message: 'Name and NPK required for assignment'
      });
    }

    let timestampValue;
    if (datetime) {
      const date = new Date(datetime);
      timestampValue = date.toISOString().slice(0, 19).replace('T', ' ');
    } else {
      const now = new Date();
      timestampValue = now.toISOString().slice(0, 19).replace('T', ' ');
    }

    const insertQuery = `
      INSERT INTO transaksi 
        (id_transaksi, kode_transaksi, id_barang, nama_barang, npk, nama, status_barang, qty_stok, tanggal, id_gudang, jenis_barang, keterangan) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) 
      RETURNING *
    `;

    const queryParams = [
      transactionId,
      transactionCode,
      id_barang,
      nama_barang,
      npk || null,
      nama || null,
      finalStatus,
      parseInt(qty_stok),
      timestampValue,
      finalGudangId,
      jenis_barang || 'General',
      keterangan || ''
    ];

    const result = await query(insertQuery, queryParams);
    const newTransaction = result.rows[0];
    
    const transformedData = {
      id: newTransaction.id_transaksi || newTransaction.kode_transaksi,
      transaction_id: newTransaction.kode_transaksi,
      type: type,
      id_barang: newTransaction.id_barang,
      nama_barang: newTransaction.nama_barang,
      spesifikasi: newTransaction.jenis_barang,
      quantity: newTransaction.qty_stok,
      status: finalStatus === 'Masuk' ? 'In Store' : finalStatus === 'Assignment' ? 'In Use' : 'Disposal',
      nama: newTransaction.nama,
      npk: newTransaction.npk,
      location: location,
      keterangan: newTransaction.keterangan,
      datetime: newTransaction.tanggal
    };

    if (createTransactionNotification) {
      createTransactionNotification(transformedData, type);
    }

    res.status(201).json({ 
      success: true, 
      message: 'Transaction created successfully', 
      data: transformedData 
    });

  } catch (err) {
    console.error('Error:', err.message);
    console.error('Stack:', err.stack);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to create transaction',
      error: err.message 
    });
  }
});

// PUT update transaction (edit all fields)
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { quantity, location, keterangan, npk, nama } = req.body;

  try {
    // Get current transaction
    const currentTx = await query('SELECT * FROM transaksi WHERE id_transaksi = $1 OR kode_transaksi = $1', [id]);
    
    if (currentTx.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Transaction not found' });
    }

    const current = currentTx.rows[0];
    
    // Get new gudang ID if location changed
    let newGudangId = current.id_gudang;
    if (location && location !== current.nama_gudang) {
      newGudangId = await getGudangId(location);
    }

    const updateQuery = `
      UPDATE transaksi 
      SET 
        qty_stok = COALESCE($1, qty_stok),
        id_gudang = COALESCE($2, id_gudang),
        keterangan = COALESCE($3, keterangan),
        npk = COALESCE($4, npk),
        nama = COALESCE($5, nama)
      WHERE id_transaksi = $6 OR kode_transaksi = $6
      RETURNING *
    `;

    const result = await query(updateQuery, [
      quantity || current.qty_stok,
      newGudangId,
      keterangan !== undefined ? keterangan : current.keterangan,
      npk !== undefined ? npk : current.npk,
      nama !== undefined ? nama : current.nama,
      id
    ]);

    res.json({ 
      success: true, 
      message: 'Transaction updated successfully', 
      data: result.rows[0] 
    });

  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to update transaction',
      error: err.message 
    });
  }
});

// DELETE transaction
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  
  try {
    const result = await query(
      'DELETE FROM transaksi WHERE kode_transaksi = $1 OR id_transaksi::text = $1 RETURNING *',
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Transaction not found' });
    }
    
    res.json({ 
      success: true, 
      message: 'Transaction deleted successfully', 
      data: result.rows[0] 
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to delete transaction',
      error: error.message 
    });
  }
});

// GET dashboard stats
router.get('/dashboard/stats', async (req, res) => {
  try {
    const result = await query(`
      SELECT 
        COUNT(*) AS total_transactions,
        COUNT(*) FILTER (WHERE status_barang = 'Masuk') AS total_masuk,
        COUNT(*) FILTER (WHERE status_barang = 'Assignment') AS total_assignment,
        COUNT(*) FILTER (WHERE status_barang = 'Disposal') AS total_disposal
      FROM transaksi
    `);

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Export setter
router.setNotificationCreator = setNotificationCreator;

module.exports = router;