const express = require('express');
const router = express.Router();
const transaksiController = require('../controllers/transaksiController');
const { optionalAuth } = require('../middleware/authMiddleware');

console.log('✅ transaksiRoutes.js loaded');

// Get all transactions
router.get('/', optionalAuth, (req, res, next) => {
  console.log('🔍 GET /api/transaksi');
  transaksiController.getAllTransactions(req, res, next);
});

// Get last code (must be befo                          re /:id route)
router.get('/last-code', optionalAuth, (req, res, next) => {
  console.log('🔍 GET /api/transaksi/last-code');
  transaksiController.getLastCode(req, res, next);
});

// Search transactions
router.get('/search', optionalAuth, (req, res, next) => {
  console.log('🔍 GET /api/transaksi/search');
  transaksiController.searchTransactions(req, res, next);
});

// Get stats
router.get('/stats', optionalAuth, (req, res, next) => {
  console.log('🔍 GET /api/transaksi/stats');
  transaksiController.getDashboardStats(req, res, next);
});

router.get('/available-item', optionalAuth, (req, res, next) => {
  console.log('🔍 GET /api/transaksi/available-item');
  transaksiController.getAvailableItemDetails(req, res, next);
});

// Get transaction by ID
router.get('/:id', optionalAuth, (req, res, next) => {
  console.log('🔍 GET /api/transaksi/:id');
  transaksiController.getTransactionById(req, res, next);
});

// Create transaction
router.post('/', optionalAuth, (req, res, next) => {
  console.log('🔍 POST /api/transaksi');
  transaksiController.createSingleTransaction(req, res, next);
});

// Update transaction
router.put('/:id', optionalAuth, (req, res, next) => {
  console.log('🔍 PUT /api/transaksi/:id');
  transaksiController.updateTransaction(req, res, next);
});

// Soft delete transaction
router.delete('/:id/soft', optionalAuth, (req, res, next) => {
  console.log('🔍 DELETE /api/transaksi/:id/soft');
  transaksiController.softDeleteTransaction(req, res, next);
});

// Hard delete transaction
router.delete('/:id', optionalAuth, (req, res, next) => {
  console.log('🔍 DELETE /api/transaksi/:id');
  transaksiController.deleteTransaction(req, res, next);
});

// Restore transaction
router.post('/:id/restore', optionalAuth, (req, res, next) => {
  console.log('🔍 POST /api/transaksi/:id/restore');
  transaksiController.restoreTransaction(req, res, next);
});

console.log('✅ transaksiRoutes registered successfully');

module.exports = router;