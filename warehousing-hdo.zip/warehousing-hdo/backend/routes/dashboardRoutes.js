const express = require('express');
const router = express.Router();
const DashboardController = require('../controllers/dashboardController');

// 🔥 IMPORT DARI MIDDLEWARE
const { requireAuth, requirePageView, requireRole } = require('../middleware/authMiddleware');

// ===== HALAMAN (GET) =====
router.get('/', requirePageView, DashboardController.getDashboardPage);
router.get('/dashboard', (req, res) => res.redirect('/'));

router.get('/master-barang', requirePageView, (req, res) => {
  res.render('pages/master-barang', {
    title: 'Master Data Barang - WMS',
    currentPage: 'master-barang'
  });
});

router.get('/master-gudang', requirePageView, (req, res) => {
  res.render('pages/master-gudang', {
    title: 'Master Gudang Barang - WMS',
    currentPage: 'master-gudang'
  });
});

router.get('/transaksi', requirePageView, (req, res) => {
  res.render('pages/transaksi', {
    title: 'Transactions - WMS Help Desk',
    currentPage: 'transaksi'
  });
});

// 🔥 ROUTE PROFILE BARU
router.get('/profile', requirePageView, (req, res) => {
  res.render('pages/profile', {
    title: 'My Profile - WMS Help Desk',
    currentPage: 'profile'
  });
});

// ===== API ROUTES (REST) =====
router.use('/api/dashboard', requireAuth);

router.get('/api/dashboard/summary', requireRole(['admin', 'user']), DashboardController.getSummaryStats);
router.get('/api/dashboard/inventory', requireRole(['admin', 'user']), DashboardController.getInventoryOverview);
router.get('/api/dashboard/transaction-summary', requireRole('admin'), DashboardController.getTransactionChartData);
router.get('/api/dashboard/user-activity', requireRole('admin'), DashboardController.getUserActivitySummary);
router.get('/api/dashboard/warehouse-utilization', requireRole('admin'), DashboardController.getWarehouseUtilization);
router.get('/api/dashboard/recent-activities', requireRole(['admin', 'user']), DashboardController.getRecentActivities);
router.get('/api/dashboard/category-stats', requireRole(['admin', 'user']), DashboardController.getCategoryStats);
router.get('/api/dashboard/stock-alerts', requireRole('admin'), DashboardController.getStockAlerts);
router.get('/api/dashboard/system-stats', requireRole('admin'), DashboardController.getSystemStats);

module.exports = router;