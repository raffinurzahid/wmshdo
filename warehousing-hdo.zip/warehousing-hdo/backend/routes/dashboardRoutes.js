const express = require('express');
const router = express.Router();
const { query } = require('../config/db'); // pastikan path sesuai

// =========================
// 🔹 Route UI: dashboard & transaksi
// =========================
router.get('/', async (req, res) => {
  try {
    // Ambil summary dari database
    const totalKaryawan = await query('SELECT COUNT(*) FROM karyawan');
    const totalGudang = await query('SELECT COUNT(*) FROM gudang');
    const totalBarang = await query('SELECT COUNT(*) FROM barang');
    const totalTransaksi = await query('SELECT COUNT(*) FROM transaksi');

    // Low stock item (stok < 5)
    const lowStockItems = await query(`
      SELECT b.id_barang, b.nama_barang, b.spesifikasi, b.qty_stok AS current_stock, g.nama_gudang
      FROM barang b
      JOIN gudang g ON g.id_gudang = b.id_gudang
      WHERE b.qty_stok < 5
      ORDER BY b.qty_stok ASC
      LIMIT 5
    `);

    // Recent transaksi
    const recentTransactions = await query(`
      SELECT kode_transaksi, status_barang, nama_barang, qty_stok, tanggal
      FROM transaksi
      ORDER BY tanggal DESC
      LIMIT 5
    `);

    res.render('pages/dashboard', {
      title: 'Dashboard - WMS Help Desk',
      currentPage: 'dashboard',
      totalKaryawan: parseInt(totalKaryawan.rows[0].count),
      totalGudang: parseInt(totalGudang.rows[0].count),
      totalMedicines: parseInt(totalBarang.rows[0].count), // alias aja biar ga ngubah EJS
      totalTransactions: parseInt(totalTransaksi.rows[0].count),
      totalDisposal: 0, // di bawah ada endpoint detailnya
      lowStockItems: lowStockItems.rows,
      recentTransactions: recentTransactions.rows,
    });
  } catch (err) {
    console.error('❌ Error loading dashboard:', err.message);
    res.status(500).send('Error loading dashboard');
  }
});

router.get('/dashboard', (req, res) => res.redirect('/'));

// Halaman transaksi
router.get('/transaksi', (req, res) => {
  res.render('pages/transaksi', {
    title: 'Transactions - WMS Help Desk',
    transactions: [],
    barang: [],
    karyawan: [],
    gudang: [],
    currentPage: 'transaksi'
  });
});

// =========================
// 🔹 API untuk dashboard.ejs
// =========================

// 1. Summary dashboard (equipment overview)
router.get('/api/dashboard', async (req, res) => {
  try {
    const totalBarang = await query('SELECT COUNT(*) FROM barang');
    const barangList = await query(`
      SELECT id_barang AS id, nama_barang AS name, spesifikasi AS category, qty_stok AS stock
      FROM barang
      ORDER BY nama_barang ASC
      LIMIT 10
    `);

    res.json({
      success: true,
      data: {
        totalShelfs: 0, // kalau kamu punya tabel rak bisa isi di sini
        totalMedicines: parseInt(totalBarang.rows[0].count),
        totalStocksQuality: parseInt(totalBarang.rows[0].count),
        totalSuppliers: 0, // isi kalau ada tabel supplier
        equipment: barangList.rows
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 2. Notifications (bell icon)
router.get('/api/notifications', async (req, res) => {
  try {
    const lowStock = await query(`
      SELECT nama_barang, qty_stok
      FROM barang
      WHERE qty_stok < 5
      LIMIT 3
    `);

    const latestTrans = await query(`
      SELECT kode_transaksi, nama_barang, status_barang
      FROM transaksi
      ORDER BY tanggal DESC
      LIMIT 1
    `);

    res.json({
      success: true,
      data: [
        {
          id: 1,
          type: 'low_stock',
          title: 'Low Stock Alert',
          message: `${lowStock.rowCount} barang hampir habis stoknya`,
          created_at: new Date(),
          read: false
        },
        {
          id: 2,
          type: 'transaction',
          title: 'New Transaction',
          message: latestTrans.rowCount > 0
            ? `Transaksi baru: ${latestTrans.rows[0].kode_transaksi} (${latestTrans.rows[0].nama_barang})`
            : 'Belum ada transaksi',
          created_at: new Date(),
          read: false
        }
      ]
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 3. Transaction stats (buat chart transaksi)
router.get('/api/transaction-stats', async (req, res) => {
  try {
    const stats = await query(`
      SELECT status_barang, COUNT(*) as total
      FROM transaksi
      GROUP BY status_barang
    `);

    const monthly = await query(`
      SELECT TO_CHAR(tanggal, 'Mon') as month, COUNT(*) as transaksi
      FROM transaksi
      GROUP BY TO_CHAR(tanggal, 'Mon'), DATE_PART('month', tanggal)
      ORDER BY DATE_PART('month', tanggal)
    `);

    res.json({
      success: true,
      data: {
        distribution: {
          masuk: parseInt(stats.rows.find(r => r.status_barang === 'Masuk')?.total || 0),
          assignment: parseInt(stats.rows.find(r => r.status_barang === 'Assignment')?.total || 0),
          disposal: parseInt(stats.rows.find(r => r.status_barang === 'Disposal')?.total || 0)
        },
        monthly: monthly.rows.map(r => ({
          month: r.month,
          transaksi: parseInt(r.transaksi)
        }))
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
