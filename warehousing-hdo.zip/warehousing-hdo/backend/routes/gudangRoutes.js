// gudangRoutes.js
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');

// Mock Controller sementara (bisa diganti nanti kalau udah ada GudangController.js)
const GudangController = {
  getAll: (req, res) => {
    res.json({ success: true, data: [] });
  },
  getById: (req, res) => {
    const { id } = req.params;
    res.json({ success: true, data: { id, nama_gudang: 'Gudang Contoh' } });
  },
  create: (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }
    res.json({ success: true, message: 'Gudang berhasil dibuat' });
  }
};

// Routes
router.get('/', GudangController.getAll);
router.get('/:id', GudangController.getById);
router.post('/', [
  body('nama_gudang').notEmpty().withMessage('Nama gudang wajib diisi'),
  body('lokasi').notEmpty().withMessage('Lokasi gudang wajib diisi')
], GudangController.create);

module.exports = router;