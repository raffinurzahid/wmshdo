const express = require('express');
const router = express.Router();
const RoleController = require('../controllers/roleController');

// 🔥 IMPORT DARI MIDDLEWARE (bukan controller)
const { requireAuth, requireRole } = require('../middleware/authMiddleware');

// SEMUA RUTE DI BAWAH INI MEMBUTUHKAN LOGIN DAN HAK AKSES ADMIN
router.use(requireAuth, requireRole('admin'));

// Rute-rute diurutkan agar lebih rapi
router.get('/search', RoleController.searchRoles);
router.get('/stats', RoleController.getRoleStats);

// Rute CRUD dasar
router.get('/', RoleController.getAllRoles);
router.post('/', RoleController.createRole);
router.get('/:id', RoleController.getRoleById);
router.put('/:id', RoleController.updateRole);
router.delete('/:id', RoleController.deleteRole); // Hard delete

// Rute Soft Delete & Restore
router.patch('/:id/soft-delete', RoleController.softDeleteRole);
router.patch('/:id/restore', RoleController.restoreRole);

// Rute relasi
router.get('/:id/users', RoleController.getUsersByRole);

module.exports = router;