const express = require('express');
const router = express.Router();
const BarangController = require('../controllers/barangController');

const { requireAuth, requireRole } = require('../middleware/authMiddleware'); 

// ✅ NEW: Download template (must be before /:id)
router.get('/download-template', requireAuth, requireRole(['Admin', 'user']), BarangController.downloadTemplate);

// ✅ NEW: Sort by stock (must be before /:id)
router.get('/sort-by-stock', requireAuth, requireRole(['Admin', 'user']), BarangController.sortByStock);

// ✅ NEW: Check kode code exists (must be before /:id)
router.get('/check-base/:kode_barang', requireAuth, requireRole(['Admin', 'user']), BarangController.checkKode);

// [SEARCH] Mencari barang
router.get('/search', requireAuth, requireRole(['Admin', 'user']), BarangController.searchItems);

// [READ ALL] Mengambil semua data barang
router.get('/', requireAuth, requireRole(['Admin', 'user']), BarangController.getAllItems);

// [READ ONE] Mengambil satu data barang berdasarkan ID
router.get('/:id', requireAuth, requireRole(['Admin', 'user']), BarangController.getItemById);

// [CREATE] Membuat data barang baru
router.post('/', requireAuth, requireRole('Admin'), BarangController.createItem);

// [UPDATE] Memperbarui data barang
router.put('/:id', requireAuth, requireRole('Admin'), BarangController.updateItem);

// [DELETE] Menghapus data barang
router.delete('/:id', requireAuth, requireRole('Admin'), BarangController.deleteItem);

module.exports = router;