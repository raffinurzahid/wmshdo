const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

// GET all items
router.get('/', async (req, res) => {
  try {
    const result = await query('SELECT * FROM barang ORDER BY nama_barang');
    res.json({ success: true, data: result.rows });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items' });
  }
});

// GET item by ID
router.get('/:id', async (req, res) => {
  try {
    const result = await query('SELECT * FROM barang WHERE id_barang = $1', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch item' });
  }
});

// CREATE new item
router.post('/', async (req, res) => {
  const { id_barang, nama_barang, jenis_barang, spesifikasi } = req.body;
  
  if (!id_barang || !nama_barang || !jenis_barang) {
    return res.status(400).json({ success: false, message: 'Missing required fields' });
  }

  try {
    const result = await query(
      'INSERT INTO barang (id_barang, nama_barang, jenis_barang, spesifikasi) VALUES ($1, $2, $3, $4) RETURNING *',
      [id_barang, nama_barang, jenis_barang, spesifikasi || null]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      res.status(409).json({ success: false, message: 'Item ID already exists' });
    } else {
      res.status(500).json({ success: false, message: 'Failed to create item' });
    }
  }
});

// GET all items with stock calculation
router.get('/with-stock', async (req, res) => {
  try {
    const result = await query(`
      SELECT 
        b.id_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        COALESCE(
          (SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = b.id_barang AND status_barang = 'Masuk'),
          0
        ) - COALESCE(
          (SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = b.id_barang AND status_barang IN ('Assignment', 'Disposal')),
          0
        ) as qty_stok,
        (SELECT g.nama_gudang FROM transaksi t 
         JOIN gudang g ON t.id_gudang = g.id_gudang 
         WHERE t.id_barang = b.id_barang AND t.status_barang = 'Masuk'
         ORDER BY t.tanggal DESC LIMIT 1) as location
      FROM barang b
      ORDER BY b.nama_barang
    `);
    
    res.json({ success: true, data: result.rows });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items with stock' });
  }
});

// UPDATE item
router.put('/:id', async (req, res) => {
  const { nama_barang, jenis_barang, spesifikasi } = req.body;
  
  try {
    const result = await query(
      'UPDATE barang SET nama_barang = $2, jenis_barang = $3, spesifikasi = $4 WHERE id_barang = $1 RETURNING *',
      [req.params.id, nama_barang, jenis_barang, spesifikasi || null]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update item' });
  }
});

// DELETE item
router.delete('/:id', async (req, res) => {
  try {
    const result = await query('DELETE FROM barang WHERE id_barang = $1 RETURNING *', [req.params.id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    
    res.json({ success: true, message: 'Item deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to delete item' });
  }
});

module.exports = router;