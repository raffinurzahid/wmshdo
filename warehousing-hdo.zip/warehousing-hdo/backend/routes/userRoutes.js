const express = require('express');
const router = express.Router();
const UserController = require('../controllers/userController');
const { requireAuth, requireRole } = require('../middleware/authMiddleware');

// All user management routes require authentication
router.use(requireAuth);

// GET /api/users - Get all users (Admin & Warehouse Manager only)
router.get('/', requireRole(['Admin', 'Warehouse Manager']), UserController.getAllUsers);

// GET /api/users/stats - Get user statistics (Admin only)
router.get('/stats', requireRole(['Admin']), UserController.getUserStats);

// GET /api/users/search - Search users (Admin & Warehouse Manager)
router.get('/search', requireRole(['Admin', 'Warehouse Manager']), UserController.searchUsers);

// GET /api/users/role/:roleId - Get users by role (Admin only)
router.get('/role/:roleId', requireRole(['Admin']), UserController.getUsersByRole);

// GET /api/users/:id - Get user by ID (Admin & Warehouse Manager)
router.get('/:id', requireRole(['Admin', 'Warehouse Manager']), UserController.getUserById);

// POST /api/users - Create new user (Admin only)
router.post('/', requireRole(['Admin']), UserController.createUser);

// PUT /api/users/:id - Update user (Admin only)
router.put('/:id', requireRole(['Admin']), UserController.updateUser);

// DELETE /api/users/:id/soft - Soft delete user (Admin only)
router.delete('/:id/soft', requireRole(['Admin']), UserController.softDeleteUser);

// DELETE /api/users/:id - Hard delete user (Admin only)
router.delete('/:id', requireRole(['Admin']), UserController.deleteUser);

// POST /api/users/:id/restore - Restore soft deleted user (Admin only)
router.post('/:id/restore', requireRole(['Admin']), UserController.restoreUser);

module.exports = router;