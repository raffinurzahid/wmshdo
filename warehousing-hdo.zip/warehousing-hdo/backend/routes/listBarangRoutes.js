const express = require('express');
const router = express.Router();
const ListBarangController = require('../controllers/listBarangController');
const { optionalAuth } = require('../middleware/authMiddleware');

router.get('/', optionalAuth, ListBarangController.getAllItems);
router.get('/status/:status', optionalAuth, ListBarangController.getItemsByStatus);
router.get('/state/:state', optionalAuth, ListBarangController.getItemsByAssetState);
router.get('/search', optionalAuth, ListBarangController.searchItems);

module.exports = router;