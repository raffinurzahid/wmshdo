const { Pool } = require('pg');
require('dotenv').config();

// Database connection configuration
const dbConfig = process.env.DATABASE_URL
  ? {
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    }
  : {
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 5432,
      database: process.env.DB_NAME || 'db_wms2',
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,  // UBAH: 2000 → 10000 (10 detik)
      query_timeout: 15000,             // TAMBAH: timeout untuk query (15 detik)
      statement_timeout: 15000          // TAMBAH: timeout untuk statement (15 detik)
    };

// Create connection pool
const pool = new Pool(dbConfig);

// Test database connection
const testConnection = async () => {
  try {
    const client = await pool.connect();
    console.log('✅ Database connected successfully');
    console.log(`📦 Database: ${process.env.DB_NAME || 'db_wms2'}`);

    const result = await client.query('SELECT NOW()');
    console.log('📅 Database time:', result.rows[0].now);

    const tablesCheck = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);
    
    console.log('📋 Available tables:', tablesCheck.rows.map(r => r.table_name).join(', '));
    client.release();
  } catch (err) {
    console.error('❌ Database connection error:', err.message);
  }
};

// Query helper function
const query = async (text, params) => {
  const start = Date.now();

  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;

    if (process.env.NODE_ENV === 'development' && duration > 1000) {
      console.log('⚠️ Slow query detected:', { 
        duration: `${duration}ms`, 
        rows: result.rowCount 
      });
    }

    return result;
  } catch (err) {
    console.error('❌ Query error:', err.message);
    console.error('🔍 Query:', text.substring(0, 200));
    throw err;
  }
};

// Get client from pool
const getClient = async () => {
  try {
    const client = await pool.connect();
    const originalRelease = client.release.bind(client);
    
    const timeout = setTimeout(() => {
      console.error('⚠️ Transaction timeout - releasing client');
      originalRelease();
    }, 30000);
    
    client.release = () => {
      clearTimeout(timeout);
      originalRelease();
    };
    
    return client;
  } catch (err) {
    console.error('❌ Failed to get database client:', err.message);
    throw err;
  }
};

// Graceful shutdown
const closePool = async () => {
  try {
    await pool.end();
    console.log('🔌 Database connection pool closed');
  } catch (err) {
    console.error('❌ Error closing database pool:', err.message);
  }
};

process.on('SIGINT', async () => {
  await closePool();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await closePool();
  process.exit(0);
});

module.exports = {
  pool,
  query,
  getClient,
  testConnection,
  closePool,
};