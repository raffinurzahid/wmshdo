require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });

const express = require('express');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');

const { testConnection } = require('./config/db');
const errorMiddleware = require('./middleware/errorMiddleware');

// === Impor Semua Rute ===
console.log('🔄 Mengimpor semua modul rute...');
const dashboardRoutes = require('./routes/dashboardRoutes');
const authRoutes = require('./routes/authRoutes');
const masterBarangRoutes = require('./routes/masterBarangRoutes');
const masterGudangRoutes = require('./routes/masterGudangRoutes');
const transaksiRoutes = require('./routes/transaksiRoutes');
const userRoutes = require('./routes/userRoutes');
const roleRoutes = require('./routes/roleRoutes');
const notificationsRoutes = require('./routes/notificationsRoutes');
const listBarangRoutes = require('./routes/listBarangRoutes');
console.log('✅ Semua rute berhasil diimpor.');

const app = express();
const PORT = process.env.PORT || 3000;

// === Middleware ===
console.log('⚙️ Menerapkan middleware...');
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(morgan('combined')); 
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());
console.log('✅ Middleware berhasil diterapkan.');

// === Konfigurasi Tampilan & File Statis ===
app.use(express.static(path.join(__dirname, '../frontend/public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../frontend/views'));

// === Koneksi Database ===
console.log('🔄 Mengetes koneksi database...');
testConnection();

// === Gunakan Rute ===
console.log('🚦 Mendaftarkan rute...');
// Rute untuk halaman UI (seperti GET /login, GET /dashboard, dll.)
app.use('/', authRoutes);
app.use('/', dashboardRoutes);

// Rute untuk API
app.use('/api/auth', authRoutes);
app.use('/api/master-barang', masterBarangRoutes);
app.use('/api/master-gudang', masterGudangRoutes);
app.use('/api/transaksi', transaksiRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/users', userRoutes);
app.use('/api/roles', roleRoutes);
app.use('/api/list-barang', listBarangRoutes);
console.log('✅ Rute berhasil didaftarkan.');

// === Rute Bantuan & Error Handling ===
// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        message: 'WMS Help Desk Server Running',
        timestamp: new Date().toISOString()
    });
});

// Penanganan 404 (Not Found)
app.use((req, res) => {
    if (req.xhr || req.headers.accept?.includes('json')) {
        res.status(404).json({ success: false, message: 'Endpoint tidak ditemukan.' });
    } else {
        res.status(404).render('pages/404', { title: '404 - Tidak Ditemukan' });
    }
});

// Middleware untuk menangani semua error lainnya
app.use(errorMiddleware);

// === Jalankan Server ===
app.listen(PORT, () => {
    console.log(`🚀 WMS Server: http://localhost:${PORT}`);
    console.log(`📦 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`💾 Database: ${process.env.DB_NAME || 'db_wms2'}`);
    console.log(`✅ Server Ready`);
});

// Penanganan graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down gracefully...');
    process.exit(0);
});

module.exports = app;