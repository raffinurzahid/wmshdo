const express = require('express');
const router = express.Router();
const TransaksiController = require('../controllers/transaksiController');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');

// GET /api/transaksi - Get all transactions
router.get('/', optionalAuth, TransaksiController.getAllTransactions);

// GET /api/transaksi/dashboard/stats - Get dashboard statistics
router.get('/dashboard/stats', optionalAuth, TransaksiController.getDashboardStats);

// GET /api/transaksi/summary - Get transaction summary
router.get('/summary', optionalAuth, TransaksiController.getTransactionSummary);

// GET /api/transaksi/search - Search transactions
router.get('/search', optionalAuth, TransaksiController.searchTransactions);

// GET /api/transaksi/report - Generate report
router.get('/report', optionalAuth, TransaksiController.generateReport);

// GET /api/transaksi/available-items - Get available items in warehouse
router.get('/available-items', optionalAuth, TransaksiController.getAvailableItems);

// GET /api/transaksi/check-stock - Check stock availability
router.get('/check-stock', optionalAuth, TransaksiController.checkStock);

// GET /api/transaksi/user/:userId - Get transactions by user
router.get('/user/:userId', requireAuth, TransaksiController.getUserTransactions);

// GET /api/transaksi/:id - Get transaction by ID
router.get('/:id', optionalAuth, TransaksiController.getTransactionById);

// POST /api/transaksi/receiving - Create receiving transaction
router.post('/receiving', requireAuth, TransaksiController.createReceiving);

// POST /api/transaksi/assignment - Create assignment transaction
router.post('/assignment', requireAuth, TransaksiController.createAssignment);

// POST /api/transaksi/disposal - Create disposal transaction
router.post('/disposal', requireAuth, TransaksiController.createDisposal);

// PUT /api/transaksi/:id - Update transaction
router.put('/:id', requireAuth, TransaksiController.updateTransaction);

// DELETE /api/transaksi/:id/soft - Soft delete transaction
router.delete('/:id/soft', requireAuth, TransaksiController.softDeleteTransaction);

// DELETE /api/transaksi/:id - Hard delete transaction (permanent)
router.delete('/:id', requireAuth, TransaksiController.deleteTransaction);

// POST /api/transaksi/:id/restore - Restore soft deleted transaction
router.post('/:id/restore', requireAuth, TransaksiController.restoreTransaction);

module.exports = router;