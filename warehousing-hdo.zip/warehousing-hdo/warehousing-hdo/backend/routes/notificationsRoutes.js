const express = require('express');
const router = express.Router();
// const { query } = require('../config/db'); // Uncomment jika ingin gunakan database

// Sample notifications data - in production, this should come from database
let notificationsData = [
  {
    id: 1,
    title: "New Transaction Created",
    message: "Transaction TXN001 has been created successfully",
    icon: "fas fa-plus-circle",
    color: "#28a745",
    time: "2 minutes ago",
    read: false,
    type: "transaction",
    created_at: new Date()
  },
  {
    id: 2,
    title: "Item Assignment",
    message: "Item ITM002 has been assigned to John Doe",
    icon: "fas fa-user-plus",
    color: "#ffc107",
    time: "1 hour ago",
    read: false,
    type: "assignment",
    created_at: new Date(Date.now() - 3600000)
  },
  {
    id: 3,
    title: "Low Stock Alert",
    message: "Item ITM003 is running low on stock (2 remaining)",
    icon: "fas fa-exclamation-triangle",
    color: "#dc3545",
    time: "3 hours ago",
    read: true,
    type: "alert",
    created_at: new Date(Date.now() - 10800000)
  },
  {
    id: 4,
    title: "System Backup",
    message: "Daily system backup completed successfully",
    icon: "fas fa-cloud-upload-alt",
    color: "#17a2b8",
    time: "Yesterday",
    read: true,
    type: "system",
    created_at: new Date(Date.now() - 86400000)
  }
];

// GET /api/notifications - Get all notifications
router.get('/', async (req, res) => {
  try {
    res.json({
      success: true,
      data: notificationsData,
      message: 'Notifications retrieved successfully'
    });
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch notifications',
      error: error.message
    });
  }
});

// GET /api/notifications/unread - Get unread notifications count
router.get('/unread', async (req, res) => {
  try {
    const unreadCount = notificationsData.filter(n => !n.read).length;
    
    res.json({
      success: true,
      data: {
        count: unreadCount
      },
      message: 'Unread notifications count retrieved successfully'
    });
  } catch (error) {
    console.error('Error fetching unread notifications:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch unread notifications count',
      error: error.message
    });
  }
});

// PUT /api/notifications/:id/read - Mark notification as read
router.put('/:id/read', async (req, res) => {
  try {
    const notificationId = parseInt(req.params.id);
    
    const notification = notificationsData.find(n => n.id === notificationId);
    
    if (!notification) {
      return res.status(404).json({
        success: false,
        message: 'Notification not found'
      });
    }
    
    notification.read = true;
    
    res.json({
      success: true,
      data: notification,
      message: 'Notification marked as read'
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to mark notification as read',
      error: error.message
    });
  }
});

// POST /api/notifications - Create new notification
router.post('/', async (req, res) => {
  try {
    const { title, message, type = 'info', icon = 'fas fa-info-circle', color = '#17a2b8' } = req.body;
    
    if (!title || !message) {
      return res.status(400).json({
        success: false,
        message: 'Title and message are required'
      });
    }
    
    const newNotification = {
      id: notificationsData.length + 1,
      title,
      message,
      icon,
      color,
      type,
      time: 'Just now',
      read: false,
      created_at: new Date()
    };
    
    notificationsData.unshift(newNotification);
    
    res.status(201).json({
      success: true,
      data: newNotification,
      message: 'Notification created successfully'
    });
  } catch (error) {
    console.error('Error creating notification:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create notification',
      error: error.message
    });
  }
});

// Helper function to create transaction-related notifications
const createTransactionNotification = (transactionData, type) => {
  const notificationConfigs = {
    RCV: {
      title: "New Item Received",
      icon: "fas fa-download",
      color: "#28a745"
    },
    ASS: {
      title: "Item Assignment", 
      icon: "fas fa-user-plus",
      color: "#ffc107"
    },
    DISP: {
      title: "Item Disposal",
      icon: "fas fa-trash",
      color: "#dc3545"
    }
  };
  
  const config = notificationConfigs[type];
  if (!config) return;
  
  let message = '';
  switch (type) {
    case 'RCV':
      message = `${transactionData.nama_barang} (${transactionData.quantity} units) received at ${transactionData.location}`;
      break;
    case 'ASS':
      message = `${transactionData.nama_barang} assigned to ${transactionData.nama || 'employee'}`;
      break;
    case 'DISP':
      message = `${transactionData.nama_barang} marked for disposal`;
      break;
  }
  
  const notification = {
    id: notificationsData.length + 1,
    title: config.title,
    message,
    icon: config.icon,
    color: config.color,
    type: 'transaction',
    time: 'Just now',
    read: false,
    created_at: new Date()
  };
  
  notificationsData.unshift(notification);
  return notification;
};

// Export the helper function
router.createTransactionNotification = createTransactionNotification;

module.exports = router;