const express = require('express');
const router = express.Router();
const DashboardController = require('../controllers/dashboardController');
const { optionalAuth } = require('../middleware/authMiddleware');

// =========================
// UI Routes (Pages)
// =========================

// GET / - Dashboard page
router.get('/', optionalAuth, DashboardController.getDashboardPage);

// GET /dashboard - Redirect to /
router.get('/dashboard', (req, res) => res.redirect('/'));

// GET /transaksi - Transactions page
router.get('/transaksi', optionalAuth, (req, res) => {
  res.render('pages/transaksi', {
    title: 'Transactions - WMS Help Desk',
    currentPage: 'transaksi'
  });
});

// =========================
// API Routes
// =========================

// GET /api/dashboard - Dashboard overview
router.get('/api/dashboard', optionalAuth, DashboardController.getDashboardStats);

// GET /api/dashboard/inventory - Inventory overview
router.get('/api/dashboard/inventory', optionalAuth, DashboardController.getInventoryOverview);

// GET /api/dashboard/transaction-summary - Transaction summary with charts
router.get('/api/dashboard/transaction-summary', optionalAuth, DashboardController.getTransactionSummary);

// GET /api/dashboard/user-activity - User activity summary
router.get('/api/dashboard/user-activity', optionalAuth, DashboardController.getUserActivity);

// GET /api/dashboard/warehouse-utilization - Warehouse utilization
router.get('/api/dashboard/warehouse-utilization', optionalAuth, DashboardController.getWarehouseUtilization);

// GET /api/dashboard/recent-activities - Recent activities
router.get('/api/dashboard/recent-activities', optionalAuth, DashboardController.getRecentActivities);

// GET /api/dashboard/category-stats - Category statistics
router.get('/api/dashboard/category-stats', optionalAuth, DashboardController.getCategoryStats);

// GET /api/dashboard/stock-alerts - Stock alerts
router.get('/api/dashboard/stock-alerts', optionalAuth, DashboardController.getStockAlerts);

// GET /api/dashboard/system-stats - System statistics
router.get('/api/dashboard/system-stats', optionalAuth, DashboardController.getSystemStats);

module.exports = router;