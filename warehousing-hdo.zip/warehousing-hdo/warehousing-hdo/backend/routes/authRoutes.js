const express = require('express');
const router = express.Router();
const { 
  login, 
  logout, 
  getCurrentUser, 
  changePassword, 
  refreshToken,
  requireAuth 
} = require('../middleware/authMiddleware');

// POST /api/auth/login - Login
router.post('/login', login);

// POST /api/auth/logout - Logout
router.post('/logout', logout);

// GET /api/auth/me - Get current user info (requires auth)
router.get('/me', requireAuth, getCurrentUser);

// POST /api/auth/change-password - Change password (requires auth)
router.post('/change-password', requireAuth, changePassword);

// POST /api/auth/refresh-token - Refresh JWT token (requires auth)
router.post('/refresh-token', requireAuth, refreshToken);

module.exports = router;