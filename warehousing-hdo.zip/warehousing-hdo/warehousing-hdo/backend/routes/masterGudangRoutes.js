const express = require('express');
const router = express.Router();
const GudangModel = require('../models/gudangModel');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');

// GET /api/master-gudang - Get all warehouses
router.get('/', optionalAuth, async (req, res) => {
  try {
    const warehouses = await GudangModel.getAll();
    res.json({ success: true, data: warehouses });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch warehouses', error: error.message });
  }
});

// GET /api/master-gudang/summary - Get warehouse summary
router.get('/summary', optionalAuth, async (req, res) => {
  try {
    const summary = await GudangModel.getSummaryStats();
    res.json({ success: true, data: summary });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch warehouse summary', error: error.message });
  }
});

// GET /api/master-gudang/search - Search warehouses
router.get('/search', optionalAuth, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) {
      return res.status(400).json({ success: false, message: 'Search query must be at least 2 characters' });
    }
    const warehouses = await GudangModel.search(q.trim());
    res.json({ success: true, data: warehouses });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to search warehouses', error: error.message });
  }
});

// GET /api/master-gudang/:id/stock - Get warehouse stock details
router.get('/:id/stock', optionalAuth, async (req, res) => {
  try {
    const stockDetails = await GudangModel.getStockDetails(req.params.id);
    res.json({ success: true, data: stockDetails });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch warehouse stock', error: error.message });
  }
});

// GET /api/master-gudang/:id/available-items - Get available items in warehouse
router.get('/:id/available-items', optionalAuth, async (req, res) => {
  try {
    const items = await GudangModel.getAvailableItems(req.params.id);
    res.json({ success: true, data: items });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch available items', error: error.message });
  }
});

// GET /api/master-gudang/:id/history - Get warehouse transaction history
router.get('/:id/history', optionalAuth, async (req, res) => {
  try {
    const { limit = 50 } = req.query;
    const history = await GudangModel.getTransactionHistory(req.params.id, parseInt(limit));
    res.json({ success: true, data: history });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch transaction history', error: error.message });
  }
});

// GET /api/master-gudang/:id - Get warehouse by ID
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const warehouse = await GudangModel.getById(req.params.id);
    if (!warehouse) {
      return res.status(404).json({ success: false, message: 'Warehouse not found' });
    }
    res.json({ success: true, data: warehouse });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch warehouse', error: error.message });
  }
});

// POST /api/master-gudang - Create new warehouse
router.post('/', requireAuth, async (req, res) => {
  try {
    const { kode_gudang, nama_gudang, lokasi } = req.body;
    
    if (!kode_gudang || !nama_gudang) {
      return res.status(400).json({ success: false, message: 'Warehouse code and name are required' });
    }

    const createdBy = req.user?.id_user || null;
    const warehouse = await GudangModel.create(req.body, createdBy);
    
    res.status(201).json({ success: true, data: warehouse, message: 'Warehouse created successfully' });
  } catch (error) {
    console.error('Error:', error);
    if (error.message.includes('already exists')) {
      res.status(409).json({ success: false, message: error.message });
    } else {
      res.status(500).json({ success: false, message: 'Failed to create warehouse', error: error.message });
    }
  }
});

// PUT /api/master-gudang/:id - Update warehouse
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const updatedBy = req.user?.id_user || null;
    const warehouse = await GudangModel.update(req.params.id, req.body, updatedBy);
    
    res.json({ success: true, data: warehouse, message: 'Warehouse updated successfully' });
  } catch (error) {
    console.error('Error:', error);
    if (error.message.includes('not found')) {
      res.status(404).json({ success: false, message: error.message });
    } else {
      res.status(500).json({ success: false, message: 'Failed to update warehouse', error: error.message });
    }
  }
});

// DELETE /api/master-gudang/:id/soft - Soft delete warehouse
router.delete('/:id/soft', requireAuth, async (req, res) => {
  try {
    const deletedBy = req.user?.id_user || null;
    const warehouse = await GudangModel.softDelete(req.params.id, deletedBy);
    
    res.json({ success: true, data: warehouse, message: 'Warehouse soft deleted successfully' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to soft delete warehouse', error: error.message });
  }
});

// DELETE /api/master-gudang/:id - Hard delete warehouse (permanent)
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const warehouse = await GudangModel.delete(req.params.id);
    
    res.json({ success: true, data: warehouse, message: 'Warehouse permanently deleted' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to delete warehouse', error: error.message });
  }
});

// POST /api/master-gudang/:id/restore - Restore soft deleted warehouse
router.post('/:id/restore', requireAuth, async (req, res) => {
  try {
    const warehouse = await GudangModel.restore(req.params.id);
    
    res.json({ success: true, data: warehouse, message: 'Warehouse restored successfully' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to restore warehouse', error: error.message });
  }
});

module.exports = router;