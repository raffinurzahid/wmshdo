const express = require('express');
const router = express.Router();
const BarangModel = require('../models/barangModel');
const { requireAuth, optionalAuth } = require('../middleware/authMiddleware');

// GET /api/master-barang - Get all items with stock
router.get('/', optionalAuth, async (req, res) => {
  try {
    const items = await BarangModel.getAllWithStock();
    res.json({ success: true, data: items });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items', error: error.message });
  }
});

// GET /api/master-barang/with-trashed - Get all items including deleted
router.get('/with-trashed', requireAuth, async (req, res) => {
  try {
    const items = await BarangModel.getAllWithTrashedAndStock();
    res.json({ success: true, data: items });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items', error: error.message });
  }
});

// GET /api/master-barang/search - Search items
router.get('/search', optionalAuth, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) {
      return res.status(400).json({ success: false, message: 'Search query must be at least 2 characters' });
    }
    const items = await BarangModel.search(q.trim());
    res.json({ success: true, data: items });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to search items', error: error.message });
  }
});

// GET /api/master-barang/categories - Get all categories
router.get('/categories', optionalAuth, async (req, res) => {
  try {
    const categories = await BarangModel.getCategories();
    res.json({ success: true, data: categories });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch categories', error: error.message });
  }
});

// GET /api/master-barang/category/:jenis - Get items by category
router.get('/category/:jenis', optionalAuth, async (req, res) => {
  try {
    const items = await BarangModel.getByCategory(req.params.jenis);
    res.json({ success: true, data: items });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch items', error: error.message });
  }
});

// GET /api/master-barang/low-stock - Get low stock items
router.get('/low-stock', optionalAuth, async (req, res) => {
  try {
    const { threshold = 5 } = req.query;
    const items = await BarangModel.getLowStockItems(parseInt(threshold));
    res.json({ success: true, data: items });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch low stock items', error: error.message });
  }
});

// GET /api/master-barang/:id - Get item by ID
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const item = await BarangModel.getById(req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, message: 'Item not found' });
    }
    res.json({ success: true, data: item });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch item', error: error.message });
  }
});

// POST /api/master-barang - Create new item
router.post('/', requireAuth, async (req, res) => {
  try {
    const { kode_barang, nama_barang, jenis_barang, spesifikasi } = req.body;
    
    if (!kode_barang || !nama_barang || !jenis_barang) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    const createdBy = req.user?.id_user || null;
    const item = await BarangModel.create(req.body, createdBy);
    
    res.status(201).json({ success: true, data: item, message: 'Item created successfully' });
  } catch (error) {
    console.error('Error:', error);
    if (error.message.includes('already exists')) {
      res.status(409).json({ success: false, message: error.message });
    } else {
      res.status(500).json({ success: false, message: 'Failed to create item', error: error.message });
    }
  }
});

// PUT /api/master-barang/:id - Update item
router.put('/:id', requireAuth, async (req, res) => {
  try {
    const updatedBy = req.user?.id_user || null;
    const item = await BarangModel.update(req.params.id, req.body, updatedBy);
    
    res.json({ success: true, data: item, message: 'Item updated successfully' });
  } catch (error) {
    console.error('Error:', error);
    if (error.message.includes('not found')) {
      res.status(404).json({ success: false, message: error.message });
    } else {
      res.status(500).json({ success: false, message: 'Failed to update item', error: error.message });
    }
  }
});

// DELETE /api/master-barang/:id/soft - Soft delete item
router.delete('/:id/soft', requireAuth, async (req, res) => {
  try {
    const deletedBy = req.user?.id_user || null;
    const item = await BarangModel.softDelete(req.params.id, deletedBy);
    
    res.json({ success: true, data: item, message: 'Item soft deleted successfully' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to soft delete item', error: error.message });
  }
});

// DELETE /api/master-barang/:id - Hard delete item (permanent)
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const item = await BarangModel.delete(req.params.id);
    
    res.json({ success: true, data: item, message: 'Item permanently deleted' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to delete item', error: error.message });
  }
});

// POST /api/master-barang/:id/restore - Restore soft deleted item
router.post('/:id/restore', requireAuth, async (req, res) => {
  try {
    const item = await BarangModel.restore(req.params.id);
    
    res.json({ success: true, data: item, message: 'Item restored successfully' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Failed to restore item', error: error.message });
  }
});

module.exports = router;