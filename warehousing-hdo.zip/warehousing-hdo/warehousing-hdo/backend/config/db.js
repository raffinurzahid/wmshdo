const { Pool } = require('pg');
require('dotenv').config();

// Database connection configuration
const dbConfig = process.env.DATABASE_URL
  ? {
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    }
  : {
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 5432,
      database: process.env.DB_NAME || 'db_wms2',
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    };

// Create connection pool
const pool = new Pool(dbConfig);

// Test database connection
const testConnection = async () => {
  try {
    const client = await pool.connect();
    console.log('✅ Database connected successfully');
    console.log(`📦 Database: ${process.env.DB_NAME || 'db_wms2'}`);

    // Test query
    const result = await client.query('SELECT NOW()');
    console.log('📅 Database time:', result.rows[0].now);

    // Check tables exist
    const tablesCheck = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);
    
    console.log('📋 Available tables:', tablesCheck.rows.map(r => r.table_name).join(', '));

    client.release();
  } catch (err) {
    console.error('❌ Database connection error:', err.message);
    console.error('🔧 Please check your database configuration in .env file');
    console.error('Expected database: db_wms2');
  }
};

// Query helper function
const query = async (text, params) => {
  const start = Date.now();

  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;

    if (process.env.NODE_ENV === 'development') {
      console.log('📊 Query executed:', { 
        text: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
        duration: `${duration}ms`, 
        rows: result.rowCount 
      });
    }

    return result;
  } catch (err) {
    console.error('❌ Query error:', err.message);
    console.error('🔍 Query:', text);
    console.error('🔍 Params:', params);
    throw err;
  }
};

// Get client from pool (for transactions)
const getClient = async () => {
  try {
    const client = await pool.connect();
    
    // Add helper methods for transactions
    const query = client.query.bind(client);
    const release = client.release.bind(client);
    
    // Set timeout for transactions
    const timeout = setTimeout(() => {
      console.error('⚠️ Transaction timeout - releasing client');
      release();
    }, 30000); // 30 seconds
    
    // Override release to clear timeout
    client.release = () => {
      clearTimeout(timeout);
      release();
    };
    
    return client;
  } catch (err) {
    console.error('❌ Failed to get database client:', err.message);
    throw err;
  }
};

// Graceful shutdown
const closePool = async () => {
  try {
    await pool.end();
    console.log('🔌 Database connection pool closed');
  } catch (err) {
    console.error('❌ Error closing database pool:', err.message);
  }
};

// Handle process termination
process.on('SIGINT', async () => {
  await closePool();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await closePool();
  process.exit(0);
});

module.exports = {
  pool,
  query,
  getClient,
  testConnection,
  closePool,
};