const express = require('express');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');
const bodyParser = require('body-parser');
require('dotenv').config();

const { testConnection } = require('./config/db');

// Import routes
const dashboardRoutes = require('./routes/dashboardRoutes');
const transaksiRoutes = require('./routes/transaksiRoutes');
const authRoutes = require('./routes/authRoutes');
const notificationsRoutes = require('./routes/notificationsRoutes');
const masterBarangRoutes = require('./routes/masterBarangRoutes');
const masterGudangRoutes = require('./routes/masterGudangRoutes');

const errorMiddleware = require('./middleware/errorMiddleware');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(morgan('combined'));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

// Static files & View engine
app.use(express.static(path.join(__dirname, '../frontend/public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../frontend/views'));

// Test database
testConnection();

// Setup notification creator
if (notificationsRoutes.createTransactionNotification && transaksiRoutes.setNotificationCreator) {
  transaksiRoutes.setNotificationCreator(notificationsRoutes.createTransactionNotification);
}

// API Routes
app.use('/', dashboardRoutes);
app.use('/api/transaksi', transaksiRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/master-barang', masterBarangRoutes);
app.use('/api/master-gudang', masterGudangRoutes);

// Web Routes
app.get('/transactions', (req, res) => {
  res.render('transaksi', {
    title: 'All Transactions - WMS Help Desk',
    currentPage: 'transaksi'
  });
});

app.get('/master-barang', (req, res) => {
  res.render('pages/master-barang', {
    title: 'Master Data Barang - WMS Help Desk',
    currentPage: 'master-barang'
  });
});

app.get('/master-gudang', (req, res) => {
  res.render('pages/master-gudang', {
    title: 'Master Gudang Barang - WMS Help Desk',
    currentPage: 'master-gudang'
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'WMS Help Desk Server Running',
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use((req, res) => {
  if (req.xhr || req.headers.accept?.includes('json')) {
    res.status(404).json({ success: false, message: 'Endpoint not found' });
  } else {
    res.status(404).send(`
      <div style="text-align:center;padding:50px;font-family:Arial;">
        <h1>404 - Page Not Found</h1>
        <p><a href="/">Back to Dashboard</a></p>
      </div>
    `);
  }
});

// Error handling
app.use(errorMiddleware);

// Start server
app.listen(PORT, () => {
  console.log(`🚀 WMS Server: http://localhost:${PORT}`);
  console.log(`📦 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`✅ Server Ready`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down gracefully...');
  process.exit(0);
});

module.exports = app;