const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class TransaksiModel {
  // Get all transactions (exclude soft deleted)
  static async getAll(jenisFilter = null, limit = 100, offset = 0) {
    let sql = `
      SELECT 
        t.id_transaksi,
        t.kode_transaksi,
        t.jenis_transaksi,
        t.status_barang,
        t.id_barang,
        t.id_gudang,
        t.qty_stok,
        t.keterangan,
        t.created_at,
        t.created_by,
        b.kode_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        g.kode_gudang,
        g.nama_gudang,
        g.lokasi
      FROM transaksi t
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE t.deleted_at IS NULL
    `;
    
    const params = [];
    
    if (jenisFilter) {
      sql += ` AND t.jenis_transaksi = $1`;
      params.push(jenisFilter);
    }
    
    sql += `
      ORDER BY t.created_at DESC, t.kode_transaksi DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;
    
    params.push(limit, offset);
    
    try {
      const result = await query(sql, params);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting transactions: ${error.message}`);
    }
  }

  // Get transaction by ID
  static async getById(id) {
    const sql = `
      SELECT 
        t.*,
        b.kode_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        g.kode_gudang,
        g.nama_gudang,
        g.lokasi
      FROM transaksi t
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE t.id_transaksi = $1 AND t.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting transaction by ID: ${error.message}`);
    }
  }

  // Create new transaction
  static async create(transactionData, createdBy = null) {
    const {
      id_barang,
      id_gudang,
      jenis_transaksi,
      status_barang,
      qty_stok,
      keterangan
    } = transactionData;

    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      const id_transaksi = uuidv4();
      const kode_transaksi = await this.generateKodeTransaksi(jenis_transaksi, client);
      
      // Verify barang exists
      const barangCheck = await client.query(
        'SELECT id_barang FROM barang WHERE id_barang = $1 AND deleted_at IS NULL',
        [id_barang]
      );
      
      if (barangCheck.rows.length === 0) {
        throw new Error('Item not found or has been deleted');
      }
      
      // Verify gudang exists
      const gudangCheck = await client.query(
        'SELECT id_gudang FROM gudang WHERE id_gudang = $1 AND deleted_at IS NULL',
        [id_gudang]
      );
      
      if (gudangCheck.rows.length === 0) {
        throw new Error('Warehouse not found or has been deleted');
      }
      
      // For Assignment/Disposal, check stock availability
      if (jenis_transaksi === 'Assignment' || jenis_transaksi === 'Disposal') {
        const stockCheck = await this.checkStockAvailability(id_barang, id_gudang, qty_stok, client);
        
        if (!stockCheck.available) {
          throw new Error(stockCheck.message);
        }
      }
      
      // Insert transaction
      const insertSql = `
        INSERT INTO transaksi 
        (id_transaksi, kode_transaksi, jenis_transaksi, status_barang, id_barang, id_gudang, qty_stok, keterangan, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
      
      const result = await client.query(insertSql, [
        id_transaksi,
        kode_transaksi,
        jenis_transaksi,
        status_barang || jenis_transaksi,
        id_barang,
        id_gudang,
        qty_stok,
        keterangan || null,
        createdBy
      ]);
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error creating transaction: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Create batch transactions
  static async createBatch(transactionDataArray, createdBy = null) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      const results = [];
      
      for (const txData of transactionDataArray) {
        const {
          id_barang,
          id_gudang,
          jenis_transaksi,
          status_barang,
          qty_stok,
          keterangan
        } = txData;
        
        const id_transaksi = uuidv4();
        const kode_transaksi = await this.generateKodeTransaksi(jenis_transaksi, client);
        
        // Verify barang and gudang
        const barangCheck = await client.query(
          'SELECT id_barang FROM barang WHERE id_barang = $1 AND deleted_at IS NULL',
          [id_barang]
        );
        
        if (barangCheck.rows.length === 0) {
          throw new Error(`Item ${id_barang} not found`);
        }
        
        const gudangCheck = await client.query(
          'SELECT id_gudang FROM gudang WHERE id_gudang = $1 AND deleted_at IS NULL',
          [id_gudang]
        );
        
        if (gudangCheck.rows.length === 0) {
          throw new Error(`Warehouse ${id_gudang} not found`);
        }
        
        // Check stock for Assignment/Disposal
        if (jenis_transaksi === 'Assignment' || jenis_transaksi === 'Disposal') {
          const stockCheck = await this.checkStockAvailability(id_barang, id_gudang, qty_stok, client);
          
          if (!stockCheck.available) {
            throw new Error(`${stockCheck.message} for item ${id_barang}`);
          }
        }
        
        // Insert transaction
        const insertSql = `
          INSERT INTO transaksi 
          (id_transaksi, kode_transaksi, jenis_transaksi, status_barang, id_barang, id_gudang, qty_stok, keterangan, created_by)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
          RETURNING *
        `;
        
        const result = await client.query(insertSql, [
          id_transaksi,
          kode_transaksi,
          jenis_transaksi,
          status_barang || jenis_transaksi,
          id_barang,
          id_gudang,
          qty_stok,
          keterangan || null,
          createdBy
        ]);
        
        results.push(result.rows[0]);
      }
      
      await client.query('COMMIT');
      
      return results;
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error creating batch transactions: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Update transaction
  static async update(id, updateData, updatedBy = null) {
    const { qty_stok, keterangan, id_gudang, status_barang } = updateData;
    
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Get current transaction
      const currentTx = await client.query(
        'SELECT * FROM transaksi WHERE id_transaksi = $1 AND deleted_at IS NULL',
        [id]
      );
      
      if (currentTx.rows.length === 0) {
        throw new Error('Transaction not found or already deleted');
      }
      
      const current = currentTx.rows[0];
      
      // Build update query
      let updateFields = [];
      let values = [id];
      let paramCount = 1;
      
      if (qty_stok !== undefined && qty_stok !== current.qty_stok) {
        if (current.jenis_transaksi === 'Assignment' || current.jenis_transaksi === 'Disposal') {
          const stockCheck = await this.checkStockAvailability(
            current.id_barang,
            current.id_gudang,
            qty_stok,
            client
          );
          
          if (!stockCheck.available) {
            throw new Error(stockCheck.message);
          }
        }
        
        paramCount++;
        updateFields.push(`qty_stok = $${paramCount}`);
        values.push(qty_stok);
      }
      
      if (keterangan !== undefined) {
        paramCount++;
        updateFields.push(`keterangan = $${paramCount}`);
        values.push(keterangan);
      }

      if (status_barang !== undefined) {
        paramCount++;
        updateFields.push(`status_barang = $${paramCount}`);
        values.push(status_barang);
      }
      
      if (id_gudang !== undefined && id_gudang !== current.id_gudang) {
        const gudangCheck = await client.query(
          'SELECT id_gudang FROM gudang WHERE id_gudang = $1 AND deleted_at IS NULL',
          [id_gudang]
        );
        
        if (gudangCheck.rows.length === 0) {
          throw new Error('New warehouse not found');
        }
        
        paramCount++;
        updateFields.push(`id_gudang = $${paramCount}`);
        values.push(id_gudang);
      }
      
      if (updatedBy) {
        paramCount++;
        updateFields.push(`updated_by = $${paramCount}`);
        values.push(updatedBy);
      }
      
      if (updateFields.length === 0) {
        throw new Error('No fields to update');
      }
      
      updateFields.push(`updated_at = NOW()`);
      
      const sql = `
        UPDATE transaksi 
        SET ${updateFields.join(', ')}
        WHERE id_transaksi = $1 AND deleted_at IS NULL
        RETURNING *
      `;
      
      const result = await client.query(sql, values);
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error updating transaction: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Soft delete transaction
  static async softDelete(id, deletedBy = null) {
    const sql = `
      UPDATE transaksi
      SET deleted_at = NOW(), deleted_by = $2
      WHERE id_transaksi = $1 AND deleted_at IS NULL
      RETURNING id_transaksi, kode_transaksi, jenis_transaksi, deleted_at
    `;
    
    try {
      const result = await query(sql, [id, deletedBy]);
      
      if (result.rows.length === 0) {
        throw new Error('Transaction not found or already deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error soft deleting transaction: ${error.message}`);
    }
  }

  // Hard delete transaction
  static async delete(id) {
    const sql = 'DELETE FROM transaksi WHERE id_transaksi = $1 RETURNING id_transaksi, kode_transaksi';
    
    try {
      const result = await query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Transaction not found');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting transaction: ${error.message}`);
    }
  }

  // Restore soft deleted transaction
  static async restore(id) {
    const sql = `
      UPDATE transaksi
      SET deleted_at = NULL, deleted_by = NULL
      WHERE id_transaksi = $1 AND deleted_at IS NOT NULL
      RETURNING id_transaksi, kode_transaksi
    `;
    
    try {
      const result = await query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Transaction not found or not deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error restoring transaction: ${error.message}`);
    }
  }

  // Generate kode_transaksi
  static async generateKodeTransaksi(jenis_transaksi, client = null) {
    const prefixMap = {
      'Masuk': 'RCV',
      'Assignment': 'ASG',
      'Disposal': 'DPS'
    };
    
    const prefix = prefixMap[jenis_transaksi] || 'TXN';
    
    try {
      const countQuery = `
        SELECT COUNT(*) as count 
        FROM transaksi 
        WHERE jenis_transaksi = $1
      `;
      
      const dbClient = client || { query };
      const result = await dbClient.query(countQuery, [jenis_transaksi]);
      const count = parseInt(result.rows[0].count) + 1;
      
      return `${prefix}${count.toString().padStart(5, '0')}`;
    } catch (error) {
      return `${prefix}${Date.now()}`;
    }
  }

  // Check stock availability
  static async checkStockAvailability(itemId, warehouseId, requiredQty, client = null) {
    const sql = `
      SELECT 
        b.nama_barang,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as available_stock
      FROM barang b
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_masuk
        FROM transaksi 
        WHERE jenis_transaksi = 'Masuk' AND id_gudang = $2 AND deleted_at IS NULL
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, SUM(qty_stok) as qty_keluar
        FROM transaksi 
        WHERE jenis_transaksi IN ('Assignment', 'Disposal') AND id_gudang = $2 AND deleted_at IS NULL
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.id_barang = $1 AND b.deleted_at IS NULL
    `;
    
    try {
      const dbClient = client || { query };
      const result = await dbClient.query(sql, [itemId, warehouseId]);
      const stock = result.rows[0];
      
      if (!stock) {
        return { available: false, message: 'Item not found', currentStock: 0 };
      }
      
      const availableStock = parseInt(stock.available_stock) || 0;
      
      if (availableStock < requiredQty) {
        return { 
          available: false, 
          message: `Insufficient stock. Available: ${availableStock}, Required: ${requiredQty}`,
          currentStock: availableStock
        };
      }
      
      return { available: true, message: 'Stock available', currentStock: availableStock };
    } catch (error) {
      throw new Error(`Error checking stock availability: ${error.message}`);
    }
  }

  // Get dashboard statistics
  static async getDashboardStats() {
    const sql = `
      SELECT 
        COUNT(*) as total_transactions,
        COUNT(CASE WHEN jenis_transaksi = 'Masuk' THEN 1 END) as total_masuk,
        COUNT(CASE WHEN jenis_transaksi = 'Assignment' THEN 1 END) as total_assignment,
        COUNT(CASE WHEN jenis_transaksi = 'Disposal' THEN 1 END) as total_disposal,
        SUM(CASE WHEN jenis_transaksi = 'Masuk' THEN qty_stok ELSE 0 END) as qty_masuk,
        SUM(CASE WHEN jenis_transaksi = 'Assignment' THEN qty_stok ELSE 0 END) as qty_assignment,
        SUM(CASE WHEN jenis_transaksi = 'Disposal' THEN qty_stok ELSE 0 END) as qty_disposal,
        COUNT(DISTINCT id_barang) as unique_items,
        COUNT(DISTINCT id_gudang) as active_warehouses
      FROM transaksi
      WHERE deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting dashboard statistics: ${error.message}`);
    }
  }

  // Get recent transactions
  static async getRecentTransactions(limit = 10) {
    const sql = `
      SELECT 
        t.id_transaksi,
        t.kode_transaksi,
        t.jenis_transaksi,
        t.status_barang,
        t.qty_stok,
        t.created_at,
        b.nama_barang,
        b.jenis_barang,
        g.nama_gudang
      FROM transaksi t
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE t.deleted_at IS NULL
      ORDER BY t.created_at DESC
      LIMIT $1
    `;
    
    try {
      const result = await query(sql, [limit]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting recent transactions: ${error.message}`);
    }
  }

  // Search transactions
  static async search(searchTerm) {
    const sql = `
      SELECT 
        t.*,
        b.nama_barang,
        b.kode_barang,
        g.nama_gudang
      FROM transaksi t
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE t.deleted_at IS NULL
        AND (
          LOWER(t.kode_transaksi) LIKE LOWER($1) OR
          LOWER(b.nama_barang) LIKE LOWER($1) OR
          LOWER(b.kode_barang) LIKE LOWER($1) OR
          LOWER(g.nama_gudang) LIKE LOWER($1) OR
          LOWER(t.keterangan) LIKE LOWER($1)
        )
      ORDER BY t.created_at DESC
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching transactions: ${error.message}`);
    }
  }

  // Generate report
  static async generateReport(filters = {}) {
    const { startDate, endDate, jenis_transaksi, warehouseId, itemId, userId } = filters;

    let sql = `
      SELECT 
        t.id_transaksi,
        t.kode_transaksi,
        t.jenis_transaksi,
        t.status_barang,
        t.qty_stok,
        t.keterangan,
        t.created_at,
        b.kode_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        g.kode_gudang,
        g.nama_gudang,
        g.lokasi,
        t.created_by
      FROM transaksi t
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      LEFT JOIN gudang g ON t.id_gudang = g.id_gudang
      WHERE t.deleted_at IS NULL
    `;

    const params = [];
    let paramCount = 0;

    if (startDate) {
      paramCount++;
      sql += ` AND DATE(t.created_at) >= $${paramCount}`;
      params.push(startDate);
    }

    if (endDate) {
      paramCount++;
      sql += ` AND DATE(t.created_at) <= $${paramCount}`;
      params.push(endDate);
    }

    if (jenis_transaksi) {
      paramCount++;
      sql += ` AND t.jenis_transaksi = $${paramCount}`;
      params.push(jenis_transaksi);
    }

    if (warehouseId) {
      paramCount++;
      sql += ` AND t.id_gudang = $${paramCount}`;
      params.push(warehouseId);
    }

    if (itemId) {
      paramCount++;
      sql += ` AND t.id_barang = $${paramCount}`;
      params.push(itemId);
    }

    if (userId) {
      paramCount++;
      sql += ` AND t.created_by = $${paramCount}`;
      params.push(userId);
    }

    sql += ` ORDER BY t.created_at DESC, t.kode_transaksi DESC`;

    try {
      const result = await query(sql, params);
      return result.rows;
    } catch (error) {
      throw new Error(`Error generating transaction report: ${error.message}`);
    }
  }

  // Get stats
  static async getStats() {
    const sql = `
      SELECT 
        COUNT(*) FILTER (WHERE deleted_at IS NULL) as total_active,
        COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) as total_deleted,
        COUNT(DISTINCT id_barang) FILTER (WHERE deleted_at IS NULL) as unique_items,
        COUNT(DISTINCT id_gudang) FILTER (WHERE deleted_at IS NULL) as unique_warehouses,
        SUM(qty_stok) FILTER (WHERE deleted_at IS NULL AND jenis_transaksi = 'Masuk') as total_qty_in,
        SUM(qty_stok) FILTER (WHERE deleted_at IS NULL AND jenis_transaksi IN ('Assignment', 'Disposal')) as total_qty_out
      FROM transaksi
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting transaction statistics: ${error.message}`);
    }
  }
}

module.exports = TransaksiModel;