const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class GudangModel {
  // Get all warehouses with transaction statistics (exclude soft deleted)
  static async getAll() {
    const sql = `
      SELECT 
        g.id_gudang,
        g.kode_gudang,
        g.nama_gudang,
        g.lokasi,
        g.created_at,
        g.updated_at,
        COUNT(t.id_transaksi) as total_transactions,
        SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.jumlah ELSE 0 END) as total_masuk,
        SUM(CASE WHEN t.jenis_transaksi IN ('Assignment', 'Disposal') THEN t.jumlah ELSE 0 END) as total_keluar,
        SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.jumlah ELSE 0 END) - 
        SUM(CASE WHEN t.jenis_transaksi IN ('Assignment', 'Disposal') THEN t.jumlah ELSE 0 END) as current_stock
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang AND t.deleted_at IS NULL
      WHERE g.deleted_at IS NULL
      GROUP BY g.id_gudang, g.kode_gudang, g.nama_gudang, g.lokasi, g.created_at, g.updated_at
      ORDER BY g.nama_gudang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all warehouses: ${error.message}`);
    }
  }

  // Get all warehouses including soft deleted
  static async getAllWithTrashed() {
    const sql = `
      SELECT 
        g.id_gudang,
        g.kode_gudang,
        g.nama_gudang,
        g.lokasi,
        g.created_at,
        g.updated_at,
        g.deleted_at,
        COUNT(t.id_transaksi) as total_transactions
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang AND t.deleted_at IS NULL
      GROUP BY g.id_gudang, g.kode_gudang, g.nama_gudang, g.lokasi, g.created_at, g.updated_at, g.deleted_at
      ORDER BY g.nama_gudang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all warehouses with trashed: ${error.message}`);
    }
  }

  // Get only soft deleted warehouses
  static async getOnlyTrashed() {
    const sql = `
      SELECT id_gudang, kode_gudang, nama_gudang, lokasi, deleted_at, deleted_by
      FROM gudang
      WHERE deleted_at IS NOT NULL
      ORDER BY deleted_at DESC
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting trashed warehouses: ${error.message}`);
    }
  }

  // Get warehouse by ID
  static async getById(id) {
    const sql = `
      SELECT 
        g.*,
        COUNT(t.id_transaksi) as total_transactions,
        SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.jumlah ELSE 0 END) as total_masuk,
        SUM(CASE WHEN t.jenis_transaksi IN ('Assignment', 'Disposal') THEN t.jumlah ELSE 0 END) as total_keluar
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang AND t.deleted_at IS NULL
      WHERE g.id_gudang = $1 AND g.deleted_at IS NULL
      GROUP BY g.id_gudang
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse by ID: ${error.message}`);
    }
  }

  // Get warehouse by kode_gudang
  static async getByKode(kode_gudang) {
    const sql = `
      SELECT * FROM gudang
      WHERE kode_gudang = $1 AND deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [kode_gudang]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse by kode: ${error.message}`);
    }
  }

  // Get warehouse by name
  static async getByName(nama_gudang) {
    const sql = `
      SELECT * FROM gudang
      WHERE LOWER(nama_gudang) = LOWER($1) AND deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [nama_gudang]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse by name: ${error.message}`);
    }
  }

  // Create new warehouse
  static async create(warehouseData, createdBy = null) {
    const { kode_gudang, nama_gudang, lokasi } = warehouseData;
    const id_gudang = uuidv4();

    const sql = `
      INSERT INTO gudang (id_gudang, kode_gudang, nama_gudang, lokasi, created_by)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `;
    
    try {
      const result = await query(sql, [id_gudang, kode_gudang, nama_gudang, lokasi || null, createdBy]);
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') {
        throw new Error('Warehouse code or name already exists');
      }
      throw new Error(`Error creating warehouse: ${error.message}`);
    }
  }

  // Update warehouse
  static async update(id, warehouseData, updatedBy = null) {
    const { kode_gudang, nama_gudang, lokasi } = warehouseData;
    
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      let updateFields = [];
      let values = [id];
      let paramCount = 1;
      
      if (kode_gudang !== undefined) {
        paramCount++;
        updateFields.push(`kode_gudang = $${paramCount}`);
        values.push(kode_gudang);
      }
      
      if (nama_gudang !== undefined) {
        paramCount++;
        updateFields.push(`nama_gudang = $${paramCount}`);
        values.push(nama_gudang);
      }
      
      if (lokasi !== undefined) {
        paramCount++;
        updateFields.push(`lokasi = $${paramCount}`);
        values.push(lokasi);
      }
      
      if (updatedBy) {
        paramCount++;
        updateFields.push(`updated_by = $${paramCount}`);
        values.push(updatedBy);
      }
      
      if (updateFields.length === 0) {
        throw new Error('No fields to update');
      }
      
      const sql = `
        UPDATE gudang
        SET ${updateFields.join(', ')}, updated_at = NOW()
        WHERE id_gudang = $1 AND deleted_at IS NULL
        RETURNING *
      `;
      
      const result = await client.query(sql, values);
      
      if (result.rows.length === 0) {
        throw new Error('Warehouse not found or already deleted');
      }
      
      await client.query('COMMIT');
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      if (error.code === '23505') {
        throw new Error('Warehouse code or name already exists');
      }
      throw new Error(`Error updating warehouse: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Soft delete warehouse
  static async softDelete(id, deletedBy = null) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if warehouse has active stock
      const stockCheck = await client.query(`
        SELECT 
          COALESCE(
            SUM(CASE WHEN jenis_transaksi = 'Masuk' THEN jumlah ELSE 0 END) -
            SUM(CASE WHEN jenis_transaksi IN ('Assignment', 'Disposal') THEN jumlah ELSE 0 END),
            0
          ) as current_stock
        FROM transaksi
        WHERE id_gudang = $1 AND deleted_at IS NULL
      `, [id]);
      
      if (parseInt(stockCheck.rows[0].current_stock) > 0) {
        throw new Error('Cannot delete warehouse with active stock. Please transfer or dispose stock first.');
      }
      
      const sql = `
        UPDATE gudang
        SET deleted_at = NOW(), deleted_by = $2
        WHERE id_gudang = $1 AND deleted_at IS NULL
        RETURNING id_gudang, kode_gudang, nama_gudang, deleted_at
      `;
      
      const result = await client.query(sql, [id, deletedBy]);
      
      if (result.rows.length === 0) {
        throw new Error('Warehouse not found or already deleted');
      }
      
      await client.query('COMMIT');
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error soft deleting warehouse: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Hard delete warehouse (permanent)
  static async delete(id) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if warehouse has transactions
      const checkTransactions = await client.query(
        'SELECT COUNT(*) as count FROM transaksi WHERE id_gudang = $1',
        [id]
      );
      
      if (parseInt(checkTransactions.rows[0].count) > 0) {
        throw new Error('Cannot delete warehouse with existing transactions. Use soft delete instead.');
      }
      
      const sql = 'DELETE FROM gudang WHERE id_gudang = $1 RETURNING id_gudang, kode_gudang, nama_gudang';
      const result = await client.query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Warehouse not found');
      }
      
      await client.query('COMMIT');
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error deleting warehouse: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Restore soft deleted warehouse
  static async restore(id) {
    const sql = `
      UPDATE gudang
      SET deleted_at = NULL, deleted_by = NULL
      WHERE id_gudang = $1 AND deleted_at IS NOT NULL
      RETURNING id_gudang, kode_gudang, nama_gudang
    `;
    
    try {
      const result = await query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Warehouse not found or not deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error restoring warehouse: ${error.message}`);
    }
  }

  // Get warehouse stock details (items in specific warehouse)
  static async getStockDetails(warehouseId) {
    const sql = `
      SELECT 
        b.id_barang,
        b.kode_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) as qty_masuk,
        COALESCE(stock_out.qty_keluar, 0) as qty_keluar,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT id_barang, SUM(jumlah) as qty_masuk
        FROM transaksi 
        WHERE jenis_transaksi = 'Masuk' AND id_gudang = $1 AND deleted_at IS NULL
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, SUM(jumlah) as qty_keluar
        FROM transaksi 
        WHERE jenis_transaksi IN ('Assignment', 'Disposal') AND id_gudang = $1 AND deleted_at IS NULL
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.deleted_at IS NULL
        AND (COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) > 0
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [warehouseId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting warehouse stock details: ${error.message}`);
    }
  }

  // Get warehouse transaction history
  static async getTransactionHistory(warehouseId, limit = 50) {
    const sql = `
      SELECT 
        t.id_transaksi,
        t.kode_transaksi,
        t.jenis_transaksi,
        t.jumlah,
        t.keterangan,
        t.created_at,
        b.kode_barang,
        b.nama_barang,
        b.jenis_barang
      FROM transaksi t
      LEFT JOIN barang b ON t.id_barang = b.id_barang
      WHERE t.id_gudang = $1 AND t.deleted_at IS NULL
      ORDER BY t.created_at DESC
      LIMIT $2
    `;
    
    try {
      const result = await query(sql, [warehouseId, limit]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting warehouse transaction history: ${error.message}`);
    }
  }

  // Search warehouses
  static async search(searchTerm) {
    const sql = `
      SELECT 
        g.id_gudang,
        g.kode_gudang,
        g.nama_gudang,
        g.lokasi,
        COUNT(t.id_transaksi) as total_transactions
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang AND t.deleted_at IS NULL
      WHERE g.deleted_at IS NULL
        AND (
          LOWER(g.nama_gudang) LIKE LOWER($1) OR
          LOWER(g.kode_gudang) LIKE LOWER($1) OR
          LOWER(g.lokasi) LIKE LOWER($1)
        )
      GROUP BY g.id_gudang, g.kode_gudang, g.nama_gudang, g.lokasi
      ORDER BY g.nama_gudang
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching warehouses: ${error.message}`);
    }
  }

  // Get warehouse summary statistics
  static async getSummaryStats() {
    const sql = `
      SELECT 
        COUNT(DISTINCT g.id_gudang) as total_warehouses,
        COUNT(t.id_transaksi) as total_transactions,
        SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.jumlah ELSE 0 END) as total_items_in,
        SUM(CASE WHEN t.jenis_transaksi IN ('Assignment', 'Disposal') THEN t.jumlah ELSE 0 END) as total_items_out,
        SUM(CASE WHEN t.jenis_transaksi = 'Masuk' THEN t.jumlah ELSE 0 END) - 
        SUM(CASE WHEN t.jenis_transaksi IN ('Assignment', 'Disposal') THEN t.jumlah ELSE 0 END) as current_total_stock
      FROM gudang g
      LEFT JOIN transaksi t ON g.id_gudang = t.id_gudang AND t.deleted_at IS NULL
      WHERE g.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse summary statistics: ${error.message}`);
    }
  }

  // Get items available in specific warehouse (with stock > 0)
  static async getAvailableItems(warehouseId) {
    const sql = `
      SELECT 
        b.id_barang,
        b.kode_barang,
        b.nama_barang,
        b.jenis_barang,
        b.spesifikasi,
        COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0) as available_stock
      FROM barang b
      INNER JOIN (
        SELECT id_barang, SUM(jumlah) as qty_masuk
        FROM transaksi 
        WHERE jenis_transaksi = 'Masuk' AND id_gudang = $1 AND deleted_at IS NULL
        GROUP BY id_barang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, SUM(jumlah) as qty_keluar
        FROM transaksi 
        WHERE jenis_transaksi IN ('Assignment', 'Disposal') AND id_gudang = $1 AND deleted_at IS NULL
        GROUP BY id_barang
      ) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.deleted_at IS NULL
        AND (COALESCE(stock_in.qty_masuk, 0) - COALESCE(stock_out.qty_keluar, 0)) > 0
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [warehouseId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting available items in warehouse: ${error.message}`);
    }
  }

  // Get warehouse statistics
  static async getStats() {
    const sql = `
      SELECT 
        COUNT(*) FILTER (WHERE deleted_at IS NULL) as total_active,
        COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) as total_deleted
      FROM gudang
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting warehouse statistics: ${error.message}`);
    }
  }
}

module.exports = GudangModel;