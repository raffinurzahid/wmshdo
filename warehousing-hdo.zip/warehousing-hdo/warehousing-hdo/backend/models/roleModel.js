const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class RoleModel {
  // Get all roles (exclude soft deleted)
  static async getAll() {
    const sql = `
      SELECT 
        r.id_role,
        r.nama_role,
        r.created_at,
        r.updated_at,
        COUNT(u.id_user) as total_users
      FROM role r
      LEFT JOIN "user" u ON r.id_role = u.id_role AND u.deleted_at IS NULL
      WHERE r.deleted_at IS NULL
      GROUP BY r.id_role, r.nama_role, r.created_at, r.updated_at
      ORDER BY r.nama_role
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all roles: ${error.message}`);
    }
  }

  // Get all roles including soft deleted
  static async getAllWithTrashed() {
    const sql = `
      SELECT 
        r.id_role,
        r.nama_role,
        r.created_at,
        r.updated_at,
        r.deleted_at,
        COUNT(u.id_user) as total_users
      FROM role r
      LEFT JOIN "user" u ON r.id_role = u.id_role AND u.deleted_at IS NULL
      GROUP BY r.id_role, r.nama_role, r.created_at, r.updated_at, r.deleted_at
      ORDER BY r.nama_role
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all roles with trashed: ${error.message}`);
    }
  }

  // Get only soft deleted roles
  static async getOnlyTrashed() {
    const sql = `
      SELECT 
        id_role,
        nama_role,
        deleted_at,
        deleted_by
      FROM role
      WHERE deleted_at IS NOT NULL
      ORDER BY deleted_at DESC
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting trashed roles: ${error.message}`);
    }
  }

  // Get role by ID
  static async getById(id) {
    const sql = `
      SELECT 
        r.id_role,
        r.nama_role,
        r.created_at,
        r.updated_at,
        COUNT(u.id_user) as total_users
      FROM role r
      LEFT JOIN "user" u ON r.id_role = u.id_role AND u.deleted_at IS NULL
      WHERE r.id_role = $1 AND r.deleted_at IS NULL
      GROUP BY r.id_role, r.nama_role, r.created_at, r.updated_at
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting role by ID: ${error.message}`);
    }
  }

  // Get role by name
  static async getByName(nama_role) {
    const sql = `
      SELECT 
        id_role,
        nama_role,
        created_at,
        updated_at
      FROM role
      WHERE LOWER(nama_role) = LOWER($1) AND deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [nama_role]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting role by name: ${error.message}`);
    }
  }

  // Create new role
  static async create(roleData, createdBy = null) {
    const { nama_role } = roleData;
    const id_role = uuidv4();

    const sql = `
      INSERT INTO role (id_role, nama_role, created_by)
      VALUES ($1, $2, $3)
      RETURNING id_role, nama_role, created_at
    `;
    
    try {
      const result = await query(sql, [id_role, nama_role, createdBy]);
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') {
        throw new Error('Role name already exists');
      }
      throw new Error(`Error creating role: ${error.message}`);
    }
  }

  // Update role
  static async update(id, roleData, updatedBy = null) {
    const { nama_role } = roleData;

    const sql = `
      UPDATE role
      SET nama_role = $2, updated_by = $3, updated_at = NOW()
      WHERE id_role = $1 AND deleted_at IS NULL
      RETURNING id_role, nama_role, updated_at
    `;
    
    try {
      const result = await query(sql, [id, nama_role, updatedBy]);
      
      if (result.rows.length === 0) {
        throw new Error('Role not found or already deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') {
        throw new Error('Role name already exists');
      }
      throw new Error(`Error updating role: ${error.message}`);
    }
  }

  // Soft delete role
  static async softDelete(id, deletedBy = null) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if role has users
      const checkUsers = await client.query(
        'SELECT COUNT(*) as count FROM "user" WHERE id_role = $1 AND deleted_at IS NULL',
        [id]
      );
      
      if (parseInt(checkUsers.rows[0].count) > 0) {
        throw new Error('Cannot delete role with assigned users. Please reassign users first.');
      }
      
      const sql = `
        UPDATE role
        SET deleted_at = NOW(), deleted_by = $2
        WHERE id_role = $1 AND deleted_at IS NULL
        RETURNING id_role, nama_role, deleted_at
      `;
      
      const result = await client.query(sql, [id, deletedBy]);
      
      if (result.rows.length === 0) {
        throw new Error('Role not found or already deleted');
      }
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error soft deleting role: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Hard delete role (permanent)
  static async delete(id) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if role has users
      const checkUsers = await client.query(
        'SELECT COUNT(*) as count FROM "user" WHERE id_role = $1',
        [id]
      );
      
      if (parseInt(checkUsers.rows[0].count) > 0) {
        throw new Error('Cannot delete role with assigned users. Please reassign users first.');
      }
      
      const sql = 'DELETE FROM role WHERE id_role = $1 RETURNING id_role, nama_role';
      const result = await client.query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Role not found');
      }
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error deleting role: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Restore soft deleted role
  static async restore(id) {
    const sql = `
      UPDATE role
      SET deleted_at = NULL, deleted_by = NULL
      WHERE id_role = $1 AND deleted_at IS NOT NULL
      RETURNING id_role, nama_role
    `;
    
    try {
      const result = await query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Role not found or not deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error restoring role: ${error.message}`);
    }
  }

  // Get users by role
  static async getUsersByRole(roleId) {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.email,
        u.created_at
      FROM "user" u
      WHERE u.id_role = $1 AND u.deleted_at IS NULL
      ORDER BY u.username
    `;
    
    try {
      const result = await query(sql, [roleId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting users by role: ${error.message}`);
    }
  }

  // Search roles
  static async search(searchTerm) {
    const sql = `
      SELECT 
        r.id_role,
        r.nama_role,
        COUNT(u.id_user) as total_users
      FROM role r
      LEFT JOIN "user" u ON r.id_role = u.id_role AND u.deleted_at IS NULL
      WHERE r.deleted_at IS NULL
        AND LOWER(r.nama_role) LIKE LOWER($1)
      GROUP BY r.id_role, r.nama_role
      ORDER BY r.nama_role
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching roles: ${error.message}`);
    }
  }

  // Get role statistics
  static async getStats() {
    const sql = `
      SELECT 
        COUNT(*) FILTER (WHERE deleted_at IS NULL) as total_active,
        COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) as total_deleted
      FROM role
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting role statistics: ${error.message}`);
    }
  }
}

module.exports = RoleModel;