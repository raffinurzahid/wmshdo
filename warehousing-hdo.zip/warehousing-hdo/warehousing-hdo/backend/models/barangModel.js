const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

class BarangModel {
  // Helper: Build stock subquery
  static _buildStockQuery(type) {
    const condition = type === 'in' 
      ? `jenis_transaksi = 'Masuk'`
      : `jenis_transaksi IN ('Assignment', 'Disposal')`;
    
    return `SELECT id_barang, SUM(qty_stok) as qty FROM transaksi WHERE ${condition} AND deleted_at IS NULL GROUP BY id_barang`;
  }

  // Get all items with stock
  static async getAllWithStock() {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty, 0) as qty_masuk,
        COALESCE(stock_out.qty, 0) as qty_keluar,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.deleted_at IS NULL
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting items with stock: ${error.message}`);
    }
  }

  // Get all including deleted
  static async getAllWithTrashedAndStock() {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty, 0) as qty_masuk,
        COALESCE(stock_out.qty, 0) as qty_keluar,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting items with trashed: ${error.message}`);
    }
  }

  // Get only deleted
  static async getOnlyTrashed() {
    const sql = `SELECT id_barang, kode_barang, nama_barang, jenis_barang, spesifikasi, deleted_at, deleted_by FROM barang WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC`;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting trashed items: ${error.message}`);
    }
  }

  // Get by ID
  static async getById(id) {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty, 0) as qty_masuk,
        COALESCE(stock_out.qty, 0) as qty_keluar,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.id_barang = $1 AND b.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting item by ID: ${error.message}`);
    }
  }

  // Get by code
  static async getByKode(kode_barang) {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.kode_barang = $1 AND b.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [kode_barang]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting item by code: ${error.message}`);
    }
  }

  // Create item
  static async create(itemData, createdBy = null) {
    const { kode_barang, nama_barang, jenis_barang, spesifikasi } = itemData;
    const sql = `INSERT INTO barang (id_barang, kode_barang, nama_barang, jenis_barang, spesifikasi, created_by) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`;
    
    try {
      const result = await query(sql, [uuidv4(), kode_barang, nama_barang, jenis_barang, spesifikasi || null, createdBy]);
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') throw new Error('Item code already exists');
      throw new Error(`Error creating item: ${error.message}`);
    }
  }

  // Update item
  static async update(id, itemData, updatedBy = null) {
    const { kode_barang, nama_barang, jenis_barang, spesifikasi } = itemData;
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      const updates = [];
      const values = [id];
      let idx = 1;
      
      const fields = { kode_barang, nama_barang, jenis_barang, spesifikasi };
      for (const [key, val] of Object.entries(fields)) {
        if (val !== undefined) {
          updates.push(`${key} = $${++idx}`);
          values.push(val);
        }
      }
      
      if (updatedBy) {
        updates.push(`updated_by = $${++idx}`);
        values.push(updatedBy);
      }
      
      if (updates.length === 0) throw new Error('No fields to update');
      
      const sql = `UPDATE barang SET ${updates.join(', ')}, updated_at = NOW() WHERE id_barang = $1 AND deleted_at IS NULL RETURNING *`;
      const result = await client.query(sql, values);
      if (result.rows.length === 0) throw new Error('Item not found');
      
      await client.query('COMMIT');
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      if (error.code === '23505') throw new Error('Item code already exists');
      throw error;
    } finally {
      client.release();
    }
  }

  // Soft delete
  static async softDelete(id, deletedBy = null) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      const stockCheck = await client.query(`
        SELECT COALESCE(
          (SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = $1 AND jenis_transaksi = 'Masuk' AND deleted_at IS NULL), 0
        ) - COALESCE(
          (SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = $1 AND jenis_transaksi IN ('Assignment', 'Disposal') AND deleted_at IS NULL), 0
        ) as current_stock
      `, [id]);
      
      if (parseInt(stockCheck.rows[0].current_stock) > 0) {
        throw new Error('Cannot delete item with active stock');
      }
      
      const result = await client.query(`UPDATE barang SET deleted_at = NOW(), deleted_by = $2 WHERE id_barang = $1 AND deleted_at IS NULL RETURNING id_barang, kode_barang, nama_barang, deleted_at`, [id, deletedBy]);
      if (result.rows.length === 0) throw new Error('Item not found');
      
      await client.query('COMMIT');
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  // Hard delete
  static async delete(id) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      const txCheck = await client.query('SELECT COUNT(*) as count FROM transaksi WHERE id_barang = $1', [id]);
      if (parseInt(txCheck.rows[0].count) > 0) throw new Error('Cannot delete item with transactions');
      
      const result = await client.query('DELETE FROM barang WHERE id_barang = $1 RETURNING id_barang, kode_barang, nama_barang', [id]);
      if (result.rows.length === 0) throw new Error('Item not found');
      
      await client.query('COMMIT');
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  // Restore
  static async restore(id) {
    const result = await query(`UPDATE barang SET deleted_at = NULL, deleted_by = NULL WHERE id_barang = $1 AND deleted_at IS NOT NULL RETURNING id_barang, kode_barang, nama_barang`, [id]);
    if (result.rows.length === 0) throw new Error('Item not found or not deleted');
    return result.rows[0];
  }

  // Get current stock
  static async getCurrentStock(itemId, warehouseId = null) {
    const whFilter = warehouseId ? `AND id_gudang = $2` : '';
    const params = warehouseId ? [itemId, warehouseId] : [itemId];
    
    const sql = `
      SELECT 
        b.id_barang, b.kode_barang, b.nama_barang, b.jenis_barang,
        COALESCE((SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = $1 AND jenis_transaksi = 'Masuk' AND deleted_at IS NULL ${whFilter}), 0) as qty_masuk,
        COALESCE((SELECT SUM(qty_stok) FROM transaksi WHERE id_barang = $1 AND jenis_transaksi IN ('Assignment', 'Disposal') AND deleted_at IS NULL ${whFilter}), 0) as qty_keluar
      FROM barang b
      WHERE b.id_barang = $1 AND b.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, params);
      const row = result.rows[0];
      if (row) row.current_stock = parseInt(row.qty_masuk) - parseInt(row.qty_keluar);
      return row;
    } catch (error) {
      throw new Error(`Error getting stock: ${error.message}`);
    }
  }

  // Get low stock items
  static async getLowStockItems(threshold = 5) {
    const sql = `
      SELECT 
        b.*, g.nama_gudang,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (
        SELECT id_barang, id_gudang, SUM(qty_stok) as qty
        FROM transaksi WHERE jenis_transaksi = 'Masuk' AND deleted_at IS NULL
        GROUP BY id_barang, id_gudang
      ) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (
        SELECT id_barang, id_gudang, SUM(qty_stok) as qty
        FROM transaksi WHERE jenis_transaksi IN ('Assignment', 'Disposal') AND deleted_at IS NULL
        GROUP BY id_barang, id_gudang
      ) stock_out ON b.id_barang = stock_out.id_barang AND stock_in.id_gudang = stock_out.id_gudang
      LEFT JOIN gudang g ON stock_in.id_gudang = g.id_gudang
      WHERE b.deleted_at IS NULL
        AND (COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0)) BETWEEN 0 AND $1
      ORDER BY current_stock ASC, b.nama_barang
    `;
    
    try {
      const result = await query(sql, [threshold]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting low stock items: ${error.message}`);
    }
  }

  // Search items
  static async search(searchTerm) {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.deleted_at IS NULL
        AND (LOWER(b.nama_barang) LIKE LOWER($1) OR LOWER(b.kode_barang) LIKE LOWER($1) OR LOWER(b.jenis_barang) LIKE LOWER($1) OR LOWER(b.spesifikasi) LIKE LOWER($1))
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching items: ${error.message}`);
    }
  }

  // Get by category
  static async getByCategory(jenisBarang) {
    const sql = `
      SELECT 
        b.*,
        COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0) as current_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.deleted_at IS NULL AND LOWER(b.jenis_barang) = LOWER($1)
      ORDER BY b.nama_barang
    `;
    
    try {
      const result = await query(sql, [jenisBarang]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting items by category: ${error.message}`);
    }
  }

  // Get categories
  static async getCategories() {
    const sql = `
      SELECT 
        jenis_barang,
        COUNT(*) as item_count,
        SUM(COALESCE(stock_in.qty, 0) - COALESCE(stock_out.qty, 0)) as total_stock
      FROM barang b
      LEFT JOIN (${this._buildStockQuery('in')}) stock_in ON b.id_barang = stock_in.id_barang
      LEFT JOIN (${this._buildStockQuery('out')}) stock_out ON b.id_barang = stock_out.id_barang
      WHERE b.deleted_at IS NULL
      GROUP BY jenis_barang
      ORDER BY jenis_barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting categories: ${error.message}`);
    }
  }

  // Get stats
  static async getStats() {
    const sql = `
      SELECT 
        COUNT(*) FILTER (WHERE deleted_at IS NULL) as total_active,
        COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) as total_deleted,
        COUNT(DISTINCT jenis_barang) FILTER (WHERE deleted_at IS NULL) as unique_categories
      FROM barang
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting stats: ${error.message}`);
    }
  }
}

module.exports = BarangModel;