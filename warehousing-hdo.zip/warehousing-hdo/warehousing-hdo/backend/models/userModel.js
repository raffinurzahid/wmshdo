const { query, getClient } = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');

class UserModel {
  // Get all users (exclude soft deleted)
  static async getAll() {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.email,
        u.id_role,
        r.nama_role,
        u.created_at,
        u.updated_at
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.deleted_at IS NULL
      ORDER BY u.username
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all users: ${error.message}`);
    }
  }

  // Get all users including soft deleted
  static async getAllWithTrashed() {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.email,
        u.id_role,
        r.nama_role,
        u.created_at,
        u.updated_at,
        u.deleted_at
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      ORDER BY u.username
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting all users with trashed: ${error.message}`);
    }
  }

  // Get only soft deleted users
  static async getOnlyTrashed() {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.email,
        u.id_role,
        r.nama_role,
        u.deleted_at,
        u.deleted_by
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.deleted_at IS NOT NULL
      ORDER BY u.deleted_at DESC
    `;
    
    try {
      const result = await query(sql);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting trashed users: ${error.message}`);
    }
  }

  // Get user by ID
  static async getById(id) {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.password,
        u.email,
        u.id_role,
        r.nama_role,
        u.created_at,
        u.updated_at
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.id_user = $1 AND u.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting user by ID: ${error.message}`);
    }
  }

  // Get user by username
  static async getByUsername(username) {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.password,
        u.email,
        u.id_role,
        r.nama_role,
        u.created_at,
        u.updated_at
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.username = $1 AND u.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [username]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting user by username: ${error.message}`);
    }
  }

  // Get user by email
  static async getByEmail(email) {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.password,
        u.email,
        u.id_role,
        r.nama_role
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.email = $1 AND u.deleted_at IS NULL
    `;
    
    try {
      const result = await query(sql, [email]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting user by email: ${error.message}`);
    }
  }

  // Create new user
  static async create(userData, createdBy = null) {
    const { username, password, email, id_role } = userData;
    const id_user = uuidv4();
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = `
      INSERT INTO "user" (id_user, username, password, email, id_role, created_by)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id_user, username, email, id_role, created_at
    `;
    
    try {
      const result = await query(sql, [
        id_user,
        username,
        hashedPassword,
        email,
        id_role,
        createdBy
      ]);
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') {
        throw new Error('Username or email already exists');
      }
      throw new Error(`Error creating user: ${error.message}`);
    }
  }

  // Update user
  static async update(id, userData, updatedBy = null) {
    const { username, email, id_role, password } = userData;
    
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Build dynamic update query
      let updateFields = [];
      let values = [id];
      let paramCount = 1;
      
      if (username !== undefined) {
        paramCount++;
        updateFields.push(`username = $${paramCount}`);
        values.push(username);
      }
      
      if (email !== undefined) {
        paramCount++;
        updateFields.push(`email = $${paramCount}`);
        values.push(email);
      }
      
      if (id_role !== undefined) {
        paramCount++;
        updateFields.push(`id_role = $${paramCount}`);
        values.push(id_role);
      }
      
      if (password !== undefined) {
        const hashedPassword = await bcrypt.hash(password, 10);
        paramCount++;
        updateFields.push(`password = $${paramCount}`);
        values.push(hashedPassword);
      }
      
      if (updatedBy) {
        paramCount++;
        updateFields.push(`updated_by = $${paramCount}`);
        values.push(updatedBy);
      }
      
      if (updateFields.length === 0) {
        throw new Error('No fields to update');
      }
      
      const sql = `
        UPDATE "user"
        SET ${updateFields.join(', ')}, updated_at = NOW()
        WHERE id_user = $1 AND deleted_at IS NULL
        RETURNING id_user, username, email, id_role, updated_at
      `;
      
      const result = await client.query(sql, values);
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      if (error.code === '23505') {
        throw new Error('Username or email already exists');
      }
      throw new Error(`Error updating user: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Soft delete user
  static async softDelete(id, deletedBy = null) {
    const sql = `
      UPDATE "user"
      SET deleted_at = NOW(), deleted_by = $2
      WHERE id_user = $1 AND deleted_at IS NULL
      RETURNING id_user, username, deleted_at
    `;
    
    try {
      const result = await query(sql, [id, deletedBy]);
      
      if (result.rows.length === 0) {
        throw new Error('User not found or already deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error soft deleting user: ${error.message}`);
    }
  }

  // Hard delete user (permanent)
  static async delete(id) {
    const client = await getClient();
    
    try {
      await client.query('BEGIN');
      
      // Check if user has transactions
      const checkTransactions = await client.query(
        'SELECT COUNT(*) as count FROM transaksi WHERE created_by = $1',
        [id]
      );
      
      if (parseInt(checkTransactions.rows[0].count) > 0) {
        throw new Error('Cannot delete user with existing transactions. Use soft delete instead.');
      }
      
      const sql = 'DELETE FROM "user" WHERE id_user = $1 RETURNING id_user, username';
      const result = await client.query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('User not found');
      }
      
      await client.query('COMMIT');
      
      return result.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw new Error(`Error deleting user: ${error.message}`);
    } finally {
      client.release();
    }
  }

  // Restore soft deleted user
  static async restore(id) {
    const sql = `
      UPDATE "user"
      SET deleted_at = NULL, deleted_by = NULL
      WHERE id_user = $1 AND deleted_at IS NOT NULL
      RETURNING id_user, username, email
    `;
    
    try {
      const result = await query(sql, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('User not found or not deleted');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error restoring user: ${error.message}`);
    }
  }

  // Verify password
  static async verifyPassword(plainPassword, hashedPassword) {
    try {
      return await bcrypt.compare(plainPassword, hashedPassword);
    } catch (error) {
      throw new Error(`Error verifying password: ${error.message}`);
    }
  }

  // Search users
  static async search(searchTerm) {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.email,
        u.id_role,
        r.nama_role
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.deleted_at IS NULL
        AND (
          LOWER(u.username) LIKE LOWER($1) OR
          LOWER(u.email) LIKE LOWER($1)
        )
      ORDER BY u.username
    `;
    
    try {
      const result = await query(sql, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching users: ${error.message}`);
    }
  }

  // Get users by role
  static async getByRole(roleId) {
    const sql = `
      SELECT 
        u.id_user,
        u.username,
        u.email,
        r.nama_role
      FROM "user" u
      LEFT JOIN role r ON u.id_role = r.id_role
      WHERE u.id_role = $1 AND u.deleted_at IS NULL
      ORDER BY u.username
    `;
    
    try {
      const result = await query(sql, [roleId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error getting users by role: ${error.message}`);
    }
  }

  // Get user statistics
  static async getStats() {
    const sql = `
      SELECT 
        COUNT(*) FILTER (WHERE deleted_at IS NULL) as total_active,
        COUNT(*) FILTER (WHERE deleted_at IS NOT NULL) as total_deleted,
        COUNT(DISTINCT id_role) FILTER (WHERE deleted_at IS NULL) as unique_roles
      FROM "user"
    `;
    
    try {
      const result = await query(sql);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error getting user statistics: ${error.message}`);
    }
  }
}

module.exports = UserModel;