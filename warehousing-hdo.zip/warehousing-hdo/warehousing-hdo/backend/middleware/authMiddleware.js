const jwt = require('jsonwebtoken');
const UserModel = require('../models/userModel');

const JWT_SECRET = process.env.JWT_SECRET || 'your_super_secret_jwt_key_change_this';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

// Middleware: Require authentication
const requireAuth = async (req, res, next) => {
  try {
    const token =
      req.headers['authorization']?.replace('Bearer ', '') ||
      req.cookies?.token;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Token not found. Please login first.'
      });
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET);

    // Get fresh user data from database
    const user = await UserModel.getById(decoded.id_user);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'User not found or has been deleted.'
      });
    }

    // Attach user to request
    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token expired. Please login again.'
      });
    }
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token. Please login again.'
      });
    }
    
    res.status(401).json({
      success: false,
      message: 'Authentication failed.'
    });
  }
};

// Middleware: Optional authentication (user may or may not be logged in)
const optionalAuth = async (req, res, next) => {
  try {
    const token =
      req.headers['authorization']?.replace('Bearer ', '') ||
      req.cookies?.token;

    if (token) {
      const decoded = jwt.verify(token, JWT_SECRET);
      const user = await UserModel.getById(decoded.id_user);
      
      if (user) {
        req.user = user;
        req.token = token;
      }
    }
    
    next();
  } catch (error) {
    // If optional auth fails, just continue without user
    next();
  }
};

// Middleware: Require specific role
const requireRole = (allowedRoles) => {
  return async (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Authentication required.' 
      });
    }

    const userRole = req.user.nama_role?.toLowerCase();

    // Check if user's role is in allowed roles
    const isAllowed = allowedRoles.some(role => {
      const normalized = role.toLowerCase();
      return userRole === normalized;
    });

    if (!isAllowed) {
      return res.status(403).json({ 
        success: false, 
        message: `Access denied. Required roles: ${allowedRoles.join(', ')}` 
      });
    }

    next();
  };
};

// Controller: Login
const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Username and password are required.' 
      });
    }

    // Get user by username
    const user = await UserModel.getByUsername(username);

    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Invalid username or password.' 
      });
    }

    // Verify password
    const isPasswordValid = await UserModel.verifyPassword(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ 
        success: false, 
        message: 'Invalid username or password.' 
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        id_user: user.id_user,
        username: user.username,
        id_role: user.id_role
      }, 
      JWT_SECRET, 
      { expiresIn: JWT_EXPIRES_IN }
    );

    // Remove password from response
    const userResponse = { ...user };
    delete userResponse.password;

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse,
        token,
        expiresIn: JWT_EXPIRES_IN
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'An error occurred during login.',
      error: error.message
    });
  }
};

// Controller: Logout
const logout = (req, res) => {
  // In JWT, logout is handled client-side by removing the token
  res.json({ 
    success: true, 
    message: 'Logout successful. Please remove token from client storage.' 
  });
};

// Controller: Get current user info
const getCurrentUser = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Not authenticated' 
      });
    }

    // Remove password from response
    const userResponse = { ...req.user };
    delete userResponse.password;

    res.json({ 
      success: true, 
      data: userResponse 
    });
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to get user information',
      error: error.message
    });
  }
};

// Controller: Change password
const changePassword = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Authentication required' 
      });
    }

    const { currentPassword, newPassword, confirmPassword } = req.body;

    // Validate input
    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(400).json({ 
        success: false, 
        message: 'All fields are required.' 
      });
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({ 
        success: false, 
        message: 'New password and confirmation do not match.' 
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ 
        success: false, 
        message: 'New password must be at least 6 characters long.' 
      });
    }

    // Get user with password
    const user = await UserModel.getById(req.user.id_user);

    // Verify current password
    const isPasswordValid = await UserModel.verifyPassword(currentPassword, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ 
        success: false, 
        message: 'Current password is incorrect.' 
      });
    }

    // Update password
    await UserModel.update(
      req.user.id_user,
      { password: newPassword },
      req.user.id_user
    );

    res.json({ 
      success: true, 
      message: 'Password changed successfully.' 
    });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to change password',
      error: error.message
    });
  }
};

// Controller: Refresh token
const refreshToken = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Authentication required' 
      });
    }

    // Generate new token
    const token = jwt.sign(
      { 
        id_user: req.user.id_user,
        username: req.user.username,
        id_role: req.user.id_role
      }, 
      JWT_SECRET, 
      { expiresIn: JWT_EXPIRES_IN }
    );

    res.json({
      success: true,
      message: 'Token refreshed successfully',
      data: {
        token,
        expiresIn: JWT_EXPIRES_IN
      }
    });
  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to refresh token',
      error: error.message
    });
  }
};

module.exports = {
  requireAuth,
  optionalAuth,
  requireRole,
  login,
  logout,
  getCurrentUser,
  changePassword,
  refreshToken
};