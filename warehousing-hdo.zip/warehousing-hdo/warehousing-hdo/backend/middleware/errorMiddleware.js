// Error handling middleware for WMS Help Desk Operation

const errorMiddleware = (err, req, res, next) => {
  console.error('🚨 Error caught by middleware:');
  console.error('📍 URL:', req.method, req.originalUrl);
  console.error('⏰ Time:', new Date().toISOString());
  console.error('💥 Error:', err.message);
  console.error('📊 Stack:', err.stack);

  // Default error response
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Internal Server Error';

  // Handle specific error types
  if (err.name === 'ValidationError') {
    statusCode = 400;
    message = 'Data validation failed';
  }

  if (err.code === '23505') { // PostgreSQL unique violation
    statusCode = 409;
    message = 'Data already exists (duplicate key)';
  }

  if (err.code === '23503') { // PostgreSQL foreign key violation
    statusCode = 400;
    message = 'Referenced data does not exist';
  }

  if (err.code === '23502') { // PostgreSQL not null violation
    statusCode = 400;
    message = 'Required field is missing';
  }

  // Check if it's an API request or web page request
  const isApiRequest = req.path.startsWith('/api/') || req.xhr || req.headers['content-type'] === 'application/json';

  if (isApiRequest) {
    // Return JSON error for API requests
    res.status(statusCode).json({
      success: false,
      message: message,
      error: process.env.NODE_ENV === 'development' ? err.stack : undefined,
      timestamp: new Date().toISOString(),
      path: req.originalUrl
    });
  } else {
    // Render error page for web requests
    res.status(statusCode).render('pages/error', {
      title: `Error ${statusCode}`,
      message: message,
      statusCode: statusCode,
      error: process.env.NODE_ENV === 'development' ? err : {},
      url: req.originalUrl
    });
  }
};

module.exports = errorMiddleware;