const BarangModel = require('../models/barangModel');
const TransaksiModel = require('../models/transaksiModel');
const UserModel = require('../models/userModel');
const GudangModel = require('../models/gudangModel');

class DashboardController {
  // Get dashboard page
  static async getDashboardPage(req, res) {
    try {
      // Get dashboard statistics
      const [
        dashboardStats,
        lowStockItems,
        recentTransactions,
        warehouseStats,
        allItems,
        allUsers,
        allWarehouses
      ] = await Promise.all([
        TransaksiModel.getDashboardStats(),
        BarangModel.getLowStockItems(5),
        TransaksiModel.getRecentTransactions(10),
        GudangModel.getSummaryStats(),
        BarangModel.getAllWithStock(),
        UserModel.getAll(),
        GudangModel.getAll()
      ]);

      // Calculate totals
      const totalBarang = allItems.length;
      const totalStok = allItems.reduce((sum, item) => sum + (item.current_stock || 0), 0);

      // Get categories count
      const categories = await BarangModel.getCategories();
      const totalShelfs = categories.length;

      const dashboardData = {
        // Main statistics
        totalShelfs: totalShelfs,
        totalMedicines: totalStok,
        totalStocksQuality: totalStok,
        totalSuppliers: 0, // Not implemented yet
        numberOfPurchase: dashboardStats.total_masuk || 0,
        totalPurchaseAmount: 0, // Not implemented
        numberOfSales: dashboardStats.total_assignment || 0,
        totalSalesAmount: 0, // Not implemented
        
        // Additional data
        lowStockItems: lowStockItems || [],
        recentTransactions: recentTransactions || [],
        warehouseStats: warehouseStats || {},
        totalUsers: allUsers.length,
        totalGudang: allWarehouses.length,
        lowStockCount: (lowStockItems || []).length,
        
        // Transaction statistics
        totalTransactions: dashboardStats.total_transactions || 0,
        totalDisposal: dashboardStats.total_disposal || 0
      };

      res.render('pages/dashboard', {
        title: 'Dashboard - WMS Help Desk',
        currentPage: 'dashboard',
        ...dashboardData
      });

    } catch (error) {
      console.error('Error loading dashboard:', error);
      res.status(500).render('pages/error', {
        title: 'Error',
        message: 'Failed to load dashboard',
        error: error.message
      });
    }
  }

  // API: Get dashboard statistics
  static async getDashboardStats(req, res) {
    try {
      const stats = await TransaksiModel.getDashboardStats();
      
      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error getting dashboard stats:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch dashboard statistics',
        error: error.message
      });
    }
  }

  // API: Get inventory overview
  static async getInventoryOverview(req, res) {
    try {
      const [items, lowStock, warehouses, categories] = await Promise.all([
        BarangModel.getAllWithStock(),
        BarangModel.getLowStockItems(),
        GudangModel.getAll(),
        BarangModel.getCategories()
      ]);

      const overview = {
        totalItems: items.length,
        totalStock: items.reduce((sum, item) => sum + (item.current_stock || 0), 0),
        lowStockCount: lowStock.length,
        activeWarehouses: warehouses.length,
        categories: categories,
        itemsByCategory: {},
        stockByWarehouse: {}
      };

      // Group items by category
      categories.forEach(category => {
        overview.itemsByCategory[category.jenis_barang] = {
          count: parseInt(category.item_count),
          totalStock: parseInt(category.total_stock || 0)
        };
      });

      // Get stock by warehouse
      for (const warehouse of warehouses) {
        const stockDetails = await GudangModel.getStockDetails(warehouse.id_gudang);
        overview.stockByWarehouse[warehouse.nama_gudang] = {
          totalItems: stockDetails.length,
          totalStock: stockDetails.reduce((sum, stock) => sum + (parseInt(stock.current_stock) || 0), 0),
          lowStockItems: stockDetails.filter(stock => (parseInt(stock.current_stock) || 0) < 5).length
        };
      }

      res.json({
        success: true,
        data: overview
      });
    } catch (error) {
      console.error('Error getting inventory overview:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch inventory overview',
        error: error.message
      });
    }
  }

  // API: Get transaction summary with chart data
  static async getTransactionSummary(req, res) {
    try {
      const { period = '30' } = req.query; // days
      
      const { query } = require('../config/db');
      const sql = `
        SELECT 
          DATE(created_at) as date,
          jenis_transaksi,
          COUNT(*) as count,
          SUM(jumlah) as total_items
        FROM transaksi 
        WHERE deleted_at IS NULL
          AND created_at >= CURRENT_DATE - INTERVAL '${parseInt(period)} days'
        GROUP BY DATE(created_at), jenis_transaksi
        ORDER BY date DESC
      `;

      const result = await query(sql);

      // Process data for chart
      const processedData = {};
      result.rows.forEach(row => {
        const dateKey = row.date.toISOString().split('T')[0];
        if (!processedData[dateKey]) {
          processedData[dateKey] = {
            date: dateKey,
            Masuk: 0,
            Assignment: 0,
            Disposal: 0
          };
        }
        processedData[dateKey][row.jenis_transaksi] = parseInt(row.count);
      });

      const chartData = Object.values(processedData).sort((a, b) => 
        new Date(a.date) - new Date(b.date)
      );

      res.json({
        success: true,
        data: chartData
      });
    } catch (error) {
      console.error('Error getting transaction summary:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch transaction summary',
        error: error.message
      });
    }
  }

  // API: Get user activity summary
  static async getUserActivity(req, res) {
    try {
      const { query } = require('../config/db');
      const sql = `
        SELECT 
          u.id_user,
          u.username,
          COUNT(CASE WHEN t.jenis_transaksi = 'Assignment' THEN 1 END) as active_assignments,
          COUNT(CASE WHEN t.jenis_transaksi = 'Masuk' THEN 1 END) as receiving_transactions,
          COUNT(t.id_transaksi) as total_transactions
        FROM "user" u
        LEFT JOIN transaksi t ON u.id_user = t.created_by AND t.deleted_at IS NULL
        WHERE u.deleted_at IS NULL
        GROUP BY u.id_user, u.username
        HAVING COUNT(t.id_transaksi) > 0
        ORDER BY active_assignments DESC, total_transactions DESC
        LIMIT 10
      `;

      const result = await query(sql);

      res.json({
        success: true,
        data: result.rows
      });
    } catch (error) {
      console.error('Error getting user activity:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch user activity',
        error: error.message
      });
    }
  }

  // API: Get warehouse utilization
  static async getWarehouseUtilization(req, res) {
    try {
      const warehouses = await GudangModel.getAll();
      const utilization = [];

      for (const warehouse of warehouses) {
        const stockDetails = await GudangModel.getStockDetails(warehouse.id_gudang);
        
        utilization.push({
          id: warehouse.id_gudang,
          kode_gudang: warehouse.kode_gudang,
          nama_gudang: warehouse.nama_gudang,
          lokasi: warehouse.lokasi,
          total_items: stockDetails.length,
          current_stock: parseInt(warehouse.current_stock) || 0,
          total_transactions: parseInt(warehouse.total_transactions) || 0,
          low_stock_items: stockDetails.filter(item => (parseInt(item.current_stock) || 0) < 5).length
        });
      }

      res.json({
        success: true,
        data: utilization
      });
    } catch (error) {
      console.error('Error getting warehouse utilization:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch warehouse utilization',
        error: error.message
      });
    }
  }

  // API: Get recent activities
  static async getRecentActivities(req, res) {
    try {
      const { limit = 20 } = req.query;

      const { query } = require('../config/db');
      const sql = `
        SELECT 
          'transaction' as activity_type,
          t.kode_transaksi as reference,
          t.jenis_transaksi as action,
          t.created_at as timestamp,
          u.username as actor,
          CONCAT(t.jenis_transaksi, ' - ', b.nama_barang, ' (', t.jumlah, ' qty)') as description
        FROM transaksi t
        LEFT JOIN "user" u ON t.created_by = u.id_user
        LEFT JOIN barang b ON t.id_barang = b.id_barang
        WHERE t.deleted_at IS NULL
        ORDER BY t.created_at DESC
        LIMIT $1
      `;

      const result = await query(sql, [parseInt(limit)]);

      res.json({
        success: true,
        data: result.rows
      });
    } catch (error) {
      console.error('Error getting recent activities:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch recent activities',
        error: error.message
      });
    }
  }

  // API: Get category statistics
  static async getCategoryStats(req, res) {
    try {
      const categories = await BarangModel.getCategories();
      
      res.json({
        success: true,
        data: categories
      });
    } catch (error) {
      console.error('Error getting category stats:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch category statistics',
        error: error.message
      });
    }
  }

  // API: Get stock alerts
  static async getStockAlerts(req, res) {
    try {
      const lowStockItems = await BarangModel.getLowStockItems(5);
      
      const alerts = lowStockItems.map(item => ({
        type: 'low_stock',
        severity: item.current_stock === 0 ? 'critical' : 'warning',
        title: 'Low Stock Alert',
        message: `${item.nama_barang} stock is ${item.current_stock === 0 ? 'out of stock' : 'running low'}`,
        item_id: item.id_barang,
        kode_barang: item.kode_barang,
        current_stock: item.current_stock,
        warehouse: item.nama_gudang
      }));

      res.json({
        success: true,
        data: alerts
      });
    } catch (error) {
      console.error('Error getting stock alerts:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch stock alerts',
        error: error.message
      });
    }
  }

  // API: Get system statistics
  static async getSystemStats(req, res) {
    try {
      const [
        userStats,
        itemStats,
        warehouseStats,
        transactionStats
      ] = await Promise.all([
        UserModel.getStats(),
        BarangModel.getStats(),
        GudangModel.getStats(),
        TransaksiModel.getStats()
      ]);

      res.json({
        success: true,
        data: {
          users: userStats,
          items: itemStats,
          warehouses: warehouseStats,
          transactions: transactionStats
        }
      });
    } catch (error) {
      console.error('Error getting system stats:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch system statistics',
        error: error.message
      });
    }
  }
}

module.exports = DashboardController;