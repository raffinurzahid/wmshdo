const TransaksiModel = require('../models/transaksiModel');
const BarangModel = require('../models/barangModel');
const UserModel = require('../models/userModel');
const GudangModel = require('../models/gudangModel');

class TransaksiController {
  // Get transactions page
  static async getTransactionsPage(req, res) {
    try {
      const [transactions, barang, users, gudang] = await Promise.all([
        TransaksiModel.getAll(),
        BarangModel.getAllWithStock(),
        UserModel.getAll(),
        GudangModel.getAll()
      ]);

      res.render('pages/transaksi', {
        title: 'Transactions - WMS Help Desk',
        transactions,
        barang,
        users,
        gudang,
        currentPage: 'transaksi'
      });
    } catch (error) {
      console.error('Error getting transactions page:', error);
      res.status(500).render('pages/error', {
        title: 'Error',
        message: 'Failed to load transactions page',
        error: error.message
      });
    }
  }

  // API: Get all transactions
  static async getAllTransactions(req, res) {
    try {
      const { jenis, limit = 100, offset = 0 } = req.query;
      
      const transactions = await TransaksiModel.getAll(
        jenis, 
        parseInt(limit), 
        parseInt(offset)
      );
      
      res.json({
        success: true,
        data: transactions,
        total: transactions.length
      });
    } catch (error) {
      console.error('Error getting all transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch transactions',
        error: error.message
      });
    }
  }

  // API: Get transaction by ID
  static async getTransactionById(req, res) {
    try {
      const { id } = req.params;
      
      const transaction = await TransaksiModel.getById(id);
      
      if (!transaction) {
        return res.status(404).json({
          success: false,
          message: 'Transaction not found'
        });
      }
      
      res.json({
        success: true,
        data: transaction
      });
    } catch (error) {
      console.error('Error getting transaction by ID:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch transaction details',
        error: error.message
      });
    }
  }

  // API: Create receiving transaction (Masuk)
  static async createReceiving(req, res) {
    try {
      const { id_gudang, keterangan, items } = req.body;
      const createdBy = req.user?.id_user || null;

      // Validate required fields
      if (!id_gudang || !items || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Warehouse and items are required.'
        });
      }

      // Validate items
      for (const item of items) {
        if (!item.id_barang || !item.jumlah || item.jumlah <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Each item must have valid id_barang and jumlah.'
          });
        }
      }

      // Create transaction data array
      const transactionDataArray = items.map(item => ({
        id_barang: item.id_barang,
        id_gudang: id_gudang,
        jenis_transaksi: 'Masuk',
        jumlah: parseInt(item.jumlah),
        keterangan: keterangan || 'Item receiving'
      }));

      const results = await TransaksiModel.createBatch(transactionDataArray, createdBy);
      
      res.status(201).json({
        success: true,
        message: 'Receiving transactions created successfully',
        data: results
      });
    } catch (error) {
      console.error('Error creating receiving transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create receiving transaction',
        error: error.message
      });
    }
  }

  // API: Create assignment transaction
  static async createAssignment(req, res) {
    try {
      const { id_gudang, keterangan, items } = req.body;
      const createdBy = req.user?.id_user || null;

      // Validate required fields
      if (!id_gudang || !items || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Warehouse and items are required.'
        });
      }

      // Validate items
      for (const item of items) {
        if (!item.id_barang || !item.jumlah || item.jumlah <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Each item must have valid id_barang and jumlah.'
          });
        }
      }

      // Create transaction data array
      const transactionDataArray = items.map(item => ({
        id_barang: item.id_barang,
        id_gudang: id_gudang,
        jenis_transaksi: 'Assignment',
        jumlah: parseInt(item.jumlah),
        keterangan: keterangan || 'Item assignment'
      }));

      const results = await TransaksiModel.createBatch(transactionDataArray, createdBy);
      
      res.status(201).json({
        success: true,
        message: 'Assignment transactions created successfully',
        data: results
      });
    } catch (error) {
      console.error('Error creating assignment transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create assignment transaction',
        error: error.message
      });
    }
  }

  // API: Create disposal transaction
  static async createDisposal(req, res) {
    try {
      const { id_gudang, keterangan, items } = req.body;
      const createdBy = req.user?.id_user || null;

      // Validate required fields
      if (!id_gudang || !keterangan || !items || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Warehouse, reason (keterangan), and items are required.'
        });
      }

      // Validate items
      for (const item of items) {
        if (!item.id_barang || !item.jumlah || item.jumlah <= 0) {
          return res.status(400).json({
            success: false,
            message: 'Each item must have valid id_barang and jumlah.'
          });
        }
      }

      // Create transaction data array
      const transactionDataArray = items.map(item => ({
        id_barang: item.id_barang,
        id_gudang: id_gudang,
        jenis_transaksi: 'Disposal',
        jumlah: parseInt(item.jumlah),
        keterangan: keterangan
      }));

      const results = await TransaksiModel.createBatch(transactionDataArray, createdBy);
      
      res.status(201).json({
        success: true,
        message: 'Disposal transactions created successfully',
        data: results
      });
    } catch (error) {
      console.error('Error creating disposal transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create disposal transaction',
        error: error.message
      });
    }
  }

  // API: Update transaction
  static async updateTransaction(req, res) {
    try {
      const { id } = req.params;
      const { jumlah, keterangan, id_gudang } = req.body;
      const updatedBy = req.user?.id_user || null;

      const updateData = {};
      if (jumlah !== undefined) updateData.jumlah = parseInt(jumlah);
      if (keterangan !== undefined) updateData.keterangan = keterangan;
      if (id_gudang !== undefined) updateData.id_gudang = id_gudang;

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({
          success: false,
          message: 'No fields to update'
        });
      }

      const result = await TransaksiModel.update(id, updateData, updatedBy);

      res.json({
        success: true,
        message: 'Transaction updated successfully',
        data: result
      });
    } catch (error) {
      console.error('Error updating transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to update transaction',
        error: error.message
      });
    }
  }

  // API: Soft delete transaction
  static async softDeleteTransaction(req, res) {
    try {
      const { id } = req.params;
      const deletedBy = req.user?.id_user || null;

      const result = await TransaksiModel.softDelete(id, deletedBy);

      res.json({
        success: true,
        message: 'Transaction soft deleted successfully',
        data: result
      });
    } catch (error) {
      console.error('Error soft deleting transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to soft delete transaction',
        error: error.message
      });
    }
  }

  // API: Hard delete transaction
  static async deleteTransaction(req, res) {
    try {
      const { id } = req.params;

      const result = await TransaksiModel.delete(id);

      res.json({
        success: true,
        message: 'Transaction permanently deleted',
        data: result
      });
    } catch (error) {
      console.error('Error deleting transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to delete transaction',
        error: error.message
      });
    }
  }

  // API: Restore soft deleted transaction
  static async restoreTransaction(req, res) {
    try {
      const { id } = req.params;

      const result = await TransaksiModel.restore(id);

      res.json({
        success: true,
        message: 'Transaction restored successfully',
        data: result
      });
    } catch (error) {
      console.error('Error restoring transaction:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to restore transaction',
        error: error.message
      });
    }
  }

  // API: Get dashboard statistics
  static async getDashboardStats(req, res) {
    try {
      const stats = await TransaksiModel.getDashboardStats();
      
      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      console.error('Error getting dashboard statistics:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch dashboard statistics',
        error: error.message
      });
    }
  }

  // API: Get available items for transaction
  static async getAvailableItems(req, res) {
    try {
      const { id_gudang } = req.query;
      
      if (!id_gudang) {
        return res.status(400).json({
          success: false,
          message: 'Warehouse ID is required'
        });
      }

      const items = await GudangModel.getAvailableItems(id_gudang);
      
      res.json({
        success: true,
        data: items
      });
    } catch (error) {
      console.error('Error getting available items:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch available items',
        error: error.message
      });
    }
  }

  // API: Search transactions
  static async searchTransactions(req, res) {
    try {
      const { q } = req.query;
      
      if (!q || q.trim().length < 2) {
        return res.status(400).json({
          success: false,
          message: 'Search query must be at least 2 characters'
        });
      }

      const results = await TransaksiModel.search(q.trim());
      
      res.json({
        success: true,
        data: results
      });
    } catch (error) {
      console.error('Error searching transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to search transactions',
        error: error.message
      });
    }
  }

  // API: Generate transaction report
  static async generateReport(req, res) {
    try {
      const filters = {
        startDate: req.query.start_date,
        endDate: req.query.end_date,
        jenis_transaksi: req.query.jenis,
        warehouseId: req.query.warehouse_id,
        itemId: req.query.item_id,
        userId: req.query.user_id
      };

      // Remove undefined filters
      Object.keys(filters).forEach(key => {
        if (filters[key] === undefined || filters[key] === '') {
          delete filters[key];
        }
      });

      const results = await TransaksiModel.generateReport(filters);
      
      res.json({
        success: true,
        data: results,
        filters: filters
      });
    } catch (error) {
      console.error('Error generating report:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to generate report',
        error: error.message
      });
    }
  }

  // API: Get user transactions
  static async getUserTransactions(req, res) {
    try {
      const { userId } = req.params;
      
      const transactions = await TransaksiModel.getByUser(userId);
      
      res.json({
        success: true,
        data: transactions
      });
    } catch (error) {
      console.error('Error getting user transactions:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch user transactions',
        error: error.message
      });
    }
  }

  // API: Check stock availability
  static async checkStock(req, res) {
    try {
      const { id_barang, id_gudang, qty_required } = req.query;
      
      if (!id_barang || !id_gudang || !qty_required) {
        return res.status(400).json({
          success: false,
          message: 'Missing required parameters'
        });
      }

      const stockCheck = await TransaksiModel.checkStockAvailability(
        id_barang,
        id_gudang,
        parseInt(qty_required)
      );
      
      res.json({
        success: true,
        data: stockCheck
      });
    } catch (error) {
      console.error('Error checking stock:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to check stock',
        error: error.message
      });
    }
  }

  // API: Get transaction summary
  static async getTransactionSummary(req, res) {
    try {
      const summaryByJenis = await TransaksiModel.getSummaryByJenis();
      const monthlyStats = await TransaksiModel.getMonthlyStats(new Date().getFullYear());
      
      res.json({
        success: true,
        data: {
          byJenis: summaryByJenis,
          monthly: monthlyStats
        }
      });
    } catch (error) {
      console.error('Error getting transaction summary:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to fetch transaction summary',
        error: error.message
      });
    }
  }
}

module.exports = TransaksiController;